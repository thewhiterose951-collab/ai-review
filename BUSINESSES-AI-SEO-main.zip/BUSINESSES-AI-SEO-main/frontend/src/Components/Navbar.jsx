import React, { useEffect, useState, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const logoPath = '/logo png[1].png';

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    document.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      document.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <nav 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 bg-white shadow-md py-2`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between md:justify-around gap-6 items-center h-12">
          <Link 
            to="/" 
            className="flex items-center"
            onClick={closeMobileMenu}>
            <img 
              src={logoPath} 
              alt="Logo" 
              className={`w-auto transition-all duration-300 ${scrolled ? 'h-8' : 'h-10'}`} 
            />
          </Link>

          <div className="md:hidden flex items-center">
            <button 
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md focus:outline-none text-gray-800 hover:text-indigo-600"
              aria-expanded={isMenuOpen}
              aria-label="Toggle menu"
            >
              {!isMenuOpen ? (
                <div className="space-y-1.5">
                  <span className="block w-6 h-0.5 bg-current transition-transform"></span>
                  <span className="block w-6 h-0.5 bg-current transition-opacity"></span>
                  <span className="block w-6 h-0.5 bg-current"></span>
                </div>
              ) : (
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              )}
            </button>
          </div>

          <div className="hidden md:flex items-center justify-between md:justify-around gap-4 lg:gap-10 space-x-4 lg:space-x-8 font-medium">
            <Link 
              to="/" 
              className={`text-sm font-normal transition-colors duration-200 ${
                scrolled ? 'text-gray-700 hover:text-indigo-600' : 'text-black hover:text-indigo-200'
              }`}
            >
              Home
            </Link>
            <Link 
              to="/dashboard" 
              className={`text-sm font-normal transition-colors duration-200 ${
                scrolled ? 'text-gray-700 hover:text-indigo-600' : 'text-black hover:text-indigo-200'
              }`}
            >
              Dashboard
            </Link>
            <Link 
              to="/all-reviews" 
              className={`text-sm font-normal transition-colors duration-200 ${
                scrolled ? 'text-gray-700 hover:text-indigo-600' : 'text-black hover:text-indigo-200'
              }`}
            >
              Reviews
            </Link>
            <Link 
              to="/seo-dashboard" 
              className={`text-sm font-normal transition-colors duration-200 ${
                scrolled ? 'text-gray-700 hover:text-indigo-600' : 'text-black hover:text-indigo-200'
              }`}
            >
             SEO
            </Link>
            <Link 
              to="/analytics-dashboard" 
              className={`text-sm font-normal transition-colors duration-200 ${
                scrolled ? 'text-gray-700 hover:text-indigo-600' : 'text-black hover:text-indigo-200'
              }`}
            >
             Analytics
            </Link>
            <Link 
              to="/settings" 
              className={`text-sm font-normal transition-colors duration-200 ${
                scrolled ? 'text-gray-700 hover:text-indigo-600' : 'text-black hover:text-indigo-200'
              }`}
            >
             Settings
            </Link>

            <div className="flex items-center space-x-2 sm:space-x-4">
              {user ? (
                <div className="flex items-center space-x-4">
                  <div className={`hidden sm:flex items-center space-x-2 ${
                    scrolled ? 'text-gray-800' : 'text-black'
                  }`}>
                    <span className="text-sm font-medium">Welcome, {user.name || user.email}</span>
                  </div>
                  <button
                    onClick={() => {
                      logout();
                      navigate('/');
                    }}
                    className={`px-3 sm:px-5 py-2 sm:py-3 text-xs sm:text-sm font-medium cursor-pointer rounded-lg sm:rounded-xl transition-colors duration-200 ${
                      scrolled 
                        ? 'text-indigo-600 border border-indigo-600 hover:bg-indigo-50' 
                        : 'text-white border border-white hover:bg-white/10'
                    }`}
                  >
                    Logout
                  </button>
                </div>
              ) : (
                <>
                  <Link 
                    to="/login" 
                    className={`px-3 sm:px-5 py-2 sm:py-3 text-xs sm:text-sm font-medium cursor-pointer rounded-lg sm:rounded-xl transition-colors duration-200 ${
                      scrolled 
                        ? 'text-indigo-600 border border-indigo-600 hover:bg-indigo-50' 
                        : 'text-black border border-black hover:bg-black/10'
                    }`}
                  >
                    Login
                  </Link>
                  <Link 
                    to="/login" 
                    className="px-3 sm:px-5 py-2 sm:py-3 text-xs sm:text-sm font-medium cursor-pointer bg-gradient-to-r from-[#5d3be6] to-[#9a7dff] text-white rounded-lg sm:rounded-xl hover:opacity-90 transition-colors duration-200"
                  >
                    Sign Up
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      <div 
        className={`lg:hidden fixed inset-0 bg-white transform ${
          isMenuOpen ? 'translate-x-0' : 'translate-x-full'
        } transition-transform duration-300 ease-in-out z-50 overflow-y-auto`}
      >
        <div className="pt-5 pb-6 px-5">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center">
              <img 
                src={logoPath} 
                alt="Logo" 
                className="w-auto h-10"
              />
            </div>
            <button 
              onClick={toggleMenu}
              className="text-black hover:text-indigo-600 focus:outline-none"
            >
              <span className="sr-only">Close menu</span>
              <svg className="h-6 w-6" fill="black" viewBox="0 0 24 24" stroke="black">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <nav className="space-y-1">
            {[
              { name: 'Dashboard', path: '/dashboard' },
              { name: 'Reviews', path: '/reviews' },
              { name: 'SEO', path: '/seo-dashboard' },
              { name: 'Analytics', path: '/analytics-dashboard' },
              { name: 'Settings', path: '/settings' }
            ].map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className="block px-4 py-3 text-base font-medium text-gray-700 hover:bg-gray-100 rounded-lg"
                onClick={closeMobileMenu}
              >
                {item.name}
              </Link>
            ))}
            
            <div className="pt-4 mt-4 border-t border-gray-800 space-y-3">
              {user ? (
                <>
                  <div className="px-4 py-3 text-gray-800 text-center">
                    Welcome, {user.name || user.email}
                  </div>
                  <button
                    onClick={() => {
                      logout();
                      closeMobileMenu();
                      navigate('/');
                    }}
                    className="w-full text-center px-4 py-3 border cursor-pointer border-gray-300 text-gray-800 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <Link
                    to="/login"
                    className="block w-full text-center px-4 py-3 border cursor-pointer border-gray-300 text-gray-800 rounded-lg hover:bg-gray-100 transition-colors"
                    onClick={closeMobileMenu}
                  >
                    Login
                  </Link>
                  <Link
                    to="/login"
                    className="block w-full text-center px-4 py-3 bg-gradient-to-r from-[#5d3be6] to-[#9a7dff] cursor-pointer text-white rounded-lg hover:opacity-90 transition-all"
                    onClick={closeMobileMenu}
                  >
                    Sign Up
                  </Link>
                </>
              )}
            </div>
          </nav>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;