import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FaDownload, FaCopy, FaExternalLinkAlt, FaQrcode, FaChevronDown, FaSync, FaGoogle } from 'react-icons/fa'
import { toast } from 'sonner'
import { useGoogleBusiness } from '../context/GoogleBusinessContext'

function QRCodeComponent({ initialUrl = 'https://example.com' }) {
  const [url, setUrl] = useState(initialUrl)
  const [showDropdown, setShowDropdown] = useState(false)
  const [qrType, setQrType] = useState('google')
  
  const {
    businesses: googleBusinesses,
    selectedBusiness: googleSelectedBusiness,
    loading: googleLoading,
    isConnected,
    selectBusiness: selectGoogleBusiness
  } = useGoogleBusiness()
  
  const [localBusinesses, setLocalBusinesses] = useState([])
  const [selectedLocalBusiness, setSelectedLocalBusiness] = useState(null)
  const [localLoading, setLocalLoading] = useState(false)
  const token = localStorage.getItem('token')

  const fetchLocalBusinesses = async () => {
    setLocalLoading(true)
    try {
      const res = await fetch('/api/business/all-business', {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      })
      const data = await res.json()
      if (res.ok) {
        setLocalBusinesses(data.businesses || [])
        console.log('QR: Local businesses fetched:', data.businesses?.length || 0)

        const storedBusinessId = localStorage.getItem('selectedBusinessId')
        if (storedBusinessId && data.businesses) {
          const storedBusiness = data.businesses.find(b => b.id === storedBusinessId)
          if (storedBusiness) {
            setSelectedLocalBusiness(storedBusiness)
            if (qrType === 'local') {
              setUrl(`${window.location.origin}/review/${storedBusiness.id}`)
            }
            console.log('QR: Auto-selected local business:', storedBusiness.name)
          }
        } else if (data.businesses && data.businesses.length === 1) {
          setSelectedLocalBusiness(data.businesses[0])
          if (qrType === 'local') {
            setUrl(`${window.location.origin}/review/${data.businesses[0].id}`)
          }
          console.log('QR: Single local business selected:', data.businesses[0].name)
        }
      } else {
        console.error('QR: Failed to fetch local businesses:', data.error)
        toast.error(data.error || 'Failed to fetch local businesses')
      }
    } catch (err) {
      console.error('QR: Network error:', err)
      toast.error('Network error')
    }
    setLocalLoading(false)
  }
  const generateQRCode = (text) => {
    return `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(text)}`
  }

  const handleGoogleBusinessSelect = async (business) => {
    await selectGoogleBusiness(business)
    setUrl(getGoogleBusinessUrl(business))
    setShowDropdown(false)
  }
  
  const handleLocalBusinessSelect = (business) => {
    setSelectedLocalBusiness(business)
    setUrl(`${window.location.origin}/review/${business.id}`)
    localStorage.setItem('selectedBusinessId', business.id)
    setShowDropdown(false)
  }
 
  const getGoogleBusinessUrl = (business) => {
    if (!business) return ''
    
    console.log('Business object for place ID extraction:', business)
    const locationId = business.name.split('/')[3]
    let placeId = null
  
    if (business.extractedPlaceId) {
      placeId = business.extractedPlaceId
    } else if (business.metadata?.placeId) {
      placeId = business.metadata.placeId
    } else if (business.placeId) {
      placeId = business.placeId
    } else if (business.location?.metadata?.placeId) {
      placeId = business.location.metadata.placeId
    } else if (business.storefrontAddress?.placeId) {
      placeId = business.storefrontAddress.placeId
    } else if (business.profile?.placeId) {
      placeId = business.profile.placeId
    } else if (business.locationKey?.placeId) {
      placeId = business.locationKey.placeId
    }
    
    if (!placeId) {
      console.warn('No place ID found for business:', business.title)
      if (business.title) {
        const businessName = encodeURIComponent(business.title)
        let searchQuery = businessName
        if (business.storefrontAddress?.addressLines) {
          const address = encodeURIComponent(business.storefrontAddress.addressLines.join(' '))
          searchQuery += `+${address}`
        }
        if (business.storefrontAddress?.locality) {
          const locality = encodeURIComponent(business.storefrontAddress.locality)
          searchQuery += `+${locality}`
        }
        
        console.log('Creating Google search URL for:', business.title)
        return `https://www.google.com/maps/search/${searchQuery}`
      }
      console.warn('Using location ID as last fallback:', locationId)
      placeId = locationId
    }
    
    console.log('Final place ID for business:', business.title, '- Place ID:', placeId)
    return `https://search.google.com/local/writereview?placeid=${placeId}`
  }
  
  const handleQrTypeChange = (type) => {
    setQrType(type)
    if (type === 'google' && googleSelectedBusiness) {
      setUrl(getGoogleBusinessUrl(googleSelectedBusiness))
    } else if (type === 'local' && selectedLocalBusiness) {
      setUrl(`${window.location.origin}/review/${selectedLocalBusiness.id}`)
    }
  }

  useEffect(() => {
    if (token) {
      fetchLocalBusinesses()
    }
  }, [])

  useEffect(() => {
    if (qrType === 'google' && googleSelectedBusiness) {
      setUrl(getGoogleBusinessUrl(googleSelectedBusiness))
    }
  }, [googleSelectedBusiness, qrType])
  
  useEffect(() => {
    if (isConnected && googleBusinesses.length > 0) {
      setQrType('google')
      if (googleSelectedBusiness) {
        setUrl(getGoogleBusinessUrl(googleSelectedBusiness))
      }
    }
  }, [isConnected, googleBusinesses, googleSelectedBusiness])

  const handleDownload = () => {
    const link = document.createElement('a')
    link.href = generateQRCode(url)
    link.download = 'qr-code.png'
    link.click()
  }


  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(url)
      toast.success('Link copied to clipboard!')
    } catch (err) {
      console.error('Failed to copy: ', err)
      toast.error('Failed to copy link')
    }
  }

  return (
    <div className="w-full max-w-lg mx-auto">
      {/* Main Container */}
      <div className="bg-[#171624]/50 border border-white/5 rounded-lg p-6 sm:p-8 backdrop-blur-sm">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-3 mb-3">
            <FaQrcode className="text-2xl text-purple-400" />
            <h2 className="text-2xl font-bold text-white">QR Code Generator</h2>
            <button
              onClick={fetchLocalBusinesses}
              disabled={localLoading}
              className="ml-2 p-2 bg-purple-600 hover:bg-purple-700 rounded-lg transition-colors duration-200 disabled:opacity-50"
              title="Refresh local businesses"
            >
              <FaSync className={`text-sm ${localLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
          <p className="text-gray-300 text-sm">
            {qrType === 'google' && googleSelectedBusiness ? `Generate QR for ${googleSelectedBusiness.title}` : 
             qrType === 'local' && selectedLocalBusiness ? `Generate QR for ${selectedLocalBusiness.name}` : 
             'Generate and share your review link'}
          </p>
        </div>

        {/* QR Type Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            QR Code Type
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => handleQrTypeChange('google')}
              disabled={!isConnected}
              className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg border transition-all duration-200 ${
                qrType === 'google' 
                  ? 'bg-blue-600 border-blue-600 text-white' 
                  : 'bg-white/10 border-white/20 text-gray-300 hover:bg-white/20'
              } ${!isConnected ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <FaGoogle className="text-sm" />
              <span className="text-sm font-medium">Google Business</span>
            </button>
            <button
              onClick={() => handleQrTypeChange('local')}
              className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg border transition-all duration-200 ${
                qrType === 'local' 
                  ? 'bg-purple-600 border-purple-600 text-white' 
                  : 'bg-white/10 border-white/20 text-gray-300 hover:bg-white/20'
              }`}
            >
              <FaQrcode className="text-sm" />
              <span className="text-sm font-medium">Local Business</span>
            </button>
          </div>
          {!isConnected && (
            <p className="text-xs text-yellow-400 mt-2">
              Connect to Google Business in Integrations to enable Google QR codes
            </p>
          )}
        </div>

        {/* Business Selection */}
        {((qrType === 'google' && googleBusinesses.length > 1) || (qrType === 'local' && localBusinesses.length > 1)) && (
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Select Business
            </label>
            <div className="relative">
              <button
                onClick={() => setShowDropdown(!showDropdown)}
                className="w-full px-4 py-3 border border-white/20 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white/10 text-white transition-all duration-200 flex items-center justify-between"
              >
                <span>
                  {qrType === 'google' && googleSelectedBusiness ? googleSelectedBusiness.title :
                   qrType === 'local' && selectedLocalBusiness ? selectedLocalBusiness.name :
                   'Select a business'}
                </span>
                <FaChevronDown className={`transition-transform duration-200 ${showDropdown ? 'rotate-180' : ''}`} />
              </button>
              
              {showDropdown && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-gray-800 border border-white/20 rounded-lg shadow-lg z-10 max-h-60 overflow-y-auto">
                  {qrType === 'google' ? (
                    googleBusinesses.map((business, index) => (
                      <button
                        key={index}
                        onClick={() => handleGoogleBusinessSelect(business)}
                        className="w-full px-4 py-3 text-left hover:bg-white/10 transition-colors duration-200 text-white border-b border-white/10 last:border-b-0"
                      >
                        <div>
                          <div className="font-medium">{business.title}</div>
                          <div className="text-sm text-gray-400">{business.primaryCategory?.displayName || 'Business'}</div>
                        </div>
                      </button>
                    ))
                  ) : (
                    localBusinesses.map((business) => (
                      <button
                        key={business.id}
                        onClick={() => handleLocalBusinessSelect(business)}
                        className="w-full px-4 py-3 text-left hover:bg-white/10 transition-colors duration-200 text-white border-b border-white/10 last:border-b-0"
                      >
                        <div>
                          <div className="font-medium">{business.name}</div>
                          <div className="text-sm text-gray-400">{business.category}</div>
                        </div>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* URL Input */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Review Link
          </label>
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Enter your review link"
            className="w-full px-4 py-3 border border-white/20 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white/10 text-white placeholder-gray-400 transition-all duration-200"
            readOnly={(qrType === 'google' && googleSelectedBusiness) || (qrType === 'local' && selectedLocalBusiness)}
          />
        </div>

        {/* QR Code Display */}
        <div className="flex justify-center mb-6">
          {(googleLoading || localLoading) ? (
            <div className="bg-white p-4 rounded-lg shadow-lg w-48 h-48 flex items-center justify-center">
              <div className="text-gray-500">Loading...</div>
            </div>
          ) : (
            <div className="bg-white p-4 rounded-lg shadow-lg">
              <img
                src={generateQRCode(url)}
                alt="QR Code"
                className="w-48 h-48 object-contain"
              />
            </div>
          )}
        </div>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={handleDownload}
              className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 shadow-md hover:shadow-lg"
            >
              <FaDownload className="text-sm" />
              <span>Download</span>
            </button>

            <button
              onClick={handleCopyLink}
              className="flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 shadow-md hover:shadow-lg"
            >
              <FaCopy className="text-sm" />
              <span>Copy Link</span>
            </button>
          </div>

          {((qrType === 'google' && googleSelectedBusiness) || (qrType === 'local' && selectedLocalBusiness)) && (
            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full text-blue-400 hover:text-blue-300 font-medium py-3 px-4 rounded-lg border border-blue-400 hover:border-blue-300 transition-all duration-200"
            >
              <FaExternalLinkAlt className="text-sm" />
              <span>Open Review Link</span>
            </a>
          )}
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-white/10 text-center">
          <p className="text-xs text-gray-400">
            {qrType === 'google' && !isConnected ? 'Connect to Google Business to generate Google QR codes' :
             qrType === 'google' && googleBusinesses.length === 0 ? 'No Google businesses found' :
             qrType === 'local' && localBusinesses.length === 0 && !localLoading ? 'Please create a business first to generate QR codes' :
             qrType === 'google' ? 'Share this QR code to get Google reviews' : 'Share this QR code to get more reviews'}
          </p>
        </div>
      </div>
    </div>
  )
}

export default QRCodeComponent