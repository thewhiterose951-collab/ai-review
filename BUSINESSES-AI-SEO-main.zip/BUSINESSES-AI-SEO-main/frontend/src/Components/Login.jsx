import axios from 'axios';
import { getAuth, signInWithCustomToken,GoogleAuthProvider, signInWithPopup } from 'firebase/auth';

import { useContext, useEffect, useState } from 'react';
import { FcGoogle } from 'react-icons/fc';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import '../config/firebase';
import { AuthContext } from '../context/AuthContext';
import SonnerProvider from '../sonner/SonnerProvider';
import { Link } from 'react-router-dom';

const Login = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  const [activeForm, setActiveForm] = useState('signup');
  const [signupData, setSignupData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
  });
  const [signupLoading, setSignupLoading] = useState(false);
  const [signupError, setSignupError] = useState('');
  const [loginData, setLoginData] = useState({
    email: '',
    password: '',
  });
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState('');
  const { user, login } = useContext(AuthContext);

  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser && !user) {
      login(JSON.parse(storedUser));
    }
  }, []);
  
  useEffect(() => {
    if (location.state?.showSuccess && location.state?.message) {
      toast.success(location.state.message);
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  const handleSignupChange = (e) => {
    setSignupData({ ...signupData, [e.target.name]: e.target.value });
  };

  const handleLoginChange = (e) => {
    setLoginData({ ...loginData, [e.target.name]: e.target.value });
  };
  const handleSignupSubmit = async (e) => {
    e.preventDefault();
    setSignupLoading(true);
    setSignupError('');
    try {
      const res = await axios.post('/api/auth/signup', signupData, {
        headers: {
          'Content-Type': 'application/json',
        },
        withCredentials: true
      });
      if (res.status === 201) {
        toast.success('Signup successful! Please check your email to verify your account.');
        setSignupData({
          name: '',
          email: '',
          phone: '',
          password: '',
        });
      }
    } catch (err) {
      const errorMessage = err.response?.data?.error || 
                          err.response?.data?.message || 
                          err.message || 
                          'Signup failed. Please try again.';
      setSignupError(errorMessage);
      toast.error(errorMessage);
      console.error('Signup error:', err.response?.data || err.message);
    } finally {
      setSignupLoading(false);
    }
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setLoginLoading(true);
    setLoginError('');
    try {
      const res = await axios.post('/api/auth/login', loginData, { withCredentials: true });
      const customToken = res.data?.customToken;
      if (res.status === 200 && customToken) {
        const auth = getAuth();
        const userCredential = await signInWithCustomToken(auth, customToken);
        const idToken = await userCredential.user.getIdToken();
        localStorage.setItem('token', idToken);
        const userRes = await axios.get('/api/me', {
          headers: { Authorization: `Bearer ${idToken}` },
          withCredentials: true
        });
        if (userRes.data?.user) {
          login(userRes.data.user);
          navigate('/dashboard', { 
            state: { 
              showSuccess: true,
              message: 'Login successful!' 
            } 
          });
        } else {
          toast.error('Could not fetch user data after login');
        }
      } else {
        toast.error('Login failed: No custom token received');
      }
    } catch (err) {
      toast.error(err.response?.data?.message || err.message || 'Login failed');
    } finally {
      setLoginLoading(false);
    }
  };

const handleGoogleSignIn = async () => {
  try {
    const auth = getAuth();
    const provider = new GoogleAuthProvider();

    provider.addScope("profile");
    provider.addScope("email");
    provider.addScope("openid");

    const result = await signInWithPopup(auth, provider);
    const user = result.user;

    let email = user.email || result._tokenResponse?.email || null;
    if (!email && user.accessToken) {
      const info = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
        headers: { Authorization: `Bearer ${user.accessToken}` },
      });
      const data = await info.json();
      email = data.email || null;
    }
    if (!email) {
      toast.error("No email found. Try a different Google account.");
      return;
    }

  
    const idToken = await user.getIdToken();


    const res = await axios.post(
      "/api/auth/signup-google",
      { idToken, fallbackEmail: email },
      { withCredentials: true }
    );

    const { customToken } = res.data;
    if (!customToken) throw new Error("No custom token received from backend");


    const userCred = await signInWithCustomToken(auth, customToken);


    // console.log("Logged-in user:", userCred.user); 
    const finalToken = await userCred.user.getIdToken();
    localStorage.setItem('token', finalToken);

    const userRes = await axios.get('/api/me', {
      headers: { Authorization: `Bearer ${finalToken}` },
      withCredentials: true
    });

    if (userRes.data?.user) {
      login(userRes.data.user);
      toast.success("Google Sign-In Successful 🎉");
      navigate("/dashboard", { 
        state: { 
          showSuccess: true,
          message: 'Google Sign-In successful!' 
        } 
      });
    } else {
      toast.error('Could not fetch user data after Google Sign-In');
    }

  } catch (err) {
    console.error("Google Sign-In Error:", err);
    toast.error(err.response?.data?.error || err.message || "Login failed");
  }
};


  return (
    <>
      <SonnerProvider />
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0f0f1a] text-white px-4">
      <div className="text-center mb-10 sm:mt-10 mt-20">
        <h2 className="text-3xl md:text-4xl font-bold text-white uppercase">Welcome to</h2>
        <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-purple-600 mt-2">
          ReviewAI Pro
        </h1>
      </div>

      <div className="w-full max-w-6xl bg-[#121212] rounded-xl shadow-2xl grid grid-cols-1 md:grid-cols-2 overflow-hidden relative">
        <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-px bg-gray-700"></div>

        {/* Switch for small/medium devices */}
        <div className="md:hidden flex justify-center items-center w-full py-4 bg-[#181818]">
          <button
            className={`px-6 py-2 rounded-l-lg font-semibold transition-colors ${activeForm === 'signup' ? 'bg-purple-600 text-white' : 'bg-[#121212] text-gray-400'}`}
            onClick={() => setActiveForm('signup')}
          >
            Sign Up
          </button>
          <button
            className={`px-6 py-2 rounded-r-lg font-semibold transition-colors ${activeForm === 'login' ? 'bg-purple-600 text-white' : 'bg-[#121212] text-gray-400'}`}
            onClick={() => setActiveForm('login')}
          >
            Login
          </button>
        </div>

        {/* Signup Form */}
        <div className={`flex flex-col items-center justify-center p-10 space-y-6 ${activeForm === 'login' ? 'hidden md:flex' : 'md:flex'} md:col-span-1`}>
          <h2 className="text-2xl font-semibold text-white">Sign up</h2>

          <form className="w-full space-y-4" onSubmit={handleSignupSubmit}>
            <input
              type="text"
              name="name"
              placeholder="Full Name"
              className="w-full bg-[#121212] border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-purple-500"
              required
              value={signupData.name}
              onChange={handleSignupChange}
            />
            <input
              type="email"
              name="email"
              placeholder="Email address"
              className="w-full bg-[#121212] border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-purple-500"
              required
              value={signupData.email}
              onChange={handleSignupChange}
            />
            <input
              type="tel"
              name="phone"
              placeholder="Phone number"
              className="w-full bg-[#121212] border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-purple-500"
              required
              value={signupData.phone}
              onChange={handleSignupChange}
            />
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                placeholder="Password"
                className="w-full bg-[#121212] border border-gray-600 rounded-lg px-4 py-3 pr-12 focus:outline-none focus:border-purple-500"
                required
                value={signupData.password}
                onChange={handleSignupChange}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-3 flex items-center text-sm text-gray-400"
              >
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>
            <button type="submit" className="bg-purple-600 hover:bg-purple-700 transition text-white py-3 rounded-lg shadow-md w-full font-semibold" disabled={signupLoading}>
              {signupLoading ? 'Signing Up...' : 'Sign Up'}
            </button>
            {signupError && <p className="text-red-500 text-sm text-center">{signupError}</p>}
          </form>

          <p className="text-xs text-gray-400 text-center mt-4">
            By signing up, you agree to the{' '}
            <a href="#" className="text-purple-400 underline">Terms of Service</a><br /> and acknowledge you've read our{' '}
            <a href="#" className="text-purple-400 underline">Privacy Policy</a>.
          </p>
        </div>

        {/* Login Form */}
        <div className={`bg-[#181818] flex flex-col justify-center p-10 space-y-6 ${activeForm === 'signup' ? 'hidden md:flex' : 'md:flex'} md:col-span-1`}>
          <h2 className="text-2xl font-semibold text-white text-center">Login</h2>

          <form className="w-full space-y-4" onSubmit={handleLoginSubmit}>
            <input
              type="email"
              name="email"
              placeholder="Email address"
              className="w-full bg-[#121212] border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-purple-500"
              required
              value={loginData.email}
              onChange={handleLoginChange}
            />
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                placeholder="Password"
                className="w-full bg-[#121212] border border-gray-600 rounded-lg px-4 py-3 pr-12 focus:outline-none focus:border-purple-500"
                required
                value={loginData.password}
                onChange={handleLoginChange}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-3 flex items-center text-sm text-gray-400"
              >
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>
            <div className="text-right">
              <Link to="/forgot-password" className="text-sm text-purple-400 hover:underline">
                Forgot your password?
              </Link>
            </div>
            <button type="submit" className="bg-purple-600 hover:bg-purple-700 transition text-white py-3 rounded-lg shadow-md w-full font-semibold" disabled={loginLoading}>
              {loginLoading ? 'Logging In...' : 'Login'}
            </button>
            {loginError && <p className="text-red-500 text-sm text-center">{loginError}</p>}
          </form>
          <div className="w-full mt-6">
            <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-600"></div>
              </div>
              <div className="relative flex justify-center">
                <span className="px-3 bg-[#181818] text-sm text-gray-400">Or continue with</span>
              </div>
            </div>
            
            <button
              type="button"
              onClick={handleGoogleSignIn}
              className="w-full flex items-center justify-center cursor-pointer gap-3 bg-[#121212] border border-gray-600 text-gray-300 py-3 px-4 rounded-lg hover:bg-[#1e1e1e] transition duration-300"
            >
              <FcGoogle className="text-xl" />
              <span>Continue with Google</span>
            </button>
            
            <p className="text-xs text-gray-500 text-center mt-4">
              By continuing, you agree to our{' '}
              <a href="/terms" className="text-purple-400 hover:underline">Terms of Service</a> and{' '}
              <a href="/privacy" className="text-purple-400 hover:underline">Privacy Policy</a>.
            </p>
          </div>
        </div>
      </div>
    </div>
    </> 
  );
};

export default Login;