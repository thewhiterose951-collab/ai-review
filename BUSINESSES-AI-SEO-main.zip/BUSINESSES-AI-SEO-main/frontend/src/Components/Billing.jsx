import { CreditCard, Check, Clock, Crown, Mail, MessageCircle, Zap, TrendingUp, Star, Shield, HelpCircle } from "lucide-react";
import { useContext, useState } from "react";
import { toast } from 'sonner';
import SideNav from './SideNav';
import { SidebarContext } from "../context/SidebarContext";

const Billing = () => {
  const { isCollapsed } = useContext(SidebarContext);
  const [activeTab, setActiveTab] = useState('plans');
  const [selectedPlan, setSelectedPlan] = useState(null);

  // Mock data - replace with actual API calls
  const currentSubscription = {
    status: 'Free Trial',
    daysRemaining: 14,
    planName: 'Free Trial',
    price: 0,
    billingCycle: 'trial'
  };

  const plan = {
    id: 'pro',
    name: 'Pro Plan',
    price: 99,
    originalPrice: 119,
    discount: 17,
    billingCycle: 'year',
    popular: true,
    features: [
      '$99 per Google Business Profile/year',
      'Auto-Post Scheduling',
      'Review Management & Auto-Reply',
      'Performance Analytics',
      'Advanced Analytics',
      'API Access',
      'Priority Support',
      'Scale as you grow - unlimited profiles'
    ]
  };

  const paymentHistory = [
    {
      id: 1,
      date: '2025-09-16',
      amount: 99,
      status: 'Paid',
      plan: 'Pro Plan',
      invoice: 'INV-2025-001'
    },
    {
      id: 2,
      date: '2024-09-16',
      amount: 99,
      status: 'Paid',
      plan: 'Pro Plan',
      invoice: 'INV-2024-001'
    }
  ];

  const handleUpgrade = () => {
    setSelectedPlan(plan);
    toast.success(`Redirecting to checkout for ${plan.name}...`);
    // Add your payment gateway integration here
  };

  const handleCancelSubscription = () => {
    toast.error('Subscription cancellation requested');
    // Add cancellation logic
  };

  return (
    <div className="min-h-screen w-full text-white flex">
      <SideNav />
      <div className={`flex-1 p-6 transition-all duration-300 ease-in-out ${isCollapsed ? 'md:ml-2' : 'md:ml-45'} w-full`}>
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-extrabold tracking-tight mb-2">Billing & Subscription</h1>
            <p className="text-white/60">Manage your subscription and payment details</p>
          </div>

          {/* Current Subscription Card */}
          <div className="rounded-xl bg-gradient-to-br from-purple-600/20 to-indigo-600/20 border border-purple-500/30 p-4 mb-6">
            <h2 className="text-lg font-bold mb-2">Current Subscription</h2>
            <p className="text-white/70 text-sm mb-4">Your active plan and billing details</p>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-xs text-white/60">Status:</span>
                    <span className="px-2 py-0.5 bg-blue-500/20 text-blue-400 rounded-full text-xs font-medium">
                      {currentSubscription.status}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 text-white/80">
                    <Clock className="w-3 h-3" />
                    <span className="text-xs">{currentSubscription.daysRemaining} days remaining in your free trial</span>
                  </div>
                </div>
              </div>
              
              <button
                onClick={() => setActiveTab('plans')}
                className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 rounded-lg text-white text-sm font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                <Crown className="w-4 h-4" />
                <span>Upgrade to Pro</span>
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-white/10 mb-6">
            <button
              onClick={() => setActiveTab('plans')}
              className={`px-6 py-3 text-sm font-medium transition-colors ${
                activeTab === 'plans'
                  ? 'text-purple-400 border-b-2 border-purple-400 bg-white/5'
                  : 'text-white/60 hover:text-white/80'
              }`}
            >
              Available Plans
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-6 py-3 text-sm font-medium transition-colors ${
                activeTab === 'history'
                  ? 'text-purple-400 border-b-2 border-purple-400 bg-white/5'
                  : 'text-white/60 hover:text-white/80'
              }`}
            >
              Payment History
            </button>
          </div>

          {activeTab === 'plans' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <div className="rounded-xl border p-6 bg-gradient-to-br from-purple-600/20 to-indigo-600/20 border-purple-500/50 shadow-lg shadow-purple-500/20 relative">
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <span className="px-3 py-1 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full text-xs font-bold uppercase">
                        Most Popular
                      </span>
                    </div>

                    <div className="mb-6">
                      <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                      <div className="flex items-baseline space-x-2">
                        <span className="text-4xl font-extrabold">${plan.price}</span>
                        <span className="text-lg text-white/60 line-through">${plan.originalPrice}</span>
                      </div>
                      <p className="text-xs text-white/70 mt-1">per Google Business Profile/{plan.billingCycle}</p>
                      <div className="mt-2">
                        <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-full text-xs font-medium">
                          Save {plan.discount}%
                        </span>
                      </div>
                    </div>

                    <ul className="space-y-3 mb-6">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <Check className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-white/90">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <button
                      onClick={handleUpgrade}
                      className="w-full py-3 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white text-base font-semibold rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl"
                    >
                      Get Started
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="rounded-xl bg-gradient-to-r from-indigo-600/20 to-purple-600/20 border border-indigo-500/30 p-4">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 bg-blue-500/20 rounded-lg">
                        <HelpCircle className="w-6 h-6 text-blue-400" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg font-bold mb-1">Need Help?</h3>
                        <p className="text-white/70 text-xs">
                          We're here to assist you with any questions or concerns
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-xl bg-[#121324]/90 border border-white/10 p-4">
                    <p className="text-white/80 text-xs leading-relaxed">
                      Our support team is ready to help you get the most out of your subscription. Reach out to us through any of the following channels:
                    </p>
                  </div>

                  <div className="rounded-xl bg-[#121324]/90 border border-white/10 p-4">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 bg-blue-500/20 rounded-lg">
                        <Mail className="w-5 h-5 text-blue-400" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-base font-semibold mb-1">Email Support</h3>
                        <a
                          href="mailto:support@reviewai.com"
                          className="text-blue-400 hover:text-blue-300 text-xs font-medium"
                        >
                          support@reviewai.com
                        </a>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-xl bg-[#121324]/90 border border-white/10 p-4">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 bg-green-500/20 rounded-lg">
                        <MessageCircle className="w-5 h-5 text-green-400" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-base font-semibold mb-1">WhatsApp Support</h3>
                        <a
                          href="https://wa.me/1234567890"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-green-400 hover:text-green-300 text-xs font-medium"
                        >
                          +91 ************
                        </a>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-xl bg-[#121324]/90 border border-blue-500/20 p-4">
                    <p className="text-white/70 text-xs leading-relaxed">
                      <span className="font-semibold text-blue-400">Response Time:</span> We typically respond within 24 hours on business days. Premium subscribers receive priority support.
                    </p>
                  </div>
                </div>
              </div>


            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-4">
              <div className="rounded-2xl bg-[#121324]/90 border border-white/10 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-white/5">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-white/80">Date</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-white/80">Plan</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-white/80">Amount</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-white/80">Status</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-white/80">Invoice</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {paymentHistory.map((payment) => (
                        <tr key={payment.id} className="hover:bg-white/5 transition-colors">
                          <td className="px-6 py-4 text-sm text-white/80">
                            {new Date(payment.date).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 text-sm text-white/80">{payment.plan}</td>
                          <td className="px-6 py-4 text-sm font-semibold text-white">${payment.amount}</td>
                          <td className="px-6 py-4">
                            <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-xs font-medium">
                              {payment.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <button className="text-blue-400 hover:text-blue-300 text-sm font-medium">
                              {payment.invoice}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {paymentHistory.length === 0 && (
                <div className="text-center py-12 text-white/60">
                  <CreditCard className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>No payment history available</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Billing;
