import { X, TrendingUp, TrendingDown, Star, CheckCircle, AlertCircle, Target, BarChart3, Brain } from "lucide-react";
import { useEffect, useState } from "react";

const AuditDialog = ({ isOpen, onClose, auditData, businessName, loading }) => {
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getScoreBackground = (score) => {
    if (score >= 80) return 'from-green-500 to-green-600';
    if (score >= 60) return 'from-yellow-500 to-yellow-600';
    return 'from-red-500 to-red-600';
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'insights', label: 'Insights', icon: Brain },
    { id: 'actions', label: 'Actions', icon: Target }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#1a1b2e] border border-white/10 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">AI Performance Audit</h2>
              <p className="text-sm text-white/60">{businessName}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {loading ? (
          <div className="p-8 text-center">
            <div className="inline-flex items-center space-x-2 text-white/60">
              <div className="w-5 h-5 border-2 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
              <span>Analyzing reviews with AI...</span>
            </div>
          </div>
        ) : auditData ? (
          <>
            {/* Tabs */}
            <div className="flex border-b border-white/10">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-6 py-3 text-sm font-medium transition-colors ${
                    activeTab === tab.id
                      ? 'text-purple-400 border-b-2 border-purple-400 bg-white/5'
                      : 'text-white/60 hover:text-white/80'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>

            <div className="p-6 max-h-[60vh] overflow-y-auto">
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div className="text-center">
                    <div className={`w-24 h-24 mx-auto rounded-full bg-gradient-to-br ${getScoreBackground(auditData.overallScore)} flex items-center justify-center mb-4`}>
                      <span className="text-2xl font-bold text-white">{auditData.overallScore}</span>
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">Overall Performance Score</h3>
                    <p className="text-white/70 max-w-2xl mx-auto">{auditData.summary}</p>
                  </div>

                  <div className="bg-[#121324]/50 rounded-lg p-4">
                    <h4 className="text-sm font-semibold text-white mb-3 flex items-center">
                      <Star className="w-4 h-4 mr-2 text-yellow-400" />
                      Rating Distribution
                    </h4>
                    <div className="space-y-2">
                      {Object.entries(auditData.ratingDistribution || {}).map(([rating, count]) => (
                        <div key={rating} className="flex items-center space-x-3">
                          <span className="w-12 text-xs text-white/60">{rating}</span>
                          <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-purple-500 rounded-full"
                              style={{ 
                                width: `${auditData.reviewCount > 0 ? (count / auditData.reviewCount) * 100 : 0}%` 
                              }}
                            />
                          </div>
                          <span className="w-8 text-xs text-white/60 text-right">{count}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-[#121324]/50 rounded-lg p-4">
                    <h4 className="text-sm font-semibold text-white mb-3">Sentiment Analysis</h4>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-green-400">{auditData.sentimentAnalysis?.positive || '0%'}</div>
                        <div className="text-xs text-white/60">Positive</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-yellow-400">{auditData.sentimentAnalysis?.neutral || '0%'}</div>
                        <div className="text-xs text-white/60">Neutral</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-red-400">{auditData.sentimentAnalysis?.negative || '0%'}</div>
                        <div className="text-xs text-white/60">Negative</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'insights' && (
                <div className="space-y-6">
                  <div className="bg-[#121324]/50 rounded-lg p-4">
                    <h4 className="text-sm font-semibold text-white mb-3 flex items-center">
                      <TrendingUp className="w-4 h-4 mr-2 text-green-400" />
                      Key Strengths
                    </h4>
                    <ul className="space-y-2">
                      {(auditData.strengths || []).map((strength, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-white/80">{strength}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-[#121324]/50 rounded-lg p-4">
                    <h4 className="text-sm font-semibold text-white mb-3 flex items-center">
                      <TrendingDown className="w-4 h-4 mr-2 text-red-400" />
                      Areas for Improvement
                    </h4>
                    <ul className="space-y-2">
                      {(auditData.weaknesses || []).map((weakness, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-white/80">{weakness}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-[#121324]/50 rounded-lg p-4">
                    <h4 className="text-sm font-semibold text-white mb-3">Most Mentioned Topics</h4>
                    <div className="flex flex-wrap gap-2">
                      {(auditData.keyTopics || []).map((topic, index) => (
                        <span 
                          key={index}
                          className="px-3 py-1 bg-purple-500/20 text-purple-300 text-xs rounded-full border border-purple-500/30"
                        >
                          {topic}
                        </span>
                      ))}
                    </div>
                  </div>

                  {auditData.trendAnalysis && (
                    <div className="bg-[#121324]/50 rounded-lg p-4">
                      <h4 className="text-sm font-semibold text-white mb-3">Trend Analysis</h4>
                      <p className="text-sm text-white/80">{auditData.trendAnalysis}</p>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'actions' && (
                <div className="space-y-6">
                  <div className="bg-[#121324]/50 rounded-lg p-4">
                    <h4 className="text-sm font-semibold text-white mb-3 flex items-center">
                      <Target className="w-4 h-4 mr-2 text-orange-400" />
                      Priority Actions
                    </h4>
                    <ul className="space-y-3">
                      {(auditData.priorityActions || []).map((action, index) => (
                        <li key={index} className="flex items-start space-x-3">
                          <div className="w-6 h-6 rounded-full bg-orange-500/20 text-orange-400 text-xs font-bold flex items-center justify-center mt-0.5 flex-shrink-0">
                            {index + 1}
                          </div>
                          <span className="text-sm text-white/80">{action}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-[#121324]/50 rounded-lg p-4">
                    <h4 className="text-sm font-semibold text-white mb-3">Detailed Recommendations</h4>
                    <ul className="space-y-2">
                      {(auditData.recommendations || []).map((recommendation, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <div className="w-2 h-2 rounded-full bg-purple-400 mt-2 flex-shrink-0" />
                          <span className="text-sm text-white/80">{recommendation}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="p-8 text-center">
            <div className="text-white/60">
              <AlertCircle className="w-12 h-12 mx-auto mb-4" />
              <p>No audit data available</p>
            </div>
          </div>
        )}

        {auditData && (
          <div className="px-6 py-4 border-t border-white/10 bg-[#121324]/30">
            <div className="flex items-center justify-between text-xs text-white/60">
              <span>Analysis based on {auditData.reviewCount || 0} reviews</span>
              <span>Generated by AI • {new Date().toLocaleDateString()}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AuditDialog;
