import React, { useState, useContext, useEffect } from "react";
import SideNav from "./SideNav";
import SMSComponent from "./SMSComponent";
import EmailComponent from "./EmailComponent";
import QRCodeComponent from "./QRCodeComponent";
import { SidebarContext } from "../context/SidebarContext";

const InboxMessage = () => {
  const [activeTab, setActiveTab] = useState('sms');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const { isCollapsed } = useContext(SidebarContext);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setMobileSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="min-h-screen w-full text-white">
      <SideNav />

      {mobileSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-20 lg:hidden"
          onClick={() => setMobileSidebarOpen(false)}
        />
      )}

      <div className={`flex-1 transition-all duration-300 ease-in-out h-screen flex flex-col ${
        mobileSidebarOpen ? 'lg:pl-0' : 'pl-0'
      } ${
        isCollapsed ? 'lg:pl-6' : 'lg:pl-50'
      }`}>
        <div className="p-2 sm:p-6 pb-0 flex-shrink-0">
          <div className="flex justify-center gap-1 sm:gap-4 mb-2 sm:mb-6">
            <button 
              onClick={() => setActiveTab('sms')}
              className={`px-2 sm:px-6 py-1 sm:py-2 rounded-lg transition-colors text-xs sm:text-base ${
                activeTab === 'sms' 
                  ? 'bg-purple-600 hover:bg-purple-700' 
                  : 'bg-[#1a1433] hover:bg-[#241b4d]'
              }`}
            >
              SMS
            </button>
            <button 
              onClick={() => setActiveTab('email')}
              className={`px-2 sm:px-6 py-1 sm:py-2 rounded-lg transition-colors text-xs sm:text-base ${
                activeTab === 'email' 
                  ? 'bg-purple-600 hover:bg-purple-700' 
                  : 'bg-[#1a1433] hover:bg-[#241b4d]'
              }`}
            >
              EMAIL
            </button>
            <button 
              onClick={() => setActiveTab('qrcode')}
              className={`px-2 sm:px-6 py-1 sm:py-2 rounded-lg transition-colors text-xs sm:text-base ${
                activeTab === 'qrcode' 
                  ? 'bg-purple-600 hover:bg-purple-700' 
                  : 'bg-[#1a1433] hover:bg-[#241b4d]'
              }`}
            >
              QR CODE
            </button>
          </div>
        </div>

        <main className="flex-1 px-2 sm:px-6 pb-2 sm:pb-6 overflow-y-auto">
          <div className="h-full">
            {activeTab === 'sms' && <SMSComponent />}
            {activeTab === 'email' && <EmailComponent />}
            {activeTab === 'qrcode' && <QRCodeComponent />}
          </div>
        </main>
      </div>
    </div>
  );
};

export default InboxMessage;
