import React, { useState, useContext , useEffect} from "react";
import SideNav from "./SideNav";
import { SidebarContext } from "../context/SidebarContext";
import { useGoogleBusiness } from "../context/GoogleBusinessContext";
import { FaGoogle, FaCalendarAlt, FaClock, FaHistory, FaPlus, FaTrash, FaEdit } from "react-icons/fa";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const BACKEND_URL = import.meta.env.VITE_API_BASE_URL;

const PostCard = ({ post, onEdit, onDelete }) => {

  // console.log("BACKEND_URL  ",BACKEND_URL);
  const formatDate = (date) => {
    return new Date(date).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getDisplayStatus = (status) => {
    if (status === 'scheduled') return `Scheduled for ${formatDate(post.scheduledFor)}`;
    if (status === 'published' && post.statusFromApi === 'processing') return `Status: Processing`;
    if (status === 'published') return `Posted on ${formatDate(post.postedAt)}`;
    return 'Draft';
  };

  return (
    <div className="bg-[#121324]/90 border border-white/5 rounded-xl p-4 mb-4">
      <div className="flex justify-between items-start mb-2">
        <div className="flex items-center gap-2">
          <div className="bg-blue-500/20 p-2 rounded-lg">
            <FaGoogle className="text-blue-400" />
          </div>
          <div>
            <h3 className="font-medium">Google My Business</h3>
            <p className="text-xs text-white/60">
              {getDisplayStatus(post.status)}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => onEdit(post)}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            aria-label="Edit post"
          >
            <FaEdit className="text-blue-400" />
          </button>
          <button 
            onClick={() => onDelete(post.id)}
            className="p-2 hover:bg-red-500/20 rounded-lg transition-colors"
            aria-label="Delete post"
          >
            <FaTrash className="text-red-400" />
          </button>
        </div>
      </div>
      <p className="text-sm text-white/80 whitespace-pre-line">{post.content}</p>
      {post.media && (
        <div className="mt-2 w-32 h-24 bg-gray-700/50 rounded-lg flex items-center justify-center">
          <span className="text-xs text-white/60">Media attached</span>
        </div>
      )}
    </div>
  );
};

const Posts = () => {
  const { isCollapsed } = useContext(SidebarContext);
  const { isConnected: isGoogleConnected, businesses, selectedBusiness } = useGoogleBusiness();
  const [activeTab, setActiveTab] = useState('published'); 
  const [showEditor, setShowEditor] = useState(false);
  const [posts, setPosts] = useState([]);
  
  const [currentPost, setCurrentPost] = useState({
    id: null,
    content: '',
    scheduledFor: null,
    media: null,
    isRecurring: false,
    frequency: 'daily',
    time: '09:00',
    days: [1, 2, 3, 4, 5]
  });

  const [businessDetails, setBusinessDetails] = useState(null);
  
  const fetchPosts = async (accountId, locationId) => {
    try {
      // console.log(`Fetching posts for account ${accountId}, location ${locationId}`);
      const postsResponse = await fetch(
        `${BACKEND_URL}/auth/google/accounts/${accountId}/locations/${locationId}/localPosts`
      );
      
      if (!postsResponse.ok) {
        const errorData = await postsResponse.json();
        throw new Error(errorData.error?.message || 'Failed to fetch posts');
      }
      
      const responseData = await postsResponse.json();
      // console.log('Posts API response:', responseData);
      
      const postsList = responseData.localPosts || responseData.posts || [];
      
      const formattedPosts = postsList.map((post) => {
        const statusFromApi = (post.state || post.status || 'published').toLowerCase();
        
        let normalizedStatus = 'drafts';
        if (statusFromApi === 'live' || statusFromApi === 'posted' || statusFromApi === 'processing') {
          normalizedStatus = 'published';
        } else if (statusFromApi === 'scheduled') {
          normalizedStatus = 'scheduled';
        }

        return {
          id: post.name || post.id,
          content: post.summary || post.content,
          status: normalizedStatus, 
          statusFromApi: statusFromApi, 
          scheduledFor: post.createTime || post.scheduledFor || new Date().toISOString(),
          postedAt: post.createTime || post.postedAt || new Date().toISOString(),
          platform: 'google',
          media: post.media?.[0]?.sourceUrl || post.mediaUrl || null,
        };
      });
      
      // console.log('Formatted posts:', formattedPosts);
      setPosts(formattedPosts);
      return formattedPosts;
    } catch (error) {
      console.error("Error fetching posts:", error);
      return [];
    }
  };

  useEffect(() => {
    if (isGoogleConnected && businesses && businesses.length > 0) {
      const business = selectedBusiness || businesses[0];
      setBusinessDetails(business);

      if (business && business.name) {
        const locationId = business.name.split('/')[1];
        fetchPosts(business.accountId, locationId);
      }
    }
  }, [isGoogleConnected, businesses, selectedBusiness]);

  const handleSavePost = async (e) => {
    e.preventDefault();
    
    if (!businessDetails) {
      alert('No business details available');
      return;
    }

    const locationId = businessDetails.name.split('/')[1];
    const postData = {
      languageCode: 'en-US',
      summary: currentPost.content,
      topicType: 'STANDARD',
      ...(currentPost.media && typeof currentPost.media === 'string' && {
        media: [{
          mediaFormat: 'PHOTO',
          sourceUrl: currentPost.media,
          thumbnail: currentPost.media
        }]
      })
    };

    try {
      const response = await fetch(
        `${BACKEND_URL}/auth/google/accounts/${businessDetails.accountId}/locations/${locationId}/localPosts`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(postData),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || "Failed to create post");
      }

      await fetchPosts(businessDetails.accountId, locationId);
      
      setCurrentPost({
        id: null, content: '', scheduledFor: null, media: null, isRecurring: false, 
        frequency: 'daily', time: '09:00', days: [1, 2, 3, 4, 5]
      });
      
      setShowEditor(false);
      
    } catch (error) {
      console.error("Error creating post:", error);
      alert(`Error creating post: ${error.message}`);
    }
  };

  const handleDeletePost = (id) => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      setPosts(posts.filter(post => post.id !== id));
    }
  };

  const handleEditPost = (post) => {
    setCurrentPost({
      id: post.id,
      content: post.content,
      scheduledFor: post.status === 'scheduled' ? new Date(post.scheduledFor) : null,
      media: post.media || null,
      isRecurring: false, 
      frequency: 'daily',
      time: '09:00',
      days: [1, 2, 3, 4, 5]
    });
    setShowEditor(true);
  };

  const filteredPosts = posts.filter(post => post.status === activeTab);

  return (
    <div className="min-h-screen w-full text-white bg-transparent flex">
      <SideNav />
      <div
        className={`flex-1 p-3 sm:p-6 transition-all duration-300 ease-in-out ${
          isCollapsed ? "md:ml-2" : "md:ml-45"
        } w-full overflow-x-hidden`}
      >
        <div className="max-w-4xl mx-auto w-full">
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <h1 className="text-2xl sm:text-3xl font-bold">Google My Business Posts</h1>
              <div className="flex-shrink-0">
                <button
                  onClick={() => {
                    setCurrentPost({
                      id: null, content: '', scheduledFor: null, media: null, isRecurring: false, 
                      frequency: 'daily', time: '09:00', days: [1, 2, 3, 4, 5]
                    });
                    setShowEditor(true);
                  }}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm font-medium transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed w-full sm:w-auto justify-center"
                  disabled={!isGoogleConnected}
                >
                  <FaPlus /> New Post
                </button>
                {!isGoogleConnected && (
                  <p className="text-xs text-red-400 mt-1 text-center sm:text-right">
                    <a 
                      href="/integrations" 
                      className="hover:text-red-300 underline transition-colors"
                    >
                      Connect to Google
                    </a> to create posts.
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="border-b border-white/10 mb-6 bg-[#1a1b2e]/50 backdrop-blur-sm rounded-t-lg">
            <div className="flex overflow-x-auto scrollbar-hide px-2 py-2">
              {['scheduled', 'published', 'drafts'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-2 text-sm font-medium whitespace-nowrap flex-shrink-0 rounded-lg mx-1 transition-all duration-200 ${
                    activeTab === tab
                      ? 'text-white bg-blue-600 shadow-lg'
                      : 'text-white/70 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                  <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                    activeTab === tab 
                      ? 'bg-white/20 text-white' 
                      : 'bg-white/10 text-white/60'
                  }`}>
                    {posts.filter(p => p.status === tab).length}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            {!isGoogleConnected ? (
              <div className="text-center py-12">
                <div className="bg-gradient-to-r from-blue-600/20 to-indigo-600/20 border border-blue-500/30 rounded-xl p-8">
                  <FaGoogle className="mx-auto text-5xl mb-4 text-blue-400" />
                  <h3 className="text-xl font-semibold mb-2 text-white">Connect Your Google Business</h3>
                  <p className="text-white/60 mb-6 max-w-md mx-auto">
                    Connect your Google My Business account to create, schedule, and manage posts directly from here.
                  </p>
                  <a 
                    href="/integrations"
                    className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
                  >
                    <FaGoogle /> Connect Google Business
                  </a>
                </div>
              </div>
            ) : filteredPosts.length > 0 ? (
              filteredPosts.map((post) => (
                <PostCard 
                  key={post.id} 
                  post={post} 
                  onEdit={handleEditPost}
                  onDelete={handleDeletePost}
                />
              ))
            ) : (
              <div className="text-center py-12 text-white/50">
                <FaHistory className="mx-auto text-4xl mb-3 opacity-30" />
                <p>No {activeTab} posts found</p>
              </div>
            )}
          </div>
        </div>

        {showEditor && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
            <div className="bg-[#121324] rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">
                    {currentPost.id ? 'Edit Post' : 'Create New Post'}
                  </h2>
                  <button 
                    onClick={() => setShowEditor(false)}
                    className="text-white/60 hover:text-white"
                  >
                    ✕
                  </button>
                </div>

                <form onSubmit={handleSavePost}>
                  <div className="mb-6">
                    <label className="block text-sm font-medium mb-2">Post Content</label>
                    <textarea
                      value={currentPost.content}
                      onChange={(e) => setCurrentPost({...currentPost, content: e.target.value})}
                      className="w-full bg-[#1a1a2e] border border-white/10 rounded-lg p-3 text-white/90 h-40 resize-none"
                      placeholder="What would you like to post?"
                      required
                    />
                    <div className="text-xs text-white/50 mt-1">
                      {currentPost.content.length}/1500 characters
                    </div>
                  </div>

                  <div className="mb-6">
                    <label className="block text-sm font-medium mb-2">Add Media (Optional)</label>
                    <div className="border-2 border-dashed border-white/20 rounded-lg p-8 text-center cursor-pointer hover:bg-white/5 transition-colors">
                      <div className="flex flex-col items-center">
                        <FaPlus className="text-2xl mb-2 opacity-60" />
                        <p className="text-sm">Click to upload or drag and drop</p>
                        <p className="text-xs text-white/50 mt-1">JPG, PNG up to 10MB</p>
                      </div>
                      <input 
                        type="file" 
                        className="hidden" 
                        accept="image/*"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            setCurrentPost({...currentPost, media: e.target.files[0]});
                          }
                        }}
                      />
                    </div>
                  </div>

                  <div className="mb-6">
                    <label className="flex items-center gap-2 mb-4">
                      <input 
                        type="checkbox" 
                        checked={currentPost.scheduledFor !== null}
                        onChange={(e) => {
                          setCurrentPost({
                            ...currentPost, 
                            scheduledFor: e.target.checked ? new Date() : null,
                            isRecurring: e.target.checked ? currentPost.isRecurring : false,
                          });
                        }}
                        className="rounded border-white/20"
                      />
                      <span className="text-sm font-medium">Schedule for later</span>
                    </label>

                    {currentPost.scheduledFor && (
                      <div className="pl-6 space-y-4">
                        <div>
                          <label className="block text-sm font-medium mb-2">Date & Time</label>
                          <div className="flex gap-4">
                            <div className="flex-1 relative">
                              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <FaCalendarAlt className="text-white/50" />
                              </div>
                              <DatePicker
                                selected={currentPost.scheduledFor}
                                onChange={(date) => setCurrentPost({...currentPost, scheduledFor: date})}
                                showTimeSelect
                                timeFormat="HH:mm"
                                timeIntervals={15}
                                dateFormat="MMMM d, yyyy h:mm aa"
                                className="w-full bg-[#1a1a2e] border border-white/10 rounded-lg pl-10 pr-3 py-2 text-white/90"
                                minDate={new Date()}
                              />
                            </div>
                          </div>
                        </div>

                        <div>
                          <label className="flex items-center gap-2 mb-2">
                            <input 
                              type="checkbox" 
                              checked={currentPost.isRecurring}
                              onChange={(e) => {
                                setCurrentPost({
                                  ...currentPost, 
                                  isRecurring: e.target.checked
                                });
                              }}
                              className="rounded border-white/20"
                            />
                            <span className="text-sm font-medium">Repeat post</span>
                          </label>

                          {currentPost.isRecurring && (
                            <div className="pl-6 space-y-3">
                              <div>
                                <label className="block text-sm font-medium mb-1">Frequency</label>
                                <select
                                  value={currentPost.frequency}
                                  onChange={(e) => setCurrentPost({...currentPost, frequency: e.target.value})}
                                  className="w-full bg-[#1a1a2e] border border-white/10 rounded-lg px-3 py-2 text-white/90"
                                >
                                  <option value="daily">Daily</option>
                                  <option value="weekly">Weekly</option>
                                  <option value="monthly">Monthly</option>
                                </select>
                              </div>

                              <div>
                                <label className="block text-sm font-medium mb-1">Time</label>
                                <div className="relative">
                                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <FaClock className="text-white/50" />
                                  </div>
                                  <input
                                    type="time"
                                    value={currentPost.time}
                                    onChange={(e) => setCurrentPost({...currentPost, time: e.target.value})}
                                    className="w-full bg-[#1a1a2e] border border-white/10 rounded-lg pl-10 pr-3 py-2 text-white/90"
                                  />
                                </div>
                              </div>

                              {currentPost.frequency === 'weekly' && (
                                <div>
                                  <label className="block text-sm font-medium mb-1">Days of the week</label>
                                  <div className="flex flex-wrap gap-2">
                                    {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, index) => (
                                      <button
                                        key={day}
                                        type="button"
                                        onClick={() => {
                                          const days = [...currentPost.days];
                                          const dayIndex = days.indexOf(index);
                                          
                                          if (dayIndex === -1) {
                                            days.push(index);
                                          } else {
                                            days.splice(dayIndex, 1);
                                          }
                                          
                                          setCurrentPost({
                                            ...currentPost,
                                            days: days.sort((a, b) => a - b)
                                          });
                                        }}
                                        className={`px-3 py-1 text-sm rounded-full ${
                                          currentPost.days.includes(index)
                                            ? 'bg-blue-600 text-white'
                                            : 'bg-white/5 text-white/60 hover:bg-white/10'
                                        }`}
                                      >
                                        {day}
                                      </button>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
                    <button
                      type="button"
                      onClick={() => setShowEditor(false)}
                      className="px-4 py-2 rounded-lg border border-white/20 text-sm font-medium hover:bg-white/5 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-sm font-medium transition-colors"
                    >
                      {currentPost.id ? 'Update' : 'Schedule'} Post
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Posts;