import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import axios from 'axios';
import { FaArrowLeft } from 'react-icons/fa';

const ForgotPassword = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    if (!email.trim()) {
      setError('Email is required');
      return;
    }
    
    if (!validateEmail(email)) {
      setError('Please enter a valid email address');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post('/api/auth/forgot-password', { email });
      if (response.status === 200) {
        setSuccess(true);
        toast.success('Password reset link sent to your email');
      }
    } catch (err) {
      const errorMessage = err.response?.data?.error || 
                         err.response?.data?.message || 
                         'Failed to send reset link. Please try again.';
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#0f0f1a] text-white px-4">
      <div className="text-center mb-10 sm:mt-10 mt-20">
        <h2 className="text-3xl md:text-4xl font-bold text-white uppercase">Forgot Your</h2>
        <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-purple-600 mt-2">
          Password?
        </h1>
      </div>

      <div className="w-full max-w-md bg-[#181818] rounded-xl shadow-2xl p-8 space-y-6">
        <div>
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-purple-400 hover:text-purple-300 mb-4 transition-colors"
          >
            <FaArrowLeft className="mr-2" /> Back to Login
          </button>
          <p className="text-center text-gray-300 mb-6">
            {success 
              ? 'We\'ve sent a password reset link to your email.'
              : 'Enter your email and we\'ll send you a link to reset your password.'}
          </p>
        </div>

        {!success ? (
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <label htmlFor="email-address" className="sr-only">
                  Email address
                </label>
                <input
                  id="email-address"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#121212] border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-purple-500 text-white placeholder-gray-400"
                  placeholder="Enter your email address"
                />
              </div>
            </div>

            {error && (
              <div className="text-red-400 text-sm p-3 bg-red-900/30 border border-red-800 rounded-lg">
                {error}
              </div>
            )}

            <div>
              <button
                type="submit"
                disabled={loading}
                className={`w-full py-3 px-4 rounded-lg font-semibold text-white transition-colors ${
                  loading
                    ? 'bg-purple-600/50 cursor-not-allowed'
                    : 'bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-600 hover:to-purple-800 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-[#181818]'
                }`}
              >
                {loading ? 'Sending...' : 'Send Reset Link'}
              </button>
            </div>
          </form>
        ) : (
          <div className="text-center py-4">
            <div className="mb-6">
              <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-900/30 border border-green-800">
                <svg className="h-8 w-8 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            </div>
            <p className="text-gray-300 mb-6">
              Check your email for the password reset link. If you don't see it, please check your spam folder.
            </p>
            <button
              onClick={() => setSuccess(false)}
              className="text-purple-400 hover:text-purple-300 font-medium transition-colors"
            >
              Didn't receive an email? Resend
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ForgotPassword;