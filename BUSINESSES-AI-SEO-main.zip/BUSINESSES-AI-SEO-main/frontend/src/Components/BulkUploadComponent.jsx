import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { FaUpload, FaFileCsv, FaSpinner, FaCheckCircle } from 'react-icons/fa';
import { getAuth } from 'firebase/auth';

export const BulkUploadComponent = ({ onUploadComplete }) => {
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [businesses, setBusinesses] = useState([]);
  const [selectedBusinessId, setSelectedBusinessId] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [uploadResult, setUploadResult] = useState(null);

  useEffect(() => {
    const fetchBusinesses = async () => {
      try {
        const auth = getAuth();
        const currentUser = auth.currentUser;
        if (!currentUser) throw new Error('No authenticated user found');
        
        const token = await currentUser.getIdToken();

        const response = await fetch('/api/business/all-business', {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          credentials: 'include'
        });
        
        if (!response.ok) throw new Error('Failed to fetch businesses');
        
        const data = await response.json();
        setBusinesses(data.businesses || []);
        if (data.businesses?.length > 0) {
          setSelectedBusinessId(data.businesses[0].id);
        }
      } catch (error) {
        console.error('Error:', error);
        toast.error(error.message || 'Failed to load business information');
      } finally {
        setIsLoading(false);
      }
    };

    fetchBusinesses();
  }, []);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type === 'text/csv') {
      setSelectedFile(file);
      setUploadResult(null); 
    } else {
      toast.error('Please upload a valid CSV file');
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      toast.error('Please select a CSV file first');
      return;
    }

    if (!selectedBusinessId) {
      toast.error('Please select a business');
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);
    formData.append('businessId', selectedBusinessId);

    setIsUploading(true);

    try {
      const auth = getAuth();
      const currentUser = auth.currentUser;
      if (!currentUser) throw new Error('No authenticated user found');
      
      const token = await currentUser.getIdToken();
      
      const response = await fetch('/api/invitations/bulk-upload', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        credentials: 'include',
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to process bulk upload');
      }

      const result = await response.json();
      setUploadResult(result);
      toast.success(`Successfully processed ${result.successful} out of ${result.total} invitations`);
      
      if (result.failed > 0) {
        toast.warning(`${result.failed} invitations failed to send`);
      }

      if (typeof onUploadComplete === 'function') {
        onUploadComplete(result);
      }
    } catch (error) {
      console.error('Bulk upload error:', error);
      toast.error(error.message || 'Failed to process bulk upload');
    } finally {
      setIsUploading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow mb-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Bulk Upload Contacts</h3>
      
      <div className="space-y-4">
        <div>
          <label htmlFor="business-select" className="block text-sm font-medium text-gray-700 mb-1">
            Select Business
          </label>
          <select
            id="business-select"
            value={selectedBusinessId}
            onChange={(e) => setSelectedBusinessId(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            disabled={isUploading}
          >
            {businesses.map((business) => (
              <option key={business.id} value={business.id}>
                {business.name}
              </option>
            ))}
          </select>
        </div>

        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
          <div className="space-y-1 text-center">
            <FaFileCsv className="mx-auto h-12 w-12 text-gray-400" />
            <div className="flex text-sm text-gray-600 justify-center">
              <label
                htmlFor="file-upload"
                className="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none"
              >
                <span>Upload a file</span>
                <input
                  id="file-upload"
                  name="file-upload"
                  type="file"
                  className="sr-only"
                  accept=".csv,text/csv"
                  onChange={handleFileChange}
                  disabled={isUploading}
                />
              </label>
              <p className="pl-1">or drag and drop</p>
            </div>
            <p className="text-xs text-gray-500">
              {selectedFile 
                ? `Selected: ${selectedFile.name}` 
                : "CSV up to 10MB with columns: customerName,customerEmail"}
            </p>
          </div>
        </div>

        {uploadResult && (
          <div className="mt-4 p-4 bg-green-50 rounded-md">
            <div className="flex items-center">
              <FaCheckCircle className="h-5 w-5 text-green-500 mr-2" />
              <p className="text-sm text-green-700">
                Processed {uploadResult.successful} out of {uploadResult.total} invitations successfully.
                {uploadResult.failed > 0 && ` ${uploadResult.failed} failed.`}
              </p>
            </div>
          </div>
        )}

        <div className="flex justify-end">
          <button
            type="button"
            onClick={handleUpload}
            disabled={!selectedFile || isUploading}
            className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${
              !selectedFile || isUploading
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-700'
            } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
          >
            {isUploading ? (
              <>
                <FaSpinner className="animate-spin -ml-1 mr-2 h-4 w-4" />
                Processing...
              </>
            ) : (
              <>
                <FaUpload className="-ml-1 mr-2 h-4 w-4" />
                Upload & Send Invitations
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default BulkUploadComponent;