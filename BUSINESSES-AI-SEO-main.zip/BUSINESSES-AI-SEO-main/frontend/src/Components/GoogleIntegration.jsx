import React, { useState, useEffect } from "react";
import axios from "axios";

const GoogleIntegration = () => {
  const [user, setUser] = useState(null);
  const [businesses, setBusinesses] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [loading, setLoading] = useState(false);

  const BACKEND_URL = import.meta.env.VITE_API_BASE_URL?.replace(/\/$/, '') || "http://localhost:8000";

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const success = urlParams.get('success');
    const userEmail = urlParams.get('user');
    
    if (success === 'true' && userEmail) {
      window.history.replaceState({}, document.title, window.location.pathname);
      handleFetchBusinesses();
    }
  }, []);

  const handleConnect = () => {
    window.location.href = `${BACKEND_URL}/auth/google/login`;
  };

  const handleFetchBusinesses = async () => {
    try {
      setLoading(true);
      const res = await axios.get(`${BACKEND_URL}/auth/google/businesses`);
      setUser(res.data.user);
      setBusinesses(res.data.businesses || []);
    } catch (error) {
      console.error(error);
      alert("Error fetching Google business data");
    } finally {
      setLoading(false);
    }
  };

  const checkAuthStatus = async () => {
    try {
      const res = await axios.get(`${BACKEND_URL}/auth/google/status`);
      if (res.data.authenticated) {
        setUser(res.data.user);
        handleFetchBusinesses();
      }
    } catch (error) {
      console.error("Auth check failed:", error);
    }
  };

  useEffect(() => {
    checkAuthStatus();
  }, []);


  const handleFetchReviews = async (accountId, locationId) => {
    try {
      setLoading(true);
      const res = await axios.get(
        `${BACKEND_URL}/auth/google/reviews/${accountId}/${locationId}`
      );
      setReviews(res.data.reviews || []);
      setSelectedLocation(locationId);
    } catch (error) {
      console.error(error);
      alert("Error fetching reviews");
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      setLoading(true);
      await axios.post(`${BACKEND_URL}/auth/google/disconnect`);
      
      setUser(null);
      setBusinesses([]);
      setReviews([]);
      setSelectedLocation(null);
      
      alert("Google account disconnected successfully!");
    } catch (error) {
      console.error(error);
      alert("Error disconnecting Google account");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-6 bg-gray-50 text-gray-800">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6 text-center">
          📍 Google Business Integration
        </h1>

        {!user ? (
          <div className="flex flex-col items-center space-y-4">
            <button
              onClick={handleConnect}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-3 rounded-md"
            >
              Connect Google Business
            </button>

            <p className="text-gray-600">
              Connect करने के बाद आपके businesses automatically load हो जाएंगे।
            </p>
          </div>
        ) : (
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">
                Welcome, {user.name || user.email}
              </h2>
              <button
                onClick={handleDisconnect}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm"
              >
                Disconnect Google
              </button>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-semibold mb-2">
                Your Google Business Locations
              </h3>
              {businesses.length === 0 ? (
                <p className="text-gray-500">No businesses found.</p>
              ) : (
                businesses.map((b, index) => {
                  const parts = b.name.split("/");
                  const accountId = parts[1];
                  const locationId = parts[3];

                  return (
                    <div
                      key={index}
                      className="border p-4 rounded-md shadow-sm bg-white"
                    >
                      <h4 className="font-bold">{b.title}</h4>
                      <p className="text-sm text-gray-600">
                        Location ID: {locationId}
                      </p>

                      <button
                        onClick={() =>
                          handleFetchReviews(accountId, locationId)
                        }
                        className="mt-3 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md"
                      >
                        View Reviews
                      </button>
                    </div>
                  );
                })
              )}
            </div>

            {reviews.length > 0 && (
              <div className="mt-8">
                <h3 className="text-xl font-semibold mb-2">
                  Reviews for Location: {selectedLocation}
                </h3>
                {reviews.map((r, i) => (
                  <div
                    key={i}
                    className="border p-4 rounded-md bg-white mb-3 shadow-sm"
                  >
                    <p>
                      ⭐ <strong>{r.starRating}</strong>
                    </p>
                    <p className="text-gray-700">{r.comment}</p>
                    <p className="text-sm text-gray-500">
                      — {r.reviewer?.displayName || "Anonymous"}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {loading && (
          <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center">
            <div className="bg-white px-6 py-4 rounded-md shadow-md">
              <p className="font-semibold">Loading...</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default GoogleIntegration;
