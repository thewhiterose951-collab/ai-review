import React, { useState, useContext } from "react";
import { RefreshCw, Star, Filter, Copy } from "lucide-react";
import { useSidebar } from "../context/SidebarContext";
import SideNav from "./SideNav";


export default function WebsiteWidgets() {
  const { isCollapsed } = useSidebar();
  const [activeTab, setActiveTab] = useState("Carousel");
  const [toggles, setToggles] = useState({
    removePoweredBy: false,
    darkMode: false,
    hideScore: false,
    hideReviewData: false,
    showOnlyHighRatings: false,
    feedback: false,
  });

  const handleToggle = (key) => {
    setToggles((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-[#1b1730] to-[#120f25] text-white">
        <SideNav />
      <div className={`flex-1 transition-all duration-300 ${isCollapsed ? 'lg:ml-2' : 'lg:ml-45'}`}>
        <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Website Widgets</h2>

      <div className="flex gap-6 mb-6">
        {["Carousel", "Feed", "Video"].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-6 py-2 rounded-lg text-sm font-medium ${
              activeTab === tab ? "bg-purple-700" : "bg-[#1e1e3a]"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="border border-purple-800 rounded-lg p-10 text-center">
        <Star className="w-10 h-10 text-yellow-400 mx-auto mb-4" />
        <p className="mb-4">No Review Are Currently Available</p>
        <button className="px-6 py-2 rounded-lg bg-[#1e1e3a] hover:bg-purple-700 transition flex items-center gap-2 mx-auto">
          <RefreshCw className="w-4 h-4" /> Reload
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <div className="bg-[#1e1e3a] rounded-lg p-5 space-y-4">
          <button className="flex items-center gap-2 mb-4 px-3 py-1 bg-black/40 rounded-md text-sm">
            <Filter className="w-4 h-4" /> FILTER
          </button>

          {[
            { key: "removePoweredBy", label: "Remove Powered By" },
            { key: "darkMode", label: "Dark Mode" },
            { key: "hideScore", label: "Hide Score" },
            { key: "hideReviewData", label: "Hide Review Data" },
            { key: "showOnlyHighRatings", label: "Show Only 4–5 Star Rating" },
          ].map((item) => (
            <label
              key={item.key}
              className="flex items-center justify-between text-sm"
            >
              {item.label}
              <input
                type="checkbox"
                checked={toggles[item.key]}
                onChange={() => handleToggle(item.key)}
                className="toggle-checkbox"
              />
            </label>
          ))}
        </div>

        <div className="bg-[#1e1e3a] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <span>Integrations</span>
            <label className="flex items-center gap-2 text-sm">
              Feedback
              <input
                type="checkbox"
                checked={toggles.feedback}
                onChange={() => handleToggle("feedback")}
                className="toggle-checkbox"
              />
            </label>
          </div>

          <div>
            <p className="mb-2 text-sm font-medium">HTML Code</p>
            <div className="flex items-center justify-between bg-black/30 px-3 py-2 rounded-md text-xs font-mono">
              <span>&lt;h1 class="hero"&gt;Effortlessly boost your online...&lt;/h1&gt;</span>
              <button>
                <Copy className="w-4 h-4 text-gray-400 hover:text-white" />
              </button>
            </div>
          </div>

          <p className="text-xs text-gray-400 border border-purple-800 rounded-md p-3">
            To get started with our AI Review Generator and SEO Optimization
            platform, simply copy and paste the following code as HTML into your
            project. This will allow you to quickly display AI-powered review
            suggestions and SEO-friendly content blocks on your website, helping
            your business improve its online reputation, engage with customers,
            and boost search rankings effortlessly.
          </p>
        </div>
          </div>
        </div>
      </div>
    </div>
  );
}
