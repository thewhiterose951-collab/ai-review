import { auth } from '../config/firebase';

const refreshToken = async () => {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('No authenticated user');
    }
    const idToken = await currentUser.getIdToken(true);
    localStorage.setItem('token', idToken);
    
    return idToken;
  } catch (error) {
    console.error('Error refreshing token:', error);
    localStorage.removeItem('token');
    window.location.href = '/login';
    throw error;
  }
};

const fetchWithAuth = async (url, options = {}) => {
  let token = localStorage.getItem('token');
  
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  let response = await fetch(url, {
    ...options,
    headers,
  });

  if (response.status === 401) {
    try {
      const newToken = await refreshToken();
      headers['Authorization'] = `Bearer ${newToken}`;
      
      response = await fetch(url, {
        ...options,
        headers,
      });
    } catch (error) {
      console.error('Failed to refresh token:', error);
      window.location.href = '/login';
      return Promise.reject(new Error('Authentication failed'));
    }
  }

  return response;
};

export default fetchWithAuth;
