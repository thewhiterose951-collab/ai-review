import React, { createContext, useState, useContext } from 'react';

const SidebarContext = createContext();

export const SidebarProvider = ({ children }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  const toggleMobileSidebar = () => {
    const isMobile = window.innerWidth < 1024;
    if (isMobile) {
      setMobileOpen(!mobileOpen);
      // Force expand sidebar on mobile when opening
      if (!mobileOpen) {
        setIsCollapsed(false);
      }
    }
  };

  const closeMobileSidebar = () => {
    setMobileOpen(false);
  };

  return (
    <SidebarContext.Provider value={{
      isCollapsed,
      mobileOpen,
      toggleSidebar,
      toggleMobileSidebar,
      closeMobileSidebar,
      setMobileOpen
    }}>
      {children}
    </SidebarContext.Provider>
  );
};

export const useSidebar = () => {
  const context = useContext(SidebarContext);
  if (!context) {
    throw new Error('useSidebar must be used within a SidebarProvider');
  }
  return context;
};

export { SidebarContext };
export default SidebarContext;
