import React, { createContext, useState, useEffect } from 'react';

export const AuthContext = createContext();

// Helper function to safely get and parse user from localStorage
export const getStoredUser = () => {
  try {
    const storedUser = localStorage.getItem('user');
    return storedUser ? JSON.parse(storedUser) : null;
  } catch (error) {
    console.error('Failed to parse stored user', error);
    return null;
  }
};

// Create and export the useAuth hook
export const useAuth = () => {
  const context = React.useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(() => getStoredUser());
    const [isLoading, setIsLoading] = useState(true);
    useEffect(() => {
        if (user) {
            localStorage.setItem('user', JSON.stringify(user));
        } else {
            localStorage.removeItem('user');
        }
    }, [user]);

    // console.log('AuthContext  user:', user);
    const login = (userData) => {
        setUser(userData);
    };

    const logout = () => {
        setUser(null);
    };

    const validateSession = async () => {
        try {
            setIsLoading(false);
            return true;
        } catch (error) {
            console.error('Session validation failed:', error);
            logout();
            setIsLoading(false);
            return false;
        }
    };

    useEffect(() => {
        if (user) {
            validateSession();
        } else {
            setIsLoading(false);
        }
    }, []);

    return (
        <AuthContext.Provider value={{ user, login, logout, isLoading }}>
            {!isLoading ? children : <div>Loading...</div>}
        </AuthContext.Provider>
    );
};
