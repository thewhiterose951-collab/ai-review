import { Toaster } from 'sonner';

const SonnerProvider = () => {
  return <Toaster richColors position="top-center" />;
};

export default SonnerProvider;
