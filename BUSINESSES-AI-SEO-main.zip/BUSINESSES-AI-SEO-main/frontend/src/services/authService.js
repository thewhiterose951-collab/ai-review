// frontend/src/services/authService.js
import { 
  signInWithEmailAndPassword, 
  signInWithCustomToken,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  getIdToken
} from 'firebase/auth';
import { auth } from '../config/firebase';
import apiClient from './apiClient';

class AuthService {
  constructor() {
    this.currentUser = null;
    this.listeners = new Set();
    
    // Listen to Firebase auth state changes
    onAuthStateChanged(auth, (user) => {
      this.currentUser = user;
      this.notifyListeners(user);
    });
  }

  // Add auth state listener
  addAuthStateListener(callback) {
    this.listeners.add(callback);
    // Call immediately with current state
    callback(this.currentUser);
    
    // Return unsubscribe function
    return () => this.listeners.delete(callback);
  }

  // Notify all listeners of auth state change
  notifyListeners(user) {
    this.listeners.forEach(callback => callback(user));
  }

  // Sign up with email and password
  async signup(userData) {
    try {
      console.log('Starting signup process...');
      
      const response = await apiClient.post('/auth/signup', userData);
      
      if (response.customToken) {
        // Sign in with the custom token from backend
        console.log('Signing in with custom token...');
        const userCredential = await signInWithCustomToken(auth, response.customToken);
        
        return {
          success: true,
          user: response.user,
          firebaseUser: userCredential.user
        };
      }
      
      return { 
        success: true, 
        user: response.user,
        message: response.message
      };
      
    } catch (error) {
      console.error('Signup error:', error);
      
      // Handle specific error codes from backend
      if (error.message.includes('USER_EXISTS')) {
        return { 
          success: false, 
          error: 'An account with this email already exists' 
        };
      }
      
      if (error.message.includes('INVALID_EMAIL')) {
        return { 
          success: false, 
          error: 'Please enter a valid email address' 
        };
      }
      
      if (error.message.includes('WEAK_PASSWORD')) {
        return { 
          success: false, 
          error: 'Password should be at least 6 characters' 
        };
      }
      
      return { 
        success: false, 
        error: error.message || 'Signup failed. Please try again.' 
      };
    }
  }

  // Login with email and password
  async login(email, password) {
    try {
      console.log('Starting login process...');
      
      // First, get custom token from backend
      const response = await apiClient.post('/auth/login', { email, password });
      
      if (response.customToken) {
        // Sign in with custom token
        console.log('Signing in with custom token...');
        const userCredential = await signInWithCustomToken(auth, response.customToken);
        
        // Store user data in localStorage for persistence
        localStorage.setItem('userData', JSON.stringify(response.user));
        
        return {
          success: true,
          user: response.user,
          firebaseUser: userCredential.user
        };
      }
      
      return { 
        success: false, 
        error: 'Authentication failed' 
      };
      
    } catch (error) {
      console.error('Login error:', error);
      
      // Handle specific error codes
      if (error.message.includes('USER_NOT_FOUND')) {
        return { 
          success: false, 
          error: 'No account found with this email address' 
        };
      }
      
      if (error.message.includes('INVALID_PASSWORD')) {
        return { 
          success: false, 
          error: 'Incorrect password' 
        };
      }
      
      return { 
        success: false, 
        error: error.message || 'Login failed. Please try again.' 
      };
    }
  }

  // Logout
  async logout() {
    try {
      console.log('Logging out...');
      
      // Call backend logout endpoint
      await apiClient.post('/auth/logout', {}, true);
      
      // Sign out from Firebase
      await firebaseSignOut(auth);
      
      // Clear local storage
      localStorage.removeItem('userData');
      
      return { success: true };
      
    } catch (error) {
      console.error('Logout error:', error);
      
      // Even if backend call fails, still sign out from Firebase
      try {
        await firebaseSignOut(auth);
        localStorage.removeItem('userData');
      } catch (firebaseError) {
        console.error('Firebase signout error:', firebaseError);
      }
      
      return { 
        success: false, 
        error: error.message || 'Logout failed' 
      };
    }
  }

  // Get user profile
  async getProfile() {
    try {
      console.log('Fetching user profile...');
      
      const response = await apiClient.get('/auth/profile', true);
      
      return {
        success: true,
        user: response.user
      };
      
    } catch (error) {
      console.error('Get profile error:', error);
      
      return {
        success: false,
        error: error.message || 'Failed to fetch profile'
      };
    }
  }

  // Update user profile
  async updateProfile(profileData) {
    try {
      console.log('Updating user profile...');
      
      const response = await apiClient.put('/auth/profile', profileData, true);
      
      // Update local storage
      const userData = JSON.parse(localStorage.getItem('userData') || '{}');
      const updatedUserData = { ...userData, ...response.user };
      localStorage.setItem('userData', JSON.stringify(updatedUserData));
      
      return {
        success: true,
        user: response.user,
        message: response.message
      };
      
    } catch (error) {
      console.error('Update profile error:', error);
      
      return {
        success: false,
        error: error.message || 'Failed to update profile'
      };
    }
  }

  // Forgot password
  async forgotPassword(email) {
    try {
      console.log('Sending password reset email...');
      
      const response = await apiClient.post('/auth/forgot-password', { email });
      
      return {
        success: true,
        message: response.message
      };
      
    } catch (error) {
      console.error('Forgot password error:', error);
      
      return {
        success: false,
        error: error.message || 'Failed to send reset email'
      };
    }
  }

  // Reset password
  async resetPassword(oobCode, newPassword) {
    try {
      console.log('Resetting password...');
      
      const response = await apiClient.post('/auth/reset-password', {
        oobCode,
        newPassword
      });
      
      return {
        success: true,
        message: response.message
      };
      
    } catch (error) {
      console.error('Reset password error:', error);
      
      return {
        success: false,
        error: error.message || 'Failed to reset password'
      };
    }
  }

  // Verify email
  async verifyEmail(oobCode) {
    try {
      console.log('Verifying email...');
      
      const response = await apiClient.post('/auth/verify-email', { oobCode });
      
      return {
        success: true,
        message: response.message
      };
      
    } catch (error) {
      console.error('Email verification error:', error);
      
      return {
        success: false,
        error: error.message || 'Email verification failed'
      };
    }
  }

  // Get current user from localStorage
  getCurrentUser() {
    try {
      const userData = localStorage.getItem('userData');
      return userData ? JSON.parse(userData) : null;
    } catch (error) {
      console.error('Error getting current user:', error);
      return null;
    }
  }

  // Check if user is authenticated
  isAuthenticated() {
    return !!this.currentUser && !!this.getCurrentUser();
  }

  // Get Firebase ID token
  async getIdToken() {
    try {
      if (this.currentUser) {
        return await getIdToken(this.currentUser);
      }
      return null;
    } catch (error) {
      console.error('Error getting ID token:', error);
      return null;
    }
  }
}

// Create and export singleton instance
const authService = new AuthService();
export default authService;