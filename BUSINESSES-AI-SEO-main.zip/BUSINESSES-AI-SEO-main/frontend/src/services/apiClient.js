// frontend/src/services/apiClient.js
import { auth } from '../config/firebase';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ;

class ApiClient {
  constructor() {
    this.baseURL = API_BASE_URL;
  }

  // Get authorization headers with Firebase token
  async getAuthHeaders() {
    try {
      const user = auth.currentUser;
      if (user) {
        const token = await user.getIdToken();
        return {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        };
      }
      return {
        'Content-Type': 'application/json',
      };
    } catch (error) {
      console.error('Error getting auth token:', error);
      return {
        'Content-Type': 'application/json',
      };
    }
  }

  // Generic request method
  async request(endpoint, options = {}) {
    try {
      const url = `${this.baseURL}${endpoint}`;
      const headers = options.requireAuth ? await this.getAuthHeaders() : {
        'Content-Type': 'application/json',
      };

      const config = {
        headers,
        ...options,
      };

      // Don't stringify if it's FormData
      if (config.body && !(config.body instanceof FormData)) {
        config.body = JSON.stringify(config.body);
      }

      console.log('Making API request:', {
        url,
        method: config.method || 'GET',
        headers: config.headers,
      });

      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP Error: ${response.status}`);
      }

      const data = await response.json();
      console.log('API response:', data);
      return data;

    } catch (error) {
      console.error('API request failed:', {
        endpoint,
        error: error.message,
      });
      throw error;
    }
  }

  // HTTP Methods
  async get(endpoint, requireAuth = false) {
    return this.request(endpoint, {
      method: 'GET',
      requireAuth,
    });
  }

  async post(endpoint, data, requireAuth = false) {
    return this.request(endpoint, {
      method: 'POST',
      body: data,
      requireAuth,
    });
  }

  async put(endpoint, data, requireAuth = false) {
    return this.request(endpoint, {
      method: 'PUT',
      body: data,
      requireAuth,
    });
  }

  async delete(endpoint, requireAuth = false) {
    return this.request(endpoint, {
      method: 'DELETE',
      requireAuth,
    });
  }

  async patch(endpoint, data, requireAuth = false) {
    return this.request(endpoint, {
      method: 'PATCH',
      body: data,
      requireAuth,
    });
  }
}

// Create and export singleton instance
const apiClient = new ApiClient();
export default apiClient;