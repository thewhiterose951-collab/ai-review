// frontend/src/services/businessService.js
import apiClient from './apiClient';

class BusinessService {
  // Register a new business
  async registerBusiness(businessData) {
    try {
      console.log('Registering business:', businessData);
      const response = await apiClient.post('/business/register', businessData, true);
      return {
        success: true,
        business: response.business,
        message: response.message
      };
    } catch (error) {
      console.error('Register business error:', error);
      return {
        success: false,
        error: error.message || 'Failed to register business'
      };
    }
  }

  // Get all businesses for the current user
  async getMyBusinesses() {
    try {
      console.log('Fetching user businesses...');
      const response = await apiClient.get('/business/', true);
      return {
        success: true,
        businesses: response.businesses,
        count: response.count
      };
    } catch (error) {
      console.error('Get businesses error:', error);
      return {
        success: false,
        error: error.message || 'Failed to fetch businesses'
      };
    }
  }

  // Get single business by ID
  async getBusinessById(businessId) {
    try {
      console.log('Fetching business:', businessId);
      const response = await apiClient.get(`/business/${businessId}`, true);
      return {
        success: true,
        business: response.business
      };
    } catch (error) {
      console.error('Get business error:', error);
      return {
        success: false,
        error: error.message || 'Failed to fetch business'
      };
    }
  }

  // Update business
  async updateBusiness(businessId, businessData) {
    try {
      console.log('Updating business:', businessId, businessData);
      const response = await apiClient.put(`/business/${businessId}`, businessData, true);
      return {
        success: true,
        business: response.business,
        message: response.message
      };
    } catch (error) {
      console.error('Update business error:', error);
      return {
        success: false,
        error: error.message || 'Failed to update business'
      };
    }
  }

  // Delete business
  async deleteBusiness(businessId) {
    try {
      console.log('Deleting business:', businessId);
      const response = await apiClient.delete(`/business/${businessId}`, true);
      return {
        success: true,
        message: response.message
      };
    } catch (error) {
      console.error('Delete business error:', error);
      return {
        success: false,
        error: error.message || 'Failed to delete business'
      };
    }
  }

  // Regenerate API key
  async regenerateApiKey(businessId) {
    try {
      console.log('Regenerating API key for business:', businessId);
      const response = await apiClient.post(`/business/${businessId}/regenerate-api-key`, {}, true);
      return {
        success: true,
        business: response.business,
        message: response.message
      };
    } catch (error) {
      console.error('Regenerate API key error:', error);
      return {
        success: false,
        error: error.message || 'Failed to regenerate API key'
      };
    }
  }
}

const businessService = new BusinessService();
export default businessService;