import { useContext } from 'react';
import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { AuthContext } from './context/AuthContext';
import { SidebarProvider } from './context/SidebarContext';
import { GoogleBusinessProvider } from './context/GoogleBusinessContext';
import SonnerProvider from './sonner/SonnerProvider';

import Allreviews from './Components/Allreviews';
import Dashboard from './Components/Dashboard';
import Features from './Components/Features';
import InboxMessage from './Components/Get-Reviews';
import Home from './Components/Home';
import Integrations from './Components/Integrations';
import Login from './Components/Login';
import Navbar from './Components/Navbar';
import Notifications from './Components/Notifications';
import ReviewLink from './Components/ReviewLink';
import Posts from './Components/Posts';
import Widget from './Components/Widget';
import ReviewPage from './pages/ReviewPage';
import ThankYouPage from './pages/ThankYouPage';
import SeoDashboard from './Components/Seo-Dashboard';
import AnalyticsDashboard from './Components/Analytics-Dashboard';
import SettingsPage from './Components/Settings';
import ForgotPassword from './Components/Forgot-Password';
import Audit from './Components/Audit';
import Billing from './Components/Billing';

// Protected Route
// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const { user, isLoading } = useContext(AuthContext);
  const location = useLocation();

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (!user) {
    return (
      <Navigate 
        to="/login" 
        replace 
        state={{ 
          from: location,
          message: 'Please login to access the dashboard' 
        }} 
      />
    );
  }

  return children || <Outlet />;
};

const App = () => {
  const location = useLocation();
  const hideNavbar = location.pathname === '/login' || 
                    location.pathname === '/dashboard' || 
                    location.pathname === '/reviews' || 
                    location.pathname === '/social-sharing' || 
                    location.pathname === '/posts' || 
                    location.pathname === '/review-link' || 
                    location.pathname === '/notifications' || 
                    location.pathname === '/widgets' || 
                    location.pathname === '/integrations' ||
                    location.pathname === '/audit' ||
                    location.pathname === '/billing';

  return (
    <>
    <SonnerProvider/>
      <Routes>
        {/* Public routes outside SidebarProvider */}
        <Route path="/" element={
          <>
            <Home />
            <Features />
            <Navbar/>
          </>
        } />
        <Route path="/login" element={<Login />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/all-reviews" element={
          <>
            <Allreviews />
            <Navbar/>
          </>
        } />
        <Route path="/seo-dashboard" element={
          <>
            <SeoDashboard />
            <Navbar/>
          </>
        } />
        <Route path="/analytics-dashboard" element={
          <>
            <AnalyticsDashboard />
            <Navbar/>
          </>
        } />
        <Route path="/settings" element={
          <>
            <SettingsPage />
            <Navbar/>
          </>
        } />
       
        {/* Protected routes inside SidebarProvider */}
        <Route element={
          <ProtectedRoute>
            <GoogleBusinessProvider>
              <SidebarProvider>
                <div className="min-h-screen bg-[#1a1b2e]">
                  {!hideNavbar && <Navbar />}
                  <main className="lg:ml-20">
                    <Outlet />
                  </main>
                </div>
              </SidebarProvider>
            </GoogleBusinessProvider>
          </ProtectedRoute>
        }>
         
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/reviews" element={<InboxMessage/>} />
          <Route path="/audit" element={<Audit />} />
          <Route path="/billing" element={<Billing />} />
          <Route path="/integrations" element={<Integrations/>} />
          <Route path="/posts" element={<Posts />} />
          <Route path="/social-sharing" element={<Posts />} />
          <Route path="/review-link" element={<ReviewLink/>} />
          <Route path="/notifications" element={<Notifications/>} />
          <Route path="/widgets" element={<Widget/>} />
          <Route path="/review/:businessId" element={<ReviewPage />} />
          <Route path="/review/thank-you" element={<ThankYouPage />} />

        </Route>
      </Routes>
    </>
  );
};

export default App;
