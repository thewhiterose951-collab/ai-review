import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

// const firebaseConfig = {
//   apiKey: "AIzaSyC92h9JqsP7eMP7G8vQlCUeI9_txb-IC9g",
//   authDomain: "ai-generated-reviews.firebaseapp.com",
//   projectId: "ai-generated-reviews",
//   storageBucket: "ai-generated-reviews.firebasestorage.app",
//   messagingSenderId: "82136387171",
//   appId: "1:82136387171:web:36b2f3941dad81f286b256",
//   measurementId: "G-5FMS6LN41G"
// };

const firebaseConfig = {
  apiKey: "AIzaSyC2G2Pd8lGq7a9cPXv0DG7tftS0sJ8l5GE",
  authDomain: "clurst-75157.firebaseapp.com",
  projectId: "clurst-75157",
  storageBucket: "clurst-75157.firebasestorage.app",
  messagingSenderId: "73017128775",
  appId: "1:73017128775:web:bffbdae641a3fbbcc8be62",
  measurementId: "G-9725CQMN0S"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export default app;