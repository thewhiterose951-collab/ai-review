import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { FaStar, FaRegStar, FaRegLightbulb } from 'react-icons/fa';
import { FaRegCopy } from 'react-icons/fa6';

function ReviewPage() {
  const { businessId } = useParams();
  const navigate = useNavigate();
  const [businessName, setBusinessName] = useState('');
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [reviewText, setReviewText] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);

const fetchAiSuggestions = async (rating) => {
    if (rating < 4) {
      setShowSuggestions(false);
      return;
    }
    
    setLoadingSuggestions(true);
    setShowSuggestions(true);
    
    try {
      const response = await fetch(`/api/reviews/samples/google/${businessId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rating })
      });
      
      if (!response.ok) throw new Error('Failed to fetch suggestions');
      
      const data = await response.json();
      setAiSuggestions(data.samples || []);
    } catch (error) {
      console.error('Error fetching AI suggestions:', error);
      toast.error('Could not load review suggestions');
      setShowSuggestions(false);
    } finally {
      setLoadingSuggestions(false);
    }
  };
  
  const handleRatingClick = (star) => {
    setRating(star);
    if (star >= 4) {
      fetchAiSuggestions(star);
    } else {
      setShowSuggestions(false);
    }
  };
  
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (rating === 0) {
      toast.error('Please select a rating');
      return;
    }
    if (!customerName.trim()) {
      toast.error('Please enter your name');
      return;
    }

    setLoading(true);
    try {
      const endpoint = rating >= 4 ? 'google' : 'database';
      const res = await fetch(`/api/reviews/submit/${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          businessId,
          rating,
          reviewText,
          customerName,
          customerEmail,
        }),
      });

      const data = await res.json();

      if (res.ok) {
        toast.success('Thank you for your review!');
        navigate(`/review/thank-you`);
      } else {
        throw new Error(data.error || 'Failed to submit review');
      }
    } catch (err) {
      toast.error(err.message);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen text-white flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-gray-800 rounded-lg shadow-lg p-8">
        <h1 className="text-3xl font-bold text-center mb-2">Leave a Review</h1>
        <p className="text-center text-gray-400 mb-6">for {businessName || '...'}</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Your Rating</label>
            <div className="flex items-center justify-center space-x-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <div
                  key={star}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  onClick={() => handleRatingClick(star)}
                  className="cursor-pointer"
                >
                  {star <= (hoverRating || rating) ? (
                    <FaStar className="w-8 h-8 text-yellow-400" />
                  ) : (
                    <FaRegStar className="w-8 h-8 text-gray-500" />
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {showSuggestions && (
            <div className="mt-6 p-4 bg-gray-700 rounded-lg">
              <div className="flex items-center mb-3 text-yellow-400">
                <FaRegLightbulb className="mr-2" />
                <h3 className="font-medium">AI-Powered Review Suggestions</h3>
              </div>
              
              {loadingSuggestions ? (
                <div className="text-center py-4">
                  <div className="animate-pulse text-gray-400">Generating suggestions...</div>
                </div>
              ) : aiSuggestions.length > 0 ? (
                <div className="space-y-3">
                  <p className="text-sm text-gray-300 mb-2">Here are some suggestions for your {rating}-star review:</p>
                  {aiSuggestions.map((suggestion, index) => (
                    <div key={index} className="relative p-3 bg-gray-600 rounded-md group">
                      <h4 className="font-medium text-yellow-400 text-sm">{suggestion.title}</h4>
                      <p className="text-sm text-gray-100 mt-1">{suggestion.text}</p>
                      <button 
                        onClick={() => {
                          setReviewText(suggestion.text);
                          toast.success('Suggestion added to your review!');
                        }}
                        className="absolute top-1 right-1 p-1 text-gray-400 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Use this suggestion"
                      >
                        <FaRegCopy />
                      </button>
                    </div>
                  ))}
                  <p className="text-xs text-gray-400 mt-2">
                    Click on the copy icon to use a suggestion, or feel free to write your own!
                  </p>
                </div>
              ) : (
                <p className="text-sm text-gray-400">No suggestions available. Please write your own review.</p>
              )}
            </div>
          )}

          <div>
            <label htmlFor="customerName" className="block text-sm font-medium text-gray-300">Your Name</label>
            <input
              id="customerName"
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-purple-500 focus:border-purple-500"
              required
            />
          </div>

          <div>
            <label htmlFor="customerEmail" className="block text-sm font-medium text-gray-300">Your Email (Optional)</label>
            <input
              id="customerEmail"
              type="email"
              value={customerEmail}
              onChange={(e) => setCustomerEmail(e.target.value)}
              className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-purple-500 focus:border-purple-500"
            />
          </div>

          <div>
            <label htmlFor="reviewText" className="block text-sm font-medium text-gray-300">Your Review (Optional)</label>
            <textarea
              id="reviewText"
              rows="4"
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value)}
              className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-purple-500 focus:border-purple-500"
            ></textarea>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-4 rounded-lg focus:outline-none focus:shadow-outline transition duration-200 disabled:opacity-50"
          >
            {loading ? 'Submitting...' : 'Submit Review'}
          </button>
        </form>
      </div>
    </div>
  );
}

export default ReviewPage;
