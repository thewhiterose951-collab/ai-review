/* eslint-disable no-undef */
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import path from "path";
import { defineConfig } from "vite";
 

export default defineConfig({
  server: {
    host: "0.0.0.0",
    allowedHosts: ["localhost"],
    proxy: {
      "/api": {
        target: process.env.API_BASE_URL || "http://localhost:8000",
        changeOrigin: true,
        secure: false, 
      },
    },
  },
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },

});













