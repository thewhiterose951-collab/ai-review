import { sendEmailInvitation, sendSmsInvitation } from "./invitationController.js";
import csv from 'csv-parser';
import { Readable } from 'stream';
import supabase from "../config/supabase.js";

// Helper function to format phone numbers
const formatPhoneNumber = (phone) => {
  if (!phone) return null;
  // Remove all non-digit characters
  const cleaned = phone.replace(/\D/g, '');
  // If number starts with country code, return as is, else add +91 for India
  return cleaned.startsWith('+') ? cleaned : `+91${cleaned}`;
};

// Helper function to validate email
const isValidEmail = (email) => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

// Helper function to validate phone number
const isValidPhone = (phone) => {
  // Basic validation - 10-15 digits after + (allowing for country codes)
  return /^\+?[1-9]\d{9,14}$/.test(phone);
};

export const processBulkInvitations = async (req, res) => {
  try {
    if (!req.file) {
      console.log('No file in request');
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const { businessId } = req.body;
    if (!businessId) {
      return res.status(400).json({ error: 'Business ID is required' });
    }

    // Verify user has access to this business
    const { data: business, error: bizError } = await supabase
      .from("businesses")
      .select("*")
      .eq("id", businessId)
      .eq("owner_id", req.user.uid)
      .single();

    if (bizError || !business) {
      return res.status(403).json({ error: 'Unauthorized access to business' });
    }

    const results = [];
    const errors = [];
    let processedCount = 0;

    // Process the CSV file
    const buffer = req.file.buffer;
    const stream = Readable.from(buffer.toString());
    const invitationType = req.body.invitationType || 'email'; // 'email', 'sms', or 'both'

    await new Promise((resolve, reject) => {
      stream
        .pipe(csv())
        .on('data', (data) => {
          const row = processedCount + 1;
          const hasEmail = data.customerEmail && isValidEmail(data.customerEmail);
          const hasPhone = data.customerPhone && isValidPhone(formatPhoneNumber(data.customerPhone));
          
          // Skip if no valid contact method based on invitation type
          if ((!hasEmail && (invitationType === 'email' || invitationType === 'both')) ||
              (!hasPhone && (invitationType === 'sms' || invitationType === 'both'))) {
            errors.push({ 
              row,
              error: 'Missing valid contact information',
              data,
              details: `Row ${row}: Missing ${!hasEmail ? 'valid email' : ''}${!hasEmail && !hasPhone ? ' and ' : ''}${!hasPhone ? 'valid phone number' : ''}`
            });
            processedCount++;
            return;
          }
          
          results.push({
            name: data.customerName,
            email: hasEmail ? data.customerEmail : null,
            phone: hasPhone ? formatPhoneNumber(data.customerPhone) : null,
            businessId,
            row
          });
          processedCount++;
        })
        .on('end', resolve)
        .on('error', reject);
    });

    // Process invitations based on type
    const processInvitation = async (invite) => {
      const result = { email: null, sms: null, errors: [] };
      
      // Process email if needed
      if ((invitationType === 'email' || invitationType === 'both') && invite.email) {
        try {
          await sendEmailInvitation(
            { 
              body: {
                businessId: invite.businessId,
                customerEmail: invite.email,
                customerName: invite.name
              },
              user: req.user
            },
            { 
              json: (data) => data,
              status: (code) => ({ json: (data) => data })
            }
          );
          result.email = { success: true };
        } catch (error) {
          result.email = { success: false, error: error.message };
          result.errors.push(`Email failed: ${error.message}`);
        }
      }
      
      // Process SMS if needed
      if ((invitationType === 'sms' || invitationType === 'both') && invite.phone) {
        try {
          await sendSmsInvitation(
            { 
              body: {
                businessId: invite.businessId,
                customerPhone: invite.phone,
                customerName: invite.name
              },
              user: req.user
            },
            { 
              json: (data) => data,
              status: (code) => ({ json: (data) => data })
            }
          );
          result.sms = { success: true };
        } catch (error) {
          result.sms = { success: false, error: error.message };
          result.errors.push(`SMS failed: ${error.message}`);
        }
      }
      
      return result;
    };

    // Process all invitations in parallel
    const processed = await Promise.allSettled(
      results.map(invite => processInvitation(invite))
    );

    // Process results
    let successful = 0;
    let failed = 0;
    const detailedResults = [];

    processed.forEach((result, index) => {
      const invite = results[index];
      const status = {
        row: invite.row,
        name: invite.name,
        email: invite.email,
        phone: invite.phone,
        success: false,
        errors: []
      };

      if (result.status === 'fulfilled') {
        const { email, sms, errors } = result.value;
        status.errors = errors;
        
        if (invitationType === 'email' || invitationType === 'both') {
          if (email?.success) successful++;
          else {
            failed++;
            status.errors.push(email?.error || 'Email sending failed');
          }
        }
        
        if (invitationType === 'sms' || invitationType === 'both') {
          if (sms?.success) successful++;
          else {
            failed++;
            status.errors.push(sms?.error || 'SMS sending failed');
          }
        }
        
        status.success = status.errors.length === 0;
      } else {
        failed++;
        const error = result.reason?.message || 'Unknown error';
        console.error(`Failed to process invitation for row ${invite.row}:`, error);
        status.errors.push(error);
      }
      
      if (status.errors.length > 0) {
        errors.push({
          row: invite.row,
          name: invite.name,
          email: invite.email,
          phone: invite.phone,
          errors: status.errors
        });
      }
      
      detailedResults.push(status);
    });

    res.json({
      total: results.length,
      successful,
      failed,
      invitationType,
      detailedResults: detailedResults.slice(0, 100), // Return first 100 for review
      errors: errors.length > 0 ? errors : undefined
    });

  } catch (error) {
    console.error('Bulk upload error:', error);
    res.status(500).json({ 
      error: 'Failed to process bulk upload',
      details: error.message 
    });
  }
};