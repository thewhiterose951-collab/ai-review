import { google } from "googleapis";
import { auth } from "../config/firebase.js";

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const makeRateLimitedRequest = async (requestFn, maxRetries = 3, baseDelayMs = 1000) => {
  let lastError;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await requestFn();
    } catch (error) {
      lastError = error;
      if (error.code === 429 && attempt < maxRetries) {
        const delayMs = baseDelayMs * Math.pow(2, attempt - 1);
        console.log(`Rate limited. Retrying in ${delayMs}ms... (Attempt ${attempt}/${maxRetries})`);
        await delay(delayMs);
      } else {
        throw error;
      }
    }
  }
  
  throw lastError;
};

const SCOPES = ["https://www.googleapis.com/auth/business.manage"];
const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI || 'http://localhost:8000/api/integration/google-callback'
);

const tokenStore = new Map();

const getUserIdFromToken = async (token) => {
  try {
    const decodedToken = await auth.verifyIdToken(token);
    return decodedToken.uid;
  } catch (error) {
    console.error('Invalid token:', error);
    return null;
  }
};

// Step 1: Redirect user to Google OAuth
export const redirectToGoogleBusiness = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ error: 'No authentication token provided' });
    }
    
    const userId = await getUserIdFromToken(token);
    if (!userId) {
      return res.status(401).json({ error: 'Invalid or expired authentication token' });
    }
    
    const url = oauth2Client.generateAuthUrl({
      access_type: "offline",
      prompt: "consent",
      scope: SCOPES,
      state: userId,
      include_granted_scopes: true
    });
    
    res.json({ authUrl: url });
  } catch (error) {
    console.error('Error generating auth URL:', error);
    res.status(500).json({ error: 'Failed to initiate OAuth flow' });
  }
};

// Step 2: OAuth callback
export const googleOAuthCallback = async (req, res) => {
  const { code, error, state } = req.query;
  
  if (error) {
    console.error('OAuth error:', error);
    return res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}/integrations?error=${encodeURIComponent(error)}`);
  }

  if (!code) {
    return res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}/integrations?error=missing_code`);
  }

  try {
    console.log('Received OAuth callback with code. Exchanging for tokens...');
    const { tokens } = await oauth2Client.getToken(code);
    console.log('Successfully obtained tokens from Google');
    
    // If we have a state parameter, it should contain the user ID
    if (state) {
      const userId = state;
      console.log(`Storing tokens for user: ${userId}`);
      tokenStore.set(userId, tokens);
      console.log(`Tokens stored successfully for user: ${userId}`);
      console.log('Token details:', {
        access_token: tokens.access_token ? '***' : 'missing',
        refresh_token: tokens.refresh_token ? '***' : 'missing',
        expiry_date: tokens.expiry_date ? new Date(tokens.expiry_date).toISOString() : 'missing'
      });
    } else {
      console.warn('No user ID found in state parameter');
    }
    
    oauth2Client.setCredentials(tokens);
    console.log('OAuth client credentials set successfully');
    
    try {
      // Fetch the user's GMB accounts with rate limiting
      console.log('Fetching Google My Business accounts...');
      const mybusiness = google.mybusinessaccountmanagement({ version: 'v1', auth: oauth2Client });
      
      // Wrap the API call in our rate-limited request handler
      const accountsResponse = await makeRateLimitedRequest(
        () => mybusiness.accounts.list(),
        3,  // max retries
        2000 // initial delay of 2 seconds
      );
      
      const accounts = accountsResponse.data.accounts || [];
      console.log(`Successfully fetched ${accounts.length} accounts`);
      
      console.log(`Found ${accounts.length} Google My Business accounts`);
      
      // Store account information with tokens
      if (state) {
        const userId = state;
        const userData = {
          ...tokens,
          accounts,
          lastSynced: new Date().toISOString()
        };
        tokenStore.set(userId, userData);
        console.log('Updated user data with account information');
      }
      
      // Prepare redirect URL with account info
      const redirectUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/integrations?success=connected&hasAccounts=${accounts.length > 0}`;
      console.log(`Redirecting to: ${redirectUrl}`);
      
      res.redirect(redirectUrl);
      
    } catch (error) {
      console.error('Error fetching GMB accounts:', error);
      const redirectUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/integrations?success=connected&error=fetch_accounts_failed`;
      res.redirect(redirectUrl);
    }
  } catch (err) {
    console.error('OAuth token exchange error:', err);
    res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}/integrations?error=oauth_failed`);
  }
};

// Step 3: Check connection status
export const checkConnectionStatus = async (req, res) => {
  console.log('\n--- Checking connection status ---');
  
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    console.log('No authentication token provided');
    return res.status(401).json({ 
      connected: false,
      message: 'No authentication token provided.'
    });
  }
  
  const userId = await getUserIdFromToken(token);
  if (!userId) {
    console.log('Invalid or expired authentication token');
    return res.status(401).json({ 
      connected: false,
      message: 'Invalid or expired authentication token.'
    });
  }
  
  console.log(`Checking status for user: ${userId}`);
  console.log(`Token store has ${tokenStore.size} entries`);
  
  const tokens = tokenStore.get(userId);
  console.log(`Tokens found for user ${userId}:`, tokens ? 'Yes' : 'No');
  
  if (!tokens) {
    console.log('No active session found for user');
    return res.json({ 
      connected: false,
      message: 'No active session. Please connect your Google My Business account.'
    });
  }
  
  try {
    oauth2Client.setCredentials(tokens);
    
    // Check if token is expired and refresh if needed
    if (tokens.expiry_date < Date.now()) {
      try {
        console.log('Access token expired, refreshing...');
        const { credentials } = await oauth2Client.refreshAccessToken();
        tokens.access_token = credentials.access_token;
        tokens.expiry_date = credentials.expiry_date;
        
        // Preserve any existing account data
        const updatedTokens = {
          ...tokens,
          accounts: tokens.accounts || [],
          lastSynced: tokens.lastSynced || new Date().toISOString()
        };
        
        tokenStore.set(userId, updatedTokens);
        console.log('Access token refreshed successfully');
      } catch (refreshError) {
        console.error('Token refresh failed:', refreshError);
        tokenStore.delete(userId);
        return res.json({ 
          connected: false,
          message: 'Session expired. Please reconnect your Google My Business account.'
        });
      }
    }
    
    // Get account information from stored tokens or fetch fresh
    let accounts = [];
    let lastSynced = tokens.lastSynced || new Date().toISOString();
    
    // If we have stored accounts and they're not too old (less than 1 hour), use them
    const oneHourAgo = new Date();
    oneHourAgo.setHours(oneHourAgo.getHours() - 1);
    
    if (tokens.accounts && tokens.lastSynced && new Date(tokens.lastSynced) > oneHourAgo) {
      console.log('Using cached account information');
      accounts = tokens.accounts;
    } else {
      try {
        // Fetch fresh account information with rate limiting
        console.log('Fetching fresh account information');
        const mybusiness = google.mybusinessaccountmanagement({ version: 'v1', auth: oauth2Client });
        
        // Use rate-limited request for the accounts list
        const accountsResponse = await makeRateLimitedRequest(
          () => mybusiness.accounts.list(),
          3,  // max retries
          2000 // initial delay of 2 seconds
        );
        
        accounts = accountsResponse.data.accounts || [];
        lastSynced = new Date().toISOString();
        console.log(`Successfully refreshed ${accounts.length} accounts`);
        
        // Update stored tokens with fresh account info
        if (userId) {
          tokenStore.set(userId, {
            ...tokens,
            accounts,
            lastSynced
          });
        }
      } catch (error) {
        console.error('Error fetching GMB accounts:', error);
        // If we can't fetch fresh data but have cached data, use that
        if (tokens.accounts) {
          console.log('Using cached accounts due to fetch error');
          accounts = tokens.accounts;
        } else {
          throw error;
        }
      }
    }
    
    res.json({ 
      connected: true, 
      accounts: accounts,
      lastSynced: lastSynced,
      hasAccounts: accounts.length > 0
    });
  } catch (err) {
    console.error('Connection check failed:', err);
    tokenStore.delete(userId);
    res.json({ 
      connected: false, 
      error: 'Failed to verify connection',
      message: 'Connection lost. Please reconnect your Google My Business account.'
    });
  }
};

// Step 4: Fetch all reviews for all locations
export const syncGoogleReviews = async (req, res) => {
  if (!sessionTokens) return res.status(400).json({ error: "Not connected" });
  oauth2Client.setCredentials(sessionTokens);

  try {
    // Fetch accounts
    const accountsRes = await google.mybusinessaccountmanagement("v1").accounts.list({
      auth: oauth2Client,
    });
    const accounts = accountsRes.data.accounts || [];
    const allReviews = [];

    for (const acc of accounts) {
      // Fetch locations for each account
      const locationsRes = await google.mybusiness("v4").accounts.locations.list({
        parent: acc.name,
        auth: oauth2Client,
      });
      const locations = locationsRes.data.locations || [];

      for (const loc of locations) {
        let pageToken;
        do {
          const reviewsRes = await google.mybusiness("v4").accounts.locations.reviews.list({
            parent: loc.name,
            pageToken,
            auth: oauth2Client,
          });
          if (reviewsRes.data.reviews) {
            allReviews.push(...reviewsRes.data.reviews);
          }
          pageToken = reviewsRes.data.nextPageToken;
        } while (pageToken);
      }
    }

    res.json({ totalReviews: allReviews.length, reviews: allReviews });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
};
