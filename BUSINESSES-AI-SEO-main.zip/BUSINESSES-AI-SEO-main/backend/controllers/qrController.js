// controllers/qrController.js
import supabase from "../config/supabase.js";
import QRCode from "qrcode";

// ✅ 1. GENERATE QR FOR LOCAL REVIEWS (Database)
export const generateLocalReviewQR = async (req, res) => {
  try {
    const { businessId } = req.params;

    // Verify business ownership
    const { data: business, error } = await supabase
      .from("businesses")
      .select("id, name, location, api_key")
      .eq("id", businessId)
      .eq("owner_id", req.user.uid)
      .single();

    if (error || !business) {
      return res.status(404).json({ 
        error: "Business not found or access denied",
        code: "BUSINESS_NOT_FOUND"
      });
    }

    // Generate local review URL (your frontend URL)
    const localReviewUrl = `${process.env.FRONTEND_URL}/review/${businessId}?type=local&key=${business.api_key}`;

    // Generate QR code
    const qrOptions = {
      errorCorrectionLevel: 'H',
      type: 'image/png',
      quality: 0.92,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      },
      width: 300
    };

    const qrDataUrl = await QRCode.toDataURL(localReviewUrl, qrOptions);

    // Save or update QR code in database
    const qrPayload = {
      business_id: businessId,
      qr_type: "local_review",
      qr_url: qrDataUrl,
      review_page_url: localReviewUrl,
      updated_at: new Date().toISOString(),
      metadata: {
        purpose: "local_database_reviews",
        accepts_ratings: "1-3 stars",
        auto_ai_reply: true,
        frontend_url: process.env.FRONTEND_URL
      }
    };

    const { data: existingQR } = await supabase
      .from("qr_codes")
      .select("id")
      .eq("business_id", businessId)
      .eq("qr_type", "local_review")
      .single();

    let savedQR;
    if (existingQR) {
      const { data, error: updateErr } = await supabase
        .from("qr_codes")
        .update(qrPayload)
        .eq("id", existingQR.id)
        .select()
        .single();
      
      if (updateErr) throw updateErr;
      savedQR = data;
    } else {
      const { data, error: insertErr } = await supabase
        .from("qr_codes")
        .insert([{
          ...qrPayload,
          created_at: new Date().toISOString()
        }])
        .select()
        .single();
      
      if (insertErr) throw insertErr;
      savedQR = data;
    }

    console.log(`✅ Local review QR generated for business: ${businessId}`);

    res.json({
      success: true,
      message: "Local review QR code generated successfully",
      qrCode: {
        id: savedQR.id,
        type: "local_review",
        image: savedQR.qr_url,
        reviewUrl: savedQR.review_page_url,
        purpose: "Collects 1-3 star reviews in database with AI auto-reply"
      },
      usage: {
        bestFor: "In-store feedback collection",
        acceptsRatings: "1-3 stars",
        features: ["Saves to database", "AI auto-reply", "Private feedback"]
      },
      business: {
        id: business.id,
        name: business.name
      }
    });

  } catch (error) {
    console.error("❌ Local QR generation error:", error);
    res.status(500).json({ 
      error: "Failed to generate local review QR",
      code: "QR_GENERATION_FAILED"
    });
  }
};

// ✅ 2. GENERATE QR FOR GOOGLE REVIEWS
export const generateGoogleReviewQR = async (req, res) => {
  try {
    const { businessId } = req.params;

    // Verify business ownership
    const { data: business, error } = await supabase
      .from("businesses")
      .select("id, name, location, google_place_id, api_key")
      .eq("id", businessId)
      .eq("owner_id", req.user.uid)
      .single();

    if (error || !business) {
      return res.status(404).json({ 
        error: "Business not found or access denied",
        code: "BUSINESS_NOT_FOUND"
      });
    }

    // Generate Google review URL
    let googleReviewUrl;
    if (business.google_place_id) {
      // Direct Google review link
      googleReviewUrl = `https://search.google.com/local/writereview?placeid=${business.google_place_id}`;
    } else {
      // Frontend redirect page that will handle Google redirect
      googleReviewUrl = `${process.env.FRONTEND_URL}/review/${businessId}?type=google&redirect=true&key=${business.api_key}`;
    }

    // Generate QR code
    const qrOptions = {
      errorCorrectionLevel: 'H',
      type: 'image/png',
      quality: 0.92,
      margin: 1,
      color: {
        dark: '#1A73E8', // Google blue
        light: '#FFFFFF'
      },
      width: 300
    };

    const qrDataUrl = await QRCode.toDataURL(googleReviewUrl, qrOptions);

    // Save or update QR code in database
    const qrPayload = {
      business_id: businessId,
      qr_type: "google_review",
      qr_url: qrDataUrl,
      review_page_url: googleReviewUrl,
      updated_at: new Date().toISOString(),
      metadata: {
        purpose: "google_reviews_redirect",
        accepts_ratings: "4-5 stars",
        has_google_place_id: !!business.google_place_id,
        shows_ai_samples: true,
        redirect_type: business.google_place_id ? "direct" : "frontend_redirect"
      }
    };

    const { data: existingQR } = await supabase
      .from("qr_codes")
      .select("id")
      .eq("business_id", businessId)
      .eq("qr_type", "google_review")
      .single();

    let savedQR;
    if (existingQR) {
      const { data, error: updateErr } = await supabase
        .from("qr_codes")
        .update(qrPayload)
        .eq("id", existingQR.id)
        .select()
        .single();
      
      if (updateErr) throw updateErr;
      savedQR = data;
    } else {
      const { data, error: insertErr } = await supabase
        .from("qr_codes")
        .insert([{
          ...qrPayload,
          created_at: new Date().toISOString()
        }])
        .select()
        .single();
      
      if (insertErr) throw insertErr;
      savedQR = data;
    }

    console.log(`✅ Google review QR generated for business: ${businessId}`);

    res.json({
      success: true,
      message: "Google review QR code generated successfully",
      qrCode: {
        id: savedQR.id,
        type: "google_review",
        image: savedQR.qr_url,
        reviewUrl: savedQR.review_page_url,
        purpose: "Redirects to Google Reviews for 4-5 star ratings"
      },
      usage: {
        bestFor: "Happy customers, public reviews",
        acceptsRatings: "4-5 stars",
        features: ["Google Reviews redirect", "AI sample reviews", "Public visibility"]
      },
      business: {
        id: business.id,
        name: business.name,
        hasGoogleProfile: !!business.google_place_id
      }
    });

  } catch (error) {
    console.error("❌ Google QR generation error:", error);
    res.status(500).json({ 
      error: "Failed to generate Google review QR",
      code: "QR_GENERATION_FAILED"
    });
  }
};

// ✅ 4. GET ALL QR CODES FOR BUSINESS
export const getBusinessQRCodes = async (req, res) => {
  try {
    const { businessId } = req.params;

    // Verify business ownership
    const { data: business } = await supabase
      .from("businesses")
      .select("id, name")
      .eq("id", businessId)
      .eq("owner_id", req.user.uid)
      .single();

    if (!business) {
      return res.status(403).json({
        error: "Access denied",
        code: "BUSINESS_ACCESS_DENIED"
      });
    }

    const { data: qrCodes, error } = await supabase
      .from("qr_codes")
      .select("*")
      .eq("business_id", businessId)
      .order("qr_type");

    if (error) throw error;

    const localQR = qrCodes?.find(qr => qr.qr_type === "local_review");
    const googleQR = qrCodes?.find(qr => qr.qr_type === "google_review");

    res.json({
      success: true,
      business: {
        id: business.id,
        name: business.name
      },
      qrCodes: {
        local: localQR || null,
        google: googleQR || null
      },
      hasAllQRCodes: !!(localQR && googleQR),
      message: (!localQR || !googleQR) 
        ? "Some QR codes are missing. Generate them to get started."
        : "All QR codes are ready to use!"
    });

  } catch (error) {
    console.error("❌ Error fetching QR codes:", error);
    res.status(500).json({ 
      error: "Failed to fetch QR codes",
      code: "QR_FETCH_FAILED"
    });
  }
};