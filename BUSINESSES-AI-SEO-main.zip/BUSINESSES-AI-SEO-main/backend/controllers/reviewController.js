import axios from 'axios';
import { existsSync, mkdirSync, writeFileSync } from "fs"; // ✅ Added mkdirSync and existsSync
import { Parser } from "json2csv";
import path from "path";
import supabase from "../config/supabase.js";
import { generateAIReply } from "./aiChatController.js";
import { syncGoogleReviews } from "./integrationController.js";


// ✅ 1. SUBMIT REVIEW TO DATABASE (1-3 stars with AI auto-reply)
export const submitReviewToDatabase = async (req, res) => {
  try {
    const { businessId, customerName, customerEmail, rating, reviewText } =
      req.body;

    // 🔒 Validate required fields
    if (!businessId || !customerName || !rating) {
      return res.status(400).json({
        error: "Missing required fields",
        code: "MISSING_FIELDS",
        required: ["businessId", "customerName", "rating"],
      });
    }

    const numericRating = parseInt(rating);

    if (numericRating < 1 || numericRating > 3) {
      return res.status(400).json({
        error: "This endpoint accepts ratings 1-3 only",
        code: "INVALID_RATING",
      });
    }

    // 🔍 Fetch business details
    const { data: business, error: bizErr } = await supabase
      .from("businesses")
      .select(
        "id, name, location, category, google_place_id, is_active, owner_id"
      )
      .eq("id", businessId)
      .single();

    if (bizErr || !business || !business.is_active) {
      return res.status(404).json({
        error: "Business not found or inactive",
        code: "BUSINESS_NOT_FOUND",
      });
    }

    console.log(
      `📝 Saving low rating review (${numericRating} stars) for ${business.name}`
    );

    // 💾 Save review to database
    const { data: newReview, error: insertError } = await supabase
      .from("reviews")
      .insert([
        {
          business_id: business.id,
          customer_name: customerName.trim(),
          customer_email: customerEmail?.trim() || null,
          rating: numericRating,
          review_text: reviewText?.trim() || null,
          source: "website",
          external_platform: "internal",
          is_verified: false,
          needs_attention: numericRating <= 2,
          created_at: new Date().toISOString(),
          metadata: {
            origin: "database_review",
            user_agent: req.headers["user-agent"] || "unknown",
            ip_address: req.ip || "unknown",
            auto_ai_reply: true,
            review_type: "needs_improvement",
          },
        },
      ])
      .select()
      .single();

    if (insertError) {
      throw new Error(`Failed to save review: ${insertError.message}`);
    }

    console.log(`✅ Review saved with ID: ${newReview.id}`);

    // 🤖 Generate AI auto-reply for low ratings
    let aiReplyText = null;
    let aiReplyError = null;

    try {
      console.log("🤖 Generating AI auto-reply for low rating...");

      const reviewContext =
        reviewText ||
        `Customer gave ${numericRating} star${numericRating > 1 ? "s" : ""}`;

      aiReplyText = await generateAIReply(
        reviewContext,
        business.id,
        newReview.id,
        business,
        null
      );

      // Update review with AI reply
      const { error: updateError } = await supabase
        .from("reviews")
        .update({
          ai_reply: aiReplyText,
          ai_replied_at: new Date().toISOString(),
          metadata: {
            ...newReview.metadata,
            ai_reply_generated: true,
            ai_reply_provider: "gemini",
            ai_reply_timestamp: new Date().toISOString(),
          },
        })
        .eq("id", newReview.id);

      if (!updateError) {
        console.log("✅ AI auto-reply generated and saved");
      }
    } catch (aiError) {
      console.error("❌ AI auto-reply failed:", aiError.message);
      aiReplyError = aiError.message;
    }

    // 📊 Update business statistics
    await updateBusinessStats(business.id);

    // 📧 Notify business owner for critical reviews
    if (numericRating <= 2) {
      await notifyBusinessOwner(business, newReview);
    }

    return res.status(201).json({
      success: true,
      message: `Thank you ${customerName} for your feedback. We take all concerns seriously.`,
      review: {
        id: newReview.id,
        rating: newReview.rating,
        text: newReview.review_text,
        customerName: newReview.customer_name,
        createdAt: newReview.created_at,
        savedTo: "database",
      },
      aiReply: {
        success: !!aiReplyText,
        text: aiReplyText,
        error: aiReplyError,
        respondedAt: aiReplyText ? new Date().toISOString() : null,
      },
      followUp: {
        message:
          numericRating <= 2
            ? "We're sorry to hear about your experience. Our team will contact you soon."
            : "We appreciate your feedback and will work to improve.",
        businessNotified: numericRating <= 2,
        expectResponse: "within 24 hours",
      },
    });
  } catch (error) {
    console.error("❌ Error in submitReviewToDatabase:", error.message);
    res.status(500).json({
      error: "Failed to submit review",
      code: "DATABASE_REVIEW_FAILED",
      details:
        process.env.NODE_ENV === "development" ? error.message : undefined,
    });
  }
};

// ✅ 2. SUBMIT REVIEW TO GOOGLE (4-5 stars with AI sample reviews)

export const submitReviewToGoogle = async (req, res) => {
  try {
    const { businessId, customerName, customerEmail, rating } = req.body;

    // 🔒 Validate
    if (!businessId || !rating) {
      return res.status(400).json({
        error: "Missing required fields",
        code: "MISSING_FIELDS",
        required: ["businessId", "rating"],
      });
    }

    const numericRating = parseInt(rating);

    if (numericRating < 4 || numericRating > 5) {
      return res.status(400).json({
        error: "This endpoint is for 4-5 star reviews only",
        code: "INVALID_RATING_FOR_GOOGLE",
      });
    }

    // 🔍 Fetch business with Google integration
    const { data: business, error: bizErr } = await supabase
      .from("businesses")
      .select(
        `
        id, 
        name, 
        location,
        category, 
        google_place_id, 
        google_integration_status,
        is_active
      `
      )
      .eq("id", businessId)
      .single();

    if (bizErr || !business || !business.is_active) {
      return res.status(404).json({
        error: "Business not found or inactive",
        code: "BUSINESS_NOT_FOUND",
      });
    }

    console.log(
      `🌟 High rating (${numericRating} stars) - preparing Google redirect for ${business.name}`
    );

    // 🤖 Generate AI sample reviews to show user
    const sampleReviews = await generateAISampleReviews(
      business,
      numericRating
    );

    // Generate Google review URL
    let googleReviewUrl;
    let redirectType;

    if (business.google_place_id) {
      googleReviewUrl = `https://search.google.com/local/writereview?placeid=${business.google_place_id}`;
      redirectType = "direct_place_id";
    } else {
      const searchQuery = encodeURIComponent(
        `${business.name} ${business.location}`
      );
      googleReviewUrl = `https://www.google.com/maps/search/?q=${searchQuery}`;
      redirectType = "search_fallback";
    }

    // 📊 Log the redirect for analytics
    const { data: redirectLog } = await supabase
      .from("review_redirects")
      .insert([
        {
          business_id: business.id,
          customer_name: customerName || "Anonymous",
          customer_email: customerEmail || null,
          rating_given: numericRating,
          redirect_type: redirectType,
          redirect_url: googleReviewUrl,
          redirect_platform: "google_reviews",
          ai_samples_shown: true,
          created_at: new Date().toISOString(),
          metadata: {
            has_google_place_id: !!business.google_place_id,
            google_integration_status: business.google_integration_status,
            sample_reviews_generated: sampleReviews.length,
            user_agent: req.headers["user-agent"] || "unknown",
            ip_address: req.ip || "unknown",
          },
        },
      ])
      .select()
      .single();

    // 📈 Update redirect statistics
    await updateRedirectStats(business.id);

    return res.status(200).json({
      success: true,
      action: "redirect_to_google",
      message: `🌟 Great! We're glad you had a positive experience!`,
      redirect: {
        url: googleReviewUrl,
        type: redirectType,
        platform: "google_reviews",
        openInNewTab: true,
      },
      aiSampleReviews: {
        message: "Here are some review suggestions to inspire you:",
        samples: sampleReviews,
        note: "Feel free to use these as inspiration or write your own!",
      },
      instructions: [
        "Review the sample reviews below for inspiration",
        "Click the button to go to Google Reviews",
        "Share your experience to help others find us",
        "Your honest feedback means the world to us!",
      ],
      business: {
        name: business.name,
        location: business.location,
        hasGoogleProfile: !!business.google_place_id,
      },
      tracking: {
        redirectId: redirectLog?.id,
        timestamp: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("❌ Error in submitReviewToGoogle:", error.message);
    res.status(500).json({
      error: "Failed to process Google review redirect",
      code: "GOOGLE_REDIRECT_FAILED",
      details:
        process.env.NODE_ENV === "development" ? error.message : undefined,
    });
  }
};

// ✅ 3. GENERATE AI SAMPLE REVIEWS
export const generateAISampleReviews = async (business, rating = 5) => {
  try {
    const prompt = `Generate 3 sample ${rating}-star Google reviews for ${
      business.name
    }, a ${business.category || "business"} in ${business.location}.

Rules:
- Each review should be 2-3 sentences
- Make them sound natural and authentic
- Mention specific positive aspects
- Vary the writing style for each
- Keep them under 100 words each

Return ONLY a valid JSON array with no additional text or markdown:
[
  { "title": "Great experience!", "text": "review text here" },
  { "title": "Highly recommend", "text": "review text here" },
  { "title": "Will return", "text": "review text here" }
]`;

    console.log(`🤖 Generating reviews for: ${business.name}`);

    // Use the stable gemini-2.5-flash model
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`;
    
    const response = await axios.post(
      apiUrl,
      {
        contents: [
          {
            parts: [
              {
                text: prompt
              }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.9,
          topP: 0.95,
          topK: 64,
          maxOutputTokens: 2048,
        }
      },
      {
        headers: { 
          "Content-Type": "application/json",
        },
        timeout: 30000,
        validateStatus: (status) => status < 500,
      }
    );

    if (response.status !== 200) {
      console.error("Gemini API error:", response.status, response.data);
      throw new Error(`Gemini API error: ${response.status}`);
    }

    const generatedText = response.data.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!generatedText) {
      console.error("No content in response:", JSON.stringify(response.data, null, 2));
      throw new Error("No content generated from Gemini API");
    }

    console.log("📝 AI generated content successfully");

    let samples;
    try {
      // Try to extract JSON from various formats
      let jsonText = generatedText.trim();
      
      // Remove markdown code blocks if present
      if (jsonText.includes('```')) {
        const jsonMatch = jsonText.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
        if (jsonMatch) {
          jsonText = jsonMatch[1];
        }
      }
      
      // Extract array if there's extra text
      const arrayMatch = jsonText.match(/\[[\s\S]*\]/);
      if (arrayMatch) {
        jsonText = arrayMatch[0];
      }
      
      samples = JSON.parse(jsonText);
      
      // Validate the structure
      if (!Array.isArray(samples) || samples.length === 0) {
        throw new Error("Invalid samples structure");
      }

      console.log(`✅ Parsed ${samples.length} review samples`);
    } catch (parseError) {
      console.error("JSON parse error:", parseError.message);
      console.error("Generated text:", generatedText);
      throw parseError;
    }

    // Save AI samples to database for analytics
    try {
      await supabase.from("ai_generated_samples").insert([
        {
          business_id: business.id,
          sample_type: "google_review",
          rating: rating,
          samples: samples,
          created_at: new Date().toISOString(),
        },
      ]);
      console.log("💾 Saved to database");
    } catch (dbError) {
      console.error("Database insert error (non-fatal):", dbError);
    }

    return samples;
  } catch (error) {
    if (error.code === 'ECONNABORTED' || error.code === 'ETIMEDOUT') {
      console.error("Request timeout - using fallback samples");
    } else if (error.response) {
      console.error("API error:", error.response.status, error.response.data);
    } else if (error.request) {
      console.error("Network error - no response received");
    } else {
      console.error("Error:", error.message);
    }
    
    console.log("Using fallback samples");
    
    // Return default samples with dynamic content
    return [
      {
        title: "Excellent service!",
        text: `Great experience at ${business.name}. Professional staff and quality service. Highly recommend!`,
      },
      {
        title: "Very satisfied",
        text: `${business.name} provided exactly what I needed. Friendly team and great results!`,
      },
      {
        title: "Will return!",
        text: `Impressed with ${business.name}. Everything was perfect from start to finish!`,
      },
    ];
  }
};

// ✅ 2. GET ALL REVIEWS (AUTH REQUIRED)
export const getReviews = async (req, res) => {
  try {
    const { businessId } = req.params;

    const { data: business } = await supabase
      .from("businesses")
      .select("id")
      .eq("id", businessId)
      .eq("owner_id", req.user.uid)
      .single();

    const { data: reviews, error } = await supabase
      .from("reviews")
      .select("*")
      .eq("business_id", businessId)
      .order("created_at", { ascending: false });

    if (error) throw error;

    res.json({ reviews: reviews || [] });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Failed to fetch reviews" });
  }
};

// ✅ 3. EXPORT REVIEWS TO CSV
export const exportReviewsCSV = async (req, res) => {
  try {
    const { businessId } = req.params;

    console.log(`📊 Exporting reviews for business: ${businessId}`);

    // Verify business ownership
    const { data: business, error: bizError } = await supabase
      .from("businesses")
      .select("id, name")
      .eq("id", businessId)
      .eq("owner_id", req.user.uid)
      .single();

    if (bizError || !business) {
      return res.status(404).json({ 
        error: "Business not found or access denied" 
      });
    }

    // Fetch reviews
    const { data: reviews, error: fetchError } = await supabase
      .from("reviews")
      .select("*")
      .eq("business_id", businessId)
      .order("created_at", { ascending: false });

    if (fetchError) {
      throw new Error(`Failed to fetch reviews: ${fetchError.message}`);
    }

    if (!reviews || reviews.length === 0) {
      return res.status(404).json({ 
        error: "No reviews found to export" 
      });
    }

    console.log(`✅ Found ${reviews.length} reviews to export`);

    // Format reviews for CSV export
    const formattedReviews = reviews.map(review => ({
      id: review.id,
      business_id: review.business_id,
      customer_name: review.customer_name,
      customer_email: review.customer_email || '',
      rating: review.rating,
      review_text: review.review_text || '',
      source: review.source,
      external_platform: review.external_platform || '',
      is_verified: review.is_verified,
      needs_attention: review.needs_attention,
      ai_reply: review.ai_reply || '',
      ai_replied_at: review.ai_replied_at || '',
      created_at: review.created_at,
      updated_at: review.updated_at || ''
    }));

    // Convert to CSV
    const parser = new Parser();
    const csv = parser.parse(formattedReviews);

    // Create exports directory if it doesn't exist
    const exportDir = path.join(process.cwd(), "exports");
    if (!existsSync(exportDir)) {
      mkdirSync(exportDir, { recursive: true });
      console.log(`✅ Created exports directory: ${exportDir}`);
    }

    // Generate filename with business name (sanitized)
    const sanitizedName = business.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    const fileName = `reviews-${sanitizedName}-${Date.now()}.csv`;
    const filePath = path.join(exportDir, fileName);

    // Write CSV file
    writeFileSync(filePath, csv);
    console.log(`✅ CSV file created: ${filePath}`);

    // Send file as download
    res.download(filePath, fileName, (err) => {
      if (err) {
        console.error("❌ Error sending file:", err);
        if (!res.headersSent) {
          res.status(500).json({ error: "Failed to download file" });
        }
      } else {
        console.log(`✅ File downloaded successfully: ${fileName}`);
        
        // Optional: Delete file after download (cleanup)
        // You can uncomment this if you want to auto-delete after download
        // setTimeout(() => {
        //   if (existsSync(filePath)) {
        //     unlinkSync(filePath);
        //     console.log(`🗑️ Cleaned up file: ${fileName}`);
        //   }
        // }, 5000);
      }
    });

  } catch (error) {
    console.error("❌ CSV export error:", error);
    res.status(500).json({ 
      error: "Failed to export reviews",
      details: process.env.NODE_ENV === "development" ? error.message : undefined
    });
  }
};

// ✅ 4. SYNC GOOGLE REVIEWS (Scheduled job)
export const syncReviewsDaily = async (req, res) => {
  try {
    const { data: businesses } = await supabase.from("businesses").select("id");

    for (const bizz of businesses) {
      req.body = { businessId: bizz.id };
      await syncGoogleReviews(req, res); // re-use controller
    }

    res.json({ message: "Review sync triggered for all businesses" });
  } catch (e) {
    console.error("Daily sync error", e);
    res.status(500).json({ error: "Review sync failed" });
  }
};

// ✅ 5. GET REVIEW SUMMARY
export const getReviewSummary = async (req, res) => {
  try {
    const { businessId } = req.params;

    // Get all reviews for the business, regardless of verification status
    const { data: reviews } = await supabase
      .from("reviews")
      .select("rating, source, created_at, is_verified")
      .eq("business_id", businessId);
      
    console.log(`Found ${reviews?.length || 0} reviews for business ${businessId}`);
    console.log('Review verification statuses:', reviews?.map(r => r.is_verified));

    const ratingDistribution = [1, 2, 3, 4, 5].map((star) => ({
      rating: star,
      count: reviews.filter((r) => r.rating == star).length,
    }));

    const sourceDistribution = reviews.reduce((acc, r) => {
      acc[r.source] = (acc[r.source] || 0) + 1;
      return acc;
    }, {});

    const avgRating = reviews.length
      ? (
          reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
        ).toFixed(2)
      : null;

    // Calculate recent reviews (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const recentReviews = reviews.filter(review => {
      const reviewDate = new Date(review.created_at);
      return reviewDate >= thirtyDaysAgo;
    });

    res.json({
      total: reviews.length,
      recentCount: recentReviews.length,
      average: avgRating,
      ratings: ratingDistribution,
      sources: sourceDistribution,
    });
  } catch (error) {
    res.status(500).json({ error: "Summary build failed" });
  }
};

// ✅ HELPER FUNCTION: UPDATE BUSINESS STATISTICS
const updateBusinessStats = async (businessId) => {
  try {
    const { data: reviews } = await supabase
      .from("reviews")
      .select("rating")
      .eq("business_id", businessId)
      .eq("is_verified", true);

    if (!reviews || reviews.length === 0) {
      console.log("⚠️ No reviews found for stats update");
      return;
    }

    const totalReviews = reviews.length;
    const averageRating = (
      reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews
    ).toFixed(2);

    // Count by rating
    const ratingCounts = {
      one_star: reviews.filter((r) => r.rating === 1).length,
      two_star: reviews.filter((r) => r.rating === 2).length,
      three_star: reviews.filter((r) => r.rating === 3).length,
      four_star: reviews.filter((r) => r.rating === 4).length,
      five_star: reviews.filter((r) => r.rating === 5).length,
    };

    // Update business record
    const { error: updateError } = await supabase
      .from("businesses")
      .update({
        total_reviews: totalReviews,
        average_rating: parseFloat(averageRating),
        ...ratingCounts,
        last_review_sync: new Date().toISOString(),
      })
      .eq("id", businessId);

    if (updateError) {
      console.error("❌ Failed to update business stats:", updateError.message);
    } else {
      console.log(
        `✅ Business stats updated: ${totalReviews} reviews, avg ${averageRating}`
      );
    }
  } catch (error) {
    console.error("❌ Error in updateBusinessStats:", error.message);
  }
};

// ✅ HELPER FUNCTION: UPDATE REDIRECT STATISTICS
const updateRedirectStats = async (businessId) => {
  try {
    const { data: redirects } = await supabase
      .from("review_redirects")
      .select("rating_given")
      .eq("business_id", businessId);

    if (!redirects || redirects.length === 0) {
      return;
    }

    const totalRedirects = redirects.length;
    const avgRedirectRating = (
      redirects.reduce((sum, r) => sum + r.rating_given, 0) / totalRedirects
    ).toFixed(2);

    const { error: updateError } = await supabase
      .from("businesses")
      .update({
        total_redirects: totalRedirects,
        average_redirect_rating: parseFloat(avgRedirectRating),
        last_redirect_at: new Date().toISOString(),
      })
      .eq("id", businessId);

    if (!updateError) {
      console.log(`✅ Redirect stats updated: ${totalRedirects} redirects`);
    }
  } catch (error) {
    console.error("❌ Error in updateRedirectStats:", error.message);
  }
};

// ✅ HELPER FUNCTION: NOTIFY BUSINESS OWNER
const notifyBusinessOwner = async (business, review) => {
  try {
    // Fetch owner details
    const { data: owner } = await supabase
      .from("users")
      .select("email, full_name, notification_preferences")
      .eq("uid", business.owner_id)
      .single();

    if (!owner || !owner.email) {
      console.log("⚠️ Owner email not found, skipping notification");
      return;
    }

    // Check if owner wants low-rating notifications
    const notifPrefs = owner.notification_preferences || {};
    if (notifPrefs.low_rating_alerts === false) {
      console.log("⚠️ Owner has disabled low-rating alerts");
      return;
    }

    // Create notification record
    const { error: notifError } = await supabase.from("notifications").insert([
      {
        user_id: business.owner_id,
        business_id: business.id,
        type: "low_rating_review",
        title: `New ${review.rating}-star review needs attention`,
        message: `${review.customer_name} left a ${review.rating}-star review for ${business.name}`,
        priority: review.rating <= 2 ? "high" : "medium",
        read: false,
        data: {
          review_id: review.id,
          customer_name: review.customer_name,
          rating: review.rating,
          review_text: review.review_text,
          created_at: review.created_at,
        },
        created_at: new Date().toISOString(),
      },
    ]);

    if (notifError) {
      console.error("❌ Failed to create notification:", notifError.message);
    } else {
      console.log(`✅ Business owner notified about low rating review`);
    }

    // TODO: Send email notification (integrate with email service)
    // await sendEmailNotification(owner.email, {
    //   subject: `New ${review.rating}-star review for ${business.name}`,
    //   body: `Customer ${review.customer_name} left a review that needs your attention...`
    // });
  } catch (error) {
    console.error("❌ Error in notifyBusinessOwner:", error.message);
  }
};

// Export these functions so they can be used in the controller
export { notifyBusinessOwner, updateBusinessStats, updateRedirectStats };

