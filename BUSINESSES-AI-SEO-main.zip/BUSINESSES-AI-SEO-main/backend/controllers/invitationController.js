import crypto from "crypto";
import nodemailer from "nodemailer";
import twilio from "twilio";
import supabase from "../config/supabase.js";
import { generateAIInvitationContent } from "./aiChatController.js";

const verifyTwilioConfig = () => {
  try {
    if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_PHONE_NUMBER) {
      return false;
    }
    return true;
  } catch (error) {
    console.error( error);
    return false;
  }
};
const formatPhoneNumber = (phone) => {
  let cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '91' + cleaned.substring(1);
  }
  if (!cleaned.startsWith('91') && cleaned.length === 10) {
    cleaned = '91' + cleaned;
  }
  if (!cleaned.startsWith('+')) {
    cleaned = '+' + cleaned;
  }
  return cleaned;
};

const isValidPhoneNumber = (phone) => {
  const e164Regex = /^\+[1-9]\d{1,14}$/;
  return e164Regex.test(phone);
};
const createTwilioClient = () => {
  if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_PHONE_NUMBER) {
    throw new Error("Twilio credentials are not configured in .env file");
  }
  return twilio(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_AUTH_TOKEN
  );
};
const createTransporter = () => {
  console.log("Creating email transporter...");
  console.log("Email User:", process.env.EMAIL_USER);
  console.log("App Password exists:", !!process.env.EMAIL_APP_PASSWORD);
  
  if (!process.env.EMAIL_USER || !process.env.EMAIL_APP_PASSWORD) {
    throw new Error("EMAIL_USER and EMAIL_APP_PASSWORD must be set in .env file");
  }

  return nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false, 
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_APP_PASSWORD, 
    },
    tls: {
      rejectUnauthorized: false 
    }
  });
};
const verifyTransporter = async (transporter) => {
  try {
    console.log("Verifying email transporter...");
    await transporter.verify();
    console.log("Email transporter verified successfully");
    return true;
  } catch (error) {
    console.error("Email transporter verification failed:", error.message);
    throw new Error(`Email configuration error: ${error.message}`);
  }
};

export const sendEmailInvitation = async (req, res) => {
  try {
    console.log("🔍 Starting email invitation process...");
    const { businessId, customerEmail, customerName } = req.body;

    console.log("📝 Input validation:", { businessId, customerEmail, customerName });
    if (!businessId || !customerEmail || !customerName) {
      console.log("❌ Missing required fields");
      return res.status(400).json({ error: "Missing required fields" });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(customerEmail)) {
      console.log("❌ Invalid email format:", customerEmail);
      return res.status(400).json({ error: "Invalid email format" });
    }

    console.log("🏢 Checking business ownership for:", businessId, "by user:", req.user?.uid);
    const { data: business, error: bizError } = await supabase
      .from("businesses")
      .select("*")
      .eq("id", businessId)
      .eq("owner_id", req.user.uid)
      .single();

    console.log("🏢 Business query result:", { business: !!business, error: bizError?.message });

    if (bizError) {
      console.error("❌ Business query error:", bizError);
      return res.status(403).json({ error: "Database error: " + bizError.message });
    }

    if (!business) {
      console.error("Business not found or not owned by user");
      return res.status(403).json({ error: "Business not found or unauthorized" });
    }

    console.log("Business found:", business.name);

    const token = crypto.randomBytes(32).toString("hex");
    const reviewUrl = `${process.env.FRONTEND_URL}/review/${businessId}?token=${token}`;
    console.log("Review URL generated:", reviewUrl);
    console.log("Generating AI content with Gemini...");
    const aiContent = await generateAIInvitationContent(business, { name: customerName }, "email");
    console.log("AI content result:", { 
      hasEmail: !!aiContent?.email, 
      hasSubject: !!aiContent?.email?.subject,
      hasBody: !!aiContent?.email?.body 
    });

    const subject = aiContent?.email?.subject || `We value your feedback at ${business.name}`;
    const body = (aiContent?.email?.body || `Hi ${customerName},\n\nPlease leave a review:\n\n{{review_link}}\n\nThank you!`)
      .replace("{{review_link}}", reviewUrl);

    console.log("Email content prepared:", { subject, bodyLength: body.length });

      console.log("Checking email configuration...");
    if (!process.env.EMAIL_USER || !process.env.EMAIL_APP_PASSWORD) {
      return res.status(500).json({ 
        error: "Email configuration missing",
        details: "EMAIL_USER or EMAIL_APP_PASSWORD not set in .env file",
        hint: "Set up Gmail App Password: https://myaccount.google.com/apppasswords"
      });
    }

    let transporter;
    try {
      transporter = createTransporter();
      await verifyTransporter(transporter);
    } catch (error) {
      console.error("Email configuration error:", error.message);
      return res.status(500).json({ 
        error: "Email configuration error",
        details: error.message,
        hint: "Make sure you're using a Gmail App Password, not your regular password"
      });
    }
    console.log(" Sending email via Nodemailer...");
    
    const mailOptions = {
      from: {
        name: business.name,
        address: process.env.EMAIL_USER
      },
      to: customerEmail,
      replyTo: process.env.EMAIL_USER,
      subject: subject,
      text: body,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9;">
          <div style="background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <h2 style="color: #333; margin-bottom: 20px;">${subject}</h2>
            <div style="color: #555; line-height: 1.6;">
              ${body.split('\n').map(line => `<p>${line}</p>`).join('')}
            </div>
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #999; font-size: 12px;">
              <p>This email was sent from ${business.name}</p>
            </div>
          </div>
        </div>
      `
    };

    console.log("Email options:", {
      to: mailOptions.to,
      from: mailOptions.from,
      subject: mailOptions.subject
    });

    let emailSent = false;
    let messageId = null;

    try {
      const info = await transporter.sendMail(mailOptions);
      console.log("Email sent successfully:", info.messageId);
      emailSent = true;
      messageId = info.messageId;
    } catch (emailError) {
      console.error("Failed to send email:", emailError.message);
      return res.status(500).json({ 
        error: "Failed to send email",
        details: emailError.message,
        code: emailError.code,
        hint: emailError.code === 'EAUTH' 
          ? 'Invalid Gmail App Password. Generate a new one at: https://myaccount.google.com/apppasswords'
          : 'Check your email configuration'
      });
    }
    console.log("💾 Saving invitation to database...");
    const { data: invitation, error: insertError } = await supabase
      .from("review_invitations")
      .insert([{
        business_id: businessId,
        customer_email: customerEmail,
        customer_name: customerName,
        invitation_type: "email",
        status: emailSent ? "sent" : "failed",
        unique_token: token,
        review_url: reviewUrl,
        metadata: {
          sent_by: req.user.uid,
          dynamic_content: aiContent,
          ai_provider: "gemini",
          ai_generated: !!aiContent?.email?.subject,
          message_id: messageId,
          sent_at: new Date().toISOString()
        }
      }])
      .select()
      .single();

    if (insertError) {
      console.error("Database insert error:", insertError);
      return res.status(201).json({ 
        message: "Email sent but failed to save record", 
        warning: insertError.message,
        messageId: messageId
      });
    }

    console.log("Invitation saved to database:", invitation.id);

    res.status(201).json({ 
      message: "AI-powered email sent successfully", 
      invitation,
      aiProvider: "gemini",
      aiGenerated: !!aiContent?.email?.subject,
      messageId: messageId,
      sentTo: customerEmail
    });

  } catch (error) {
    console.error("Email invitation error:", error.message);
    console.error("Full error:", error);

    res.status(500).json({ 
      error: "Failed to send email invitation",
      details: error.message,
      hint: error.code === 'EAUTH' 
        ? 'Invalid Gmail credentials. Use an App Password from: https://myaccount.google.com/apppasswords'
        : 'Check server logs for more details'
    });
  }
};


export const sendSmsInvitation = async (req, res) => {
  try {
    const { businessId, customerPhone, customerName } = req.body;
    console.log("Input validation:", { businessId, customerPhone, customerName });
    if (!businessId || !customerPhone || !customerName) {
      console.log("Missing required fields");
      return res.status(400).json({ 
        error: "Missing required fields",
        required: ["businessId", "customerPhone", "customerName"]
      });
    }

    const formattedPhone = formatPhoneNumber(customerPhone);
    console.log("Phone formatting:", { original: customerPhone, formatted: formattedPhone });

    if (!isValidPhoneNumber(formattedPhone)) {
      console.log("Invalid phone number format:", formattedPhone);
      return res.status(400).json({ 
        error: "Invalid phone number format",
        details: "Phone number must be in international format (e.g., +919876543210)",
        provided: customerPhone,
        formatted: formattedPhone
      });
    }

    console.log("🏢 Checking business ownership for:", businessId, "by user:", req.user?.uid);
    const { data: business, error: bizError } = await supabase
      .from("businesses")
      .select("*")
      .eq("id", businessId)
      .eq("owner_id", req.user.uid)
      .single();

    console.log("Business query result:", { business: !!business, error: bizError?.message });

    if (bizError) {
      console.error("Business query error:", bizError);
      return res.status(403).json({ error: "Database error: " + bizError.message });
    }

    if (!business) {
      console.error("Business not found or not owned by user");
      return res.status(403).json({ error: "Business not found or unauthorized" });
    }

    console.log("Business found:", business.name);

    const token = crypto.randomBytes(32).toString("hex");
    const reviewUrl = `${process.env.FRONTEND_URL}/review/${businessId}?token=${token}`;
    console.log("Review URL generated:", reviewUrl);
    console.log("Generating AI content with Gemini...");
    const aiContent = await generateAIInvitationContent(
      business,
      { name: customerName },
      "sms"
    );
    console.log("AI content generated:", { hasSms: !!aiContent?.sms });

    let smsText = (aiContent?.sms || `Hi ${customerName}! Thanks for visiting ${business.name}. Please share your experience: {{review_link}}`)
      .replace("{{review_link}}", reviewUrl);

    if (smsText.length > 160) {
      console.log("SMS too long, truncating...");
      const maxTextLength = 160 - reviewUrl.length - 10;
      const shortText = `Hi ${customerName}! Review ${business.name}: ${reviewUrl}`;
      smsText = shortText.length <= 160 ? shortText : shortText.substring(0, 157) + "...";
    }

    console.log("SMS text prepared:", { length: smsText.length, text: smsText });

    console.log("Checking Twilio configuration...");
    if (!verifyTwilioConfig()) {
      return res.status(500).json({ 
        error: "SMS service not configured",
        details: "Twilio credentials are missing. Please contact administrator.",
        hint: "Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER in .env"
      });
    }

    let smsSent = false;
    let messageSid = null;
    let smsError = null;

    try {
      console.log("Sending SMS via Twilio...");
      const twilioClient = createTwilioClient();

      const message = await twilioClient.messages.create({
        body: smsText,
        from: process.env.TWILIO_PHONE_NUMBER,
        to: formattedPhone
      });

      messageSid = message.sid;
      smsSent = true;
      console.log("SMS sent successfully:", messageSid);
      console.log("SMS details:", {
        to: message.to,
        from: message.from,
        status: message.status,
        sid: message.sid
      });

    } catch (twilioError) {
      console.error("Failed to send SMS:", twilioError.message);
      smsError = twilioError.message;
      return res.status(500).json({ 
        error: "Failed to send SMS",
        details: twilioError.message,
        code: twilioError.code,
        possibleReasons: [
          "Invalid phone number format",
          "Phone number not verified (Twilio trial)",
          "Insufficient Twilio credits",
          "Country not supported",
          "Twilio credentials invalid"
        ],
        hint: twilioError.code === 21211 
          ? "This phone number is not verified in your Twilio trial account. Add it at: https://console.twilio.com/us1/develop/phone-numbers/manage/verified"
          : "Check your Twilio configuration and account balance"
      });
    }

    console.log("Saving invitation to database...");
    const { data: invitation, error: insertError } = await supabase
      .from("review_invitations")
      .insert([{
        business_id: businessId,
        customer_phone: formattedPhone,
        customer_name: customerName,
        invitation_type: "sms",
        status: smsSent ? "sent" : "failed",
        unique_token: token,
        review_url: reviewUrl,
        metadata: {
          sent_by: req.user.uid,
          dynamic_content: aiContent,
          ai_provider: "gemini",
          message_sid: messageSid,
          sent_at: new Date().toISOString(),
          sms_provider: "twilio",
          phone_formatted: formattedPhone,
          original_phone: customerPhone
        }
      }])
      .select()
      .single();

    if (insertError) {
      console.error("Database insert error:", insertError);
      return res.status(201).json({ 
        message: "SMS sent but failed to save record", 
        warning: insertError.message,
        messageSid: messageSid,
        sentTo: formattedPhone
      });
    }

    console.log("Invitation saved to database:", invitation.id);

    res.status(201).json({
      message: "AI-powered SMS sent successfully",
      invitation,
      smsPreview: smsText,
      aiProvider: "gemini",
      messageSid: messageSid,
      sentTo: formattedPhone,
      deliveryStatus: "sent",
      smsLength: smsText.length,
      estimatedSegments: Math.ceil(smsText.length / 160)
    });

  } catch (error) {
    console.error("SMS invitation error:", error.message);
    console.error("Full error:", error);

    res.status(500).json({
      error: "Failed to send SMS invitation",
      details: error.message,
      hint: "Check Twilio configuration and account status"
    });
  }
};
