import crypto from "crypto";
import { auth } from "../config/firebase.js";
import supabase from "../config/supabase.js";
import nodemailer from "nodemailer";

const generateRefreshToken = async (userId) => {
  const refreshToken = crypto.randomUUID();
  await supabase
    .from("users")
    .update({
      refresh_token: refreshToken,
      updated_at: new Date().toISOString(),
    })
    .eq("id", userId);
  return refreshToken;
};

export const signup = async (req, res) => {
  try {
    const { email, password, name, phone } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        error: "Email and password are required",
        code: "MISSING_FIELDS",
      });
    }
    const { data: existingUser } = await supabase
      .from("users")
      .select("id, email")
      .eq("email", email)
      .single();

    if (existingUser) {
      return res.status(400).json({
        error: "User already exists",
        code: "USER_EXISTS",
      });
    }
    const firebaseUser = await auth.createUser({
      email,
      password,
      displayName: name,
    });

    const { data: supabaseUser, error: supabaseError } = await supabase
      .from("users")
      .insert([
        {
          firebase_uid: firebaseUser.uid,
          email: firebaseUser.email,
          name: name || null,
          phone: phone || null,
          role: "business-owner",
          email_verified: true,
          phone_verified: false,
          is_active: true,
        },
      ])
      .select("id, firebase_uid, email, name, role, created_at")
      .single();

    if (supabaseError) {
      await auth.deleteUser(firebaseUser.uid);
      throw new Error(`Database error: ${supabaseError.message}`);
    }
    const customToken = await auth.createCustomToken(firebaseUser.uid, {
      role: supabaseUser.role,
      supabase_id: supabaseUser.id,
    });

    res.status(201).json({
      message: "User created successfully",
      user: {
        id: supabaseUser.id,
        firebase_uid: firebaseUser.uid,
        email: firebaseUser.email,
        name: supabaseUser.name,
        role: supabaseUser.role,
        created_at: supabaseUser.created_at,
        emailVerified: true,
      },
      customToken,
    });
  } catch (error) {
    console.error("Signup error:", error);
    res.status(500).json({
      error: "Failed to create user",
      code: "SIGNUP_FAILED",
      details: process.env.NODE_ENV === "development" ? error.message : undefined,
    });
  }
};

export const signupWithGoogle = async (req, res) => {
  try {
    const { idToken, fallbackEmail } = req.body; // 🔹 get fallbackEmail from frontend
    console.log("fallbackEmail:", fallbackEmail)
    console.log("idToken:", idToken

    )
    if (!idToken) {
      return res.status(400).json({
        error: "Google ID token is required",
        code: "MISSING_ID_TOKEN",
      });
    }
    
    const decodedToken = await auth.verifyIdToken(idToken);
    const { uid, email: tokenEmail, name, picture, email_verified } = decodedToken;

    // 🔹 Use fallbackEmail if token doesn't have email
    const email = tokenEmail || fallbackEmail;
    if (!email) {
      return res.status(400).json({
        error: "No email found in Google account",
        code: "MISSING_EMAIL",
      });
    }
    console.log("Using Email:", email);

    const { data: user, error } = await supabase
      .from("users")
      .upsert({
        firebase_uid: uid,
        email: email,
        name: name || null,
        photo_url: picture || null,
        email_verified: email_verified || false,
        role: "business-owner",
        is_active: true,
        updated_at: new Date().toISOString(),
      }, {
        onConflict: 'firebase_uid',
        returning: 'representation'
      })
      .select()
      .single();

    if (error) {
      return res.status(500).json({
        error: "Database error",
        code: "DB_ERROR",
      });
    }

    const customToken = await auth.createCustomToken(uid, {
      role: user.role,
      supabase_id: user.id,
    });

    const refreshToken = crypto.randomUUID();
     console.log("LOGIN SUCCESS",user)
    res.json({
      message: "Google login successful",
      user,
      customToken,
      refreshToken,
      isNewUser: !user.created_at || new Date(user.created_at) > new Date(Date.now() - 1000),
    });

  } catch (error) {
    console.error("Google signup error:", error);
    res.status(500).json({
      error: "Google authentication failed",
      code: "GOOGLE_AUTH_FAILED",
    });
  }
};





export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        error: "Email and password are required",
        code: "MISSING_FIELDS",
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        error: "Invalid email format",
        code: "INVALID_EMAIL",
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        error: "Password must be at least 6 characters",
        code: "INVALID_PASSWORD",
      });
    }

    
    let authResult;
    try {
      const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${process.env.FIREBASE_WEB_API_KEY}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email,
          password: password,
          returnSecureToken: true,
        }),
      });

      authResult = await response.json();

      if (!response.ok) {
        console.error( authResult.error?.message);
        
        switch (authResult.error?.message) {
          case 'EMAIL_NOT_FOUND':
            return res.status(404).json({
              error: "No account found with this email address",
              code: "USER_NOT_FOUND",
            });
          
          case 'INVALID_PASSWORD':
            return res.status(401).json({
              error: "Incorrect password",
              code: "WRONG_PASSWORD",
            });
          
          case 'USER_DISABLED':
            return res.status(403).json({
              error: "This account has been disabled",
              code: "USER_DISABLED",
            });
          
          case 'TOO_MANY_ATTEMPTS_TRY_LATER':
            return res.status(429).json({
              error: "Too many failed login attempts. Please try again later",
              code: "TOO_MANY_REQUESTS",
            });
          
          case 'INVALID_EMAIL':
            return res.status(400).json({
              error: "Invalid email address",
              code: "INVALID_EMAIL",
            });
          
          default:
            return res.status(401).json({
              error: "Authentication failed",
              code: "AUTH_FAILED",
              details: authResult.error?.message,
            });
        }
      }


    } catch (fetchError) {
      console.error(fetchError);
      return res.status(503).json({
        error: "Authentication service unavailable",
        code: "AUTH_SERVICE_ERROR",
      });
    }

    let firebaseUser;
    try {
      firebaseUser = await auth.getUserByEmail(email);
      console.log(firebaseUser.uid);
    } catch (adminError) {
      console.error(adminError);
      return res.status(500).json({
        error: "Failed to retrieve user details",
        code: "USER_DETAILS_ERROR",
      });
    }

    const { data: supabaseUser, error: supabaseError } = await supabase
      .from("users")
      .select("id, firebase_uid, email, name, role, is_active, created_at")
      .eq("firebase_uid", firebaseUser.uid)
      .single();

    if (supabaseError) {
      console.error("Supabase query error:", supabaseError);
      return res.status(500).json({
        error: "Database error during login",
        code: "DATABASE_ERROR",
      });
    }

    if (!supabaseUser) {
      console.error("User not found in Supabase for UID:", firebaseUser.uid);
      return res.status(404).json({
        error: "User profile not found. Please contact support",
        code: "PROFILE_NOT_FOUND",
      });
    }

    if (supabaseUser.is_active === false) {
      console.error("User account is deactivated:", supabaseUser.id);
      return res.status(403).json({
        error: "Your account has been deactivated. Please contact support",
        code: "ACCOUNT_DEACTIVATED",
      });
    }



    const customToken = await auth.createCustomToken(firebaseUser.uid, {
      role: supabaseUser.role,
      supabase_id: supabaseUser.id,
      email: supabaseUser.email,
    });

    const refreshToken = crypto.randomUUID();
    
    const { error: updateError } = await supabase
      .from("users")
      .update({
        refresh_token: refreshToken,
        last_login: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq("id", supabaseUser.id);

    if (updateError) {
      console.error('Failed to update user login info:', updateError);
    }

    try {
      await supabase.from("login_logs").insert([
        {
          user_id: supabaseUser.id,
          firebase_uid: firebaseUser.uid,
          email: supabaseUser.email,
          login_time: new Date().toISOString(),
          ip_address: req.ip || req.connection.remoteAddress,
          user_agent: req.get('User-Agent'),
          success: true,
        },
      ]);

      return res.status(200).json({
        success: true,
        message: 'Login successful',
        customToken: customToken,
        user: {
          id: supabaseUser.id,
          email: supabaseUser.email,
          name: supabaseUser.name,
          role: supabaseUser.role,
          is_active: supabaseUser.is_active,
          created_at: supabaseUser.created_at
        }
      });
    } catch (logError) {
      console.error(logError);
    }


    const userResponse = {
      id: supabaseUser.id,
      firebase_uid: firebaseUser.uid,
      email: firebaseUser.email,
      name: supabaseUser.name || '',
      role: supabaseUser.role,
      created_at: supabaseUser.created_at,
      updated_at: supabaseUser.updated_at
    };

    res.json({
      message: "Login successful",
      user: {
        id: supabaseUser.id,
        firebase_uid: firebaseUser.uid,
        email: firebaseUser.email,
        name: supabaseUser.name,
        role: supabaseUser.role,
        is_active: supabaseUser.is_active,
        created_at: supabaseUser.created_at,
      },
      tokens: {
        customToken,
        refreshToken,
      },
      loginTime: new Date().toISOString(),
    });

  } catch (error) {
    console.error(error);

    try {
      await supabase.from("login_logs").insert([
        {
          email: req.body.email,
          login_time: new Date().toISOString(),
          ip_address: req.ip || req.connection.remoteAddress,
          user_agent: req.get('User-Agent'),
          success: false,
          error_message: error.message,
        },
      ]);
    } catch (logError) {
      console.error(logError);
    }
    if(error.code === "auth/user-not-found") {
      return res.status(404).json({
        error: "No user found with this email",
        code: "USER_NOT_FOUND",
      });
    }
    res.status(401).json({
      error: "Invalid email or password",
      code: "INVALID_CREDENTIALS",
    });

    res.status(500).json({
      error: "Internal server error during login",
      code: "INTERNAL_ERROR",
    });
  }
};

export const logout = async (req, res) => {
  try {
    await auth.revokeRefreshTokens(req.user.firebase_uid);
    console.log("Tokens revoked for user:", req.user.uid);

    res.json({
      message: "Logout successful",
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Logout error:", error);
    res.status(500).json({
      error: "Logout failed",
      code: "LOGOUT_FAILED",
    });
  }
};

export const getProfile = async (req, res) => {
  try {

    const { data: user, error } = await supabase
      .from("users")
      .select("id, email, name, phone, role, photo_url, created_at, updated_at")
      .eq("firebase_uid", req.user.firebase_uid)
      .single();

    if (error) {
      console.error( error);
      throw error;
    }

    if (!user) {
      return res.status(404).json({
        error: "User profile not found",
        code: "PROFILE_NOT_FOUND",
      });
    }


    res.json({
      user: {
        ...user,
        firebase_uid: req.user.firebase_uid,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Failed to fetch profile",
      code: "PROFILE_FETCH_FAILED",
    });
  }
};

export const updateProfile = async (req, res) => {
  try {
    const { name, phone, photo_url } = req.body;

    const updates = {};
    if (name !== undefined) updates.name = name;
    if (phone !== undefined) updates.phone = phone;
    if (photo_url !== undefined) updates.photo_url = photo_url;

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({
        error: "No valid fields to update",
        code: "NO_UPDATES",
      });
    }

    updates.updated_at = new Date().toISOString();

    const { data, error } = await supabase
      .from("users")
      .update(updates)
      .eq("firebase_uid", req.user.firebase_uid)
      .select()
      .single();

    if (error) {
      console.error( error);
      throw error;
    }

    res.json({
      message: "Profile updated successfully",
      user: data,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Failed to update profile",
      code: "PROFILE_UPDATE_FAILED",
    });
  }
};

const createTransporter = () => {
  
  if (!process.env.EMAIL_USER || !process.env.EMAIL_APP_PASSWORD) {
    throw new Error("EMAIL_USER and EMAIL_APP_PASSWORD must be set in .env file");
  }

  return nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_APP_PASSWORD,
    },
    tls: {
      rejectUnauthorized: false
    }
  });
};

const verifyTransporter = async (transporter) => {
  try {
    await transporter.verify();
    return true;
  } catch (error) {
    console.error(error.message);
    throw new Error(`Email configuration error: ${error.message}`);
  }
};

export const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        error: "Email is required",
        code: "EMAIL_REQUIRED",
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        error: "Invalid email format",
        code: "INVALID_EMAIL",
      });
    }

    let firebaseUser;
    try {
      firebaseUser = await auth.getUserByEmail(email);
    } catch (firebaseError) {
      console.error("User not found in Firebase:", firebaseError.code);
      
      if (firebaseError.code === "auth/user-not-found") {
        return res.status(404).json({
          error: "No user found with this email",
          code: "USER_NOT_FOUND",
        });
      }
      
      throw firebaseError;
    }

    const { data: supabaseUser, error: supabaseError } = await supabase
      .from("users")
      .select("id, name, email")
      .eq("firebase_uid", firebaseUser.uid)
      .single();

    const resetLink = await auth.generatePasswordResetLink(email, {
      url: `${process.env.FRONTEND_URL}/reset-password`,
    });


    if (!process.env.EMAIL_USER || !process.env.EMAIL_APP_PASSWORD) {
      return res.status(500).json({ 
        error: "Email service not configured",
        code: "EMAIL_SERVICE_ERROR",
        hint: "Contact administrator - email service is not set up"
      });
    }

    let transporter;
    try {
      transporter = createTransporter();
      await verifyTransporter(transporter);
    } catch (error) {
      console.error(error.message);
      return res.status(500).json({ 
        error: "Email service configuration error",
        code: "EMAIL_CONFIG_ERROR",
        hint: "Please try again later or contact support"
      });
    }

    const userName = supabaseUser?.name || "User";
    const subject = "Reset Your Password";
    
    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Reset</title>
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">Password Reset Request</h1>
        </div>
        
        <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; border: 1px solid #ddd;">
          <h2 style="color: #333; margin-top: 0;">Hello ${userName}!</h2>
          
          <p style="font-size: 16px; margin-bottom: 20px;">
            We received a request to reset your password. If you didn't make this request, you can safely ignore this email.
          </p>
          
          <p style="font-size: 16px; margin-bottom: 30px;">
            To reset your password, click the button below:
          </p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetLink}" 
               style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                      color: white; 
                      padding: 15px 30px; 
                      text-decoration: none; 
                      border-radius: 5px; 
                      font-weight: bold; 
                      font-size: 16px; 
                      display: inline-block;">
              Reset My Password
            </a>
          </div>
          
          <p style="font-size: 14px; color: #666; margin-top: 30px;">
            <strong>Security Note:</strong> This link will expire in 1 hour for your security.
          </p>
          
          <p style="font-size: 14px; color: #666;">
            If the button doesn't work, you can copy and paste this link into your browser:
          </p>
          
          <p style="font-size: 12px; color: #888; word-break: break-all; background: #f0f0f0; padding: 10px; border-radius: 5px;">
            ${resetLink}
          </p>
          
          <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
          
          <p style="font-size: 12px; color: #888; text-align: center;">
            If you didn't request this password reset, please ignore this email or contact support if you have concerns.
          </p>
          
          <p style="font-size: 12px; color: #888; text-align: center;">
            This email was sent from your account security system.
          </p>
        </div>
      </body>
      </html>
    `;

    const emailText = `
Hello ${userName}!

We received a request to reset your password. If you didn't make this request, you can safely ignore this email.

To reset your password, click the link below:
${resetLink}

This link will expire in 1 hour for your security.

If you didn't request this password reset, please ignore this email or contact support if you have concerns.
    `;
    
    const mailOptions = {
      from: {
        name: "Your App Security",
        address: process.env.EMAIL_USER
      },
      to: email,
      subject: subject,
      text: emailText,
      html: emailHtml
    };

    let emailSent = false;
    let messageId = null;

    try {
      const info = await transporter.sendMail(mailOptions);
      console.log(info.messageId);
      emailSent = true;
      messageId = info.messageId;
    } catch (emailError) {
      console.error(emailError.message);
      
      return res.status(500).json({ 
        error: "Failed to send password reset email",
        code: "EMAIL_SEND_FAILED",
        hint: emailError.code === 'EAUTH' 
          ? 'Email service authentication failed. Please try again later.'
          : 'Email service temporarily unavailable. Please try again later.'
      });
    }

    try {
      await supabase.from("password_reset_logs").insert([
        {
          user_id: supabaseUser?.id || null,
          firebase_uid: firebaseUser.uid,
          email: email,
          reset_requested_at: new Date().toISOString(),
          ip_address: req.ip || req.connection.remoteAddress,
          user_agent: req.get('User-Agent'),
          email_sent: emailSent,
          message_id: messageId,
        },
      ]);
    } catch (logError) {
      console.error(logError)
    }


    res.json({
      message: "Password reset link sent to your email",
      email: email,
      sentAt: new Date().toISOString(),
      expiresIn: "1 hour"
    });

  } catch (error) {
    console.error(error);

    try {
      await supabase.from("password_reset_logs").insert([
        {
          email: req.body.email,
          reset_requested_at: new Date().toISOString(),
          ip_address: req.ip || req.connection.remoteAddress,
          user_agent: req.get('User-Agent'),
          email_sent: false,
          error_message: error.message,
        },
      ]);
    } catch (logError) {
      console.error(logError)
    }

    if (error.code === "auth/user-not-found") {
      return res.status(404).json({
        error: "No user found with this email",
        code: "USER_NOT_FOUND",
      });
    }

    res.status(500).json({
      error: "Failed to send reset link",
      code: "RESET_LINK_FAILED",
      details: process.env.NODE_ENV === "development" ? error.message : undefined,
    });
  }
};

export const refreshToken = async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({
        error: "Refresh token is required",
        code: "REFRESH_TOKEN_REQUIRED",
      });
    }

    const { data: user } = await supabase
      .from("users")
      .select("id, firebase_uid, email, role")
      .eq("refresh_token", refreshToken)
      .single();

    if (!user) {
      return res.status(401).json({
        error: "Invalid refresh token",
        code: "INVALID_REFRESH_TOKEN",
      });
    }

    const newCustomToken = await auth.createCustomToken(user.firebase_uid, {
      role: user.role,
      supabase_id: user.id,
    });

    res.json({
      message: "Token refreshed successfully",
      customToken: newCustomToken,
    });
  } catch (error) {
    console.error("Refresh token error:", error);
    res.status(500).json({
      error: "Failed to refresh token",
      code: "TOKEN_REFRESH_FAILED",
    });
  }
};
