import { createClient } from "@supabase/supabase-js";
import dotenv from 'dotenv';

dotenv.config();

// Validate environment variables
if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_KEY) {
  console.error("❌ Missing Supabase configuration");
  console.log("SUPABASE_URL:", process.env.SUPABASE_URL ? "Set" : "Missing");
  console.log("SUPABASE_SERVICE_KEY:", process.env.SUPABASE_SERVICE_KEY ? "Set" : "Missing");
  throw new Error("Missing required Supabase configuration");
}

console.log("🔧 Initializing Supabase client...");
console.log("Supabase URL:", process.env.SUPABASE_URL);

// Custom fetch with retry logic
const customFetch = async (url, options = {}) => {
  const maxRetries = 3;
  let lastError;

  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          ...options.headers,
          'apikey': process.env.SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      });

      if (!response.ok) {
        const error = new Error(`HTTP error! status: ${response.status}`);
        error.status = response.status;
        throw error;
      }

      return response;
    } catch (error) {
      lastError = error;
      console.warn(`Attempt ${i + 1} failed:`, error.message);
      
      // Wait before retrying (exponential backoff)
      if (i < maxRetries - 1) {
        const delay = Math.pow(2, i) * 1000; // 1s, 2s, 4s
        console.log(`Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }

  throw lastError || new Error('Max retries reached');
};

// Create Supabase client with retry logic
const createSupabaseClient = () => {
  try {
    // Create the client with minimal configuration
    const client = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_KEY,
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
          detectSessionInUrl: false
        },
        global: {
          headers: {
            'x-application-name': 'AI-Review-Backend',
            'apikey': process.env.SUPABASE_SERVICE_KEY,
            'Authorization': `Bearer ${process.env.SUPABASE_SERVICE_KEY}`
          }
        },
        db: {
          schema: 'public'
        }
      }
    );

    // Create a wrapper function for queries with retry logic
    const queryWithRetry = async (queryFn, maxRetries = 3) => {
      let lastError;
      
      for (let i = 0; i < maxRetries; i++) {
        try {
          const { data, error } = await queryFn();
          
          if (error) {
            throw error;
          }
          
          return { data, error: null };
        } catch (error) {
          lastError = error;
          console.warn(`Attempt ${i + 1} failed:`, error.message);
          
          if (i < maxRetries - 1) {
            const delay = Math.pow(2, i) * 1000;
            console.log(`Retrying in ${delay}ms...`);
            await new Promise(resolve => setTimeout(resolve, delay));
          }
        }
      }
      
      throw lastError || new Error('Max retries reached');
    };
    
    // Add the queryWithRetry method to the client
    client.queryWithRetry = queryWithRetry;
    
    return client;
  } catch (error) {
    console.error('❌ Failed to create Supabase client:', error);
    throw error;
  }
};

const supabase = createSupabaseClient();

// Test connection on startup
async function testConnection() {
  try {
    console.log("🔍 Testing Supabase connection...");
    
    const { data, error } = await supabase.queryWithRetry(async () => {
      return await supabase
        .from('users')
        .select('*')
        .limit(1);
    });

    if (error) {
      console.error("❌ Supabase connection test failed after retries:", error);
      console.error("Please check your Supabase URL and service key");
      console.error("SUPABASE_URL:", process.env.SUPABASE_URL ? 'Set' : 'Not set');
      console.error("SUPABASE_SERVICE_KEY:", process.env.SUPABASE_SERVICE_KEY ? 'Set' : 'Not set');
    } else {
      console.log("✅ Successfully connected to Supabase!");
      console.log("Connection test successful at:", new Date().toISOString());
    }
  } catch (error) {
    console.error("❌ Error testing Supabase connection:", {
      message: error.message,
      code: error.code,
      timestamp: new Date().toISOString()
    });
    
    if (error.message.includes('fetch failed') || error.message.includes('ECONNREFUSED')) {
      console.error("\n🔧 Connection Troubleshooting Tips:");
      console.error("1. Check if Supabase URL is correct");
      console.error("2. Verify the service key has the correct permissions");
      console.error("3. Check if your network allows outbound connections to Supabase");
      console.error("4. Try accessing the Supabase dashboard to verify the service is up");
    }
  }
}

// Run the test connection in non-test environments
if (process.env.NODE_ENV !== 'test') {
  testConnection();
}

export default supabase;