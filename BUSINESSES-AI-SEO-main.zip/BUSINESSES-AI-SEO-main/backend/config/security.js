// config/security.js
import helmet from "helmet";
import cors from "cors";
import compression from "compression";

export const REQUEST_LIMITS = {
  JSON_LIMIT: '10mb',
  URL_ENCODED_LIMIT: '10mb',
};

const defaultDevOrigins = [
  "http://localhost:5173",
  "http://127.0.0.1:5173",
  "http://localhost:3000",
  "http://127.0.0.1:3000",
  'https://clurst.io',
'https://clurst.netlify.app/',
'https://clurst.netlify.app',
'https://www.clurst.io',
   'http://clurst.io','https://clurstseo.netlify.app/','https://clurstseo.netlify.app',
  'http://www.clurst.io/',
  'http://clurst.io/',
  'http://www.clurst.io/',
 

];

export const corsConfig = {
  origin: function (origin, callback) {
    // Build allowed origins from env (if present) else use defaults
    const envOrigins = process.env.ALLOWED_ORIGINS
      ? process.env.ALLOWED_ORIGINS.split(",").map(s => s.trim()).filter(Boolean)
      : [];

    // Allow any localhost / 127.x for development to avoid port mismatches
    const allowLocalhost = (o) =>
      o && (o.startsWith("http://localhost:") || o.startsWith("http://127.0.0.1:"));

    const allowedOrigins = envOrigins.length > 0 ? envOrigins : defaultDevOrigins;

    // Debug log
    console.log("CORS check - origin:", origin, "allowedOrigins:", allowedOrigins);

    // Allow non-browser requests (curl, Postman) — no Origin header
    if (!origin) return callback(null, true);

    // Allow exact list
    if (allowedOrigins.includes(origin)) return callback(null, true);

    // Allow any localhost/127.x (dev convenience)
    if (allowLocalhost(origin)) return callback(null, true);

    // Otherwise block
    console.warn("CORS blocked request from origin:", origin);
    return callback(new Error("Not allowed by CORS policy"));
  },
  credentials: true,
  optionsSuccessStatus: 200,
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
  allowedHeaders: [
    "Origin",
    "X-Requested-With",
    "Content-Type",
    "Accept",
    "Authorization",
    "X-API-Key",
    "X-Client-Version"
  ],
  maxAge: 86400,
};

export const helmetConfig = {
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
    },
  },
  crossOriginEmbedderPolicy: false,
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  }
};

export const compressionConfig = {
  threshold: 1024,
  level: 6,
  filter: (req, res) => {
    if (req.headers['x-no-compression']) return false;
    return compression.filter(req, res);
  }
};

// createSecurityMiddleware returns an array of middlewares to apply in server.js
export const createSecurityMiddleware = () => {
  return [
    // trust proxy setter middleware — server.js also sets trust proxy; harmless
    (req, res, next) => {
      req.app.set('trust proxy', process.env.NODE_ENV === 'production');
      next();
    },

    // Helmet
    helmet(helmetConfig),

    // CORS (centralized)
    cors(corsConfig),

    // Compression
    compression(compressionConfig),

    // Simple request logger wrapper (keeps response.send behavior)
    (req, res, next) => {
      const start = Date.now();
      const originalSend = res.send;
      res.send = function (body) {
        const duration = Date.now() - start;
        console.log(`${req.method} ${req.path} - ${res.statusCode} - ${duration}ms - ${req.ip}`);
        return originalSend.call(this, body);
      };
      next();
    },

    // Security headers
    (req, res, next) => {
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('X-Frame-Options', 'DENY');
      res.setHeader('X-XSS-Protection', '1; mode=block');
      res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
      res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
      next();
    }
  ];
};

// Expose other configs if needed
export const getSecuritySettings = () => {
  const isProduction = process.env.NODE_ENV === 'production';
  return {
    enableSecurityHeaders: true,
    isProduction,
  };
};
