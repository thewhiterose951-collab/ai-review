import express from "express";
import { authenticateToken, requireRole } from "../middleware/auth.js";
import {
  getNotifications,
  markAsRead,
  markAllAsRead,
  deleteNotification,
  sendNotification,
} from "../controllers/notificationController.js";

const notificationRouter = express.Router();

notificationRouter.get("/", authenticateToken, getNotifications);

notificationRouter.patch("/read/:id", authenticateToken, markAsRead);

notificationRouter.patch("/read-all", authenticateToken, markAllAsRead);

notificationRouter.delete("/:id", authenticateToken, deleteNotification);

notificationRouter.post(
  "/send",
  authenticateToken,
  requireRole(["admin"]),
  sendNotification
);

export { notificationRouter };
