// routes/qrRoutes.js
import express from "express";
import { authenticateToken, applyRateLimit } from "../middleware/auth.js";
import {
  generateLocalReviewQR,
  generateGoogleReviewQR,
  getBusinessQRCodes
} from "../controllers/qrController.js";

const router = express.Router();

// Apply auth to all routes
router.use(authenticateToken);


// Generate local review QR (1-3 stars)
router.post("/generate/local/:businessId",  generateLocalReviewQR);

// Generate Google review QR (4-5 stars)
router.post("/generate/google/:businessId",  generateGoogleReviewQR);


// Get all QR codes for business
router.get("/:businessId", getBusinessQRCodes);

export default router;