// routes/adminRoutes.js
import express from "express";
import { authenticateToken, requireRole } from "../middleware/auth.js";
import {
  getAllUsers,
  updateUser,
  deleteUser,
  getAllReviews,
  getAllPayments,
  getAllBusinesses,
  updateSettings,
  getSettings,
} from "../controllers/adminController.js";

const router = express.Router();
router.use(authenticateToken);
router.use(requireRole(["admin"]));
router.get("/users", getAllUsers);
router.put("/users/:id", updateUser);
router.delete("/users/:id", deleteUser);
router.get("/reviews", getAllReviews);
router.get("/payments", getAllPayments);
router.get("/businesses", getAllBusinesses);
router.get("/settings", getSettings);
router.put("/settings", updateSettings);

export default router;