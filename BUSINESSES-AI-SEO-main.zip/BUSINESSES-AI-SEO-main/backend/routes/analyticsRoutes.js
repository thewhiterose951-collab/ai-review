import express from "express";
import { authenticateToken } from "../middleware/auth.js";
import {
  getBusinessAnalytics,
  exportAnalyticsCSV,
} from "../controllers/analyticsController.js";

const analyticsRouter = express.Router();

analyticsRouter.get("/:businessId", authenticateToken, getBusinessAnalytics);

analyticsRouter.get("/export/csv/:businessId", authenticateToken, exportAnalyticsCSV);

export { analyticsRouter };
