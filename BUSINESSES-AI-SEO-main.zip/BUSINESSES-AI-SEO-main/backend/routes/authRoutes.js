// routes/authRoutes.js
import express from "express";
import { authenticateToken, applyRateLimit } from "../middleware/auth.js";
import {
  signup,
  signupWithGoogle,
  login,
  logout,
  getProfile,
  updateProfile,
  forgotPassword,
  refreshToken,
} from "../controllers/authController.js";

const router = express.Router();

const authRateLimit = applyRateLimit(20, 15 * 60 * 1000); 
const strictAuthRateLimit = applyRateLimit(5, 15 * 60 * 1000);
const generalRateLimit = applyRateLimit(100, 15 * 60 * 1000);

router.post("/signup", strictAuthRateLimit, signup);
router.post("/login", strictAuthRateLimit, login);
router.post('/signup-google', signupWithGoogle);
router.post("/forgot-password", strictAuthRateLimit, forgotPassword);



router.post("/refresh", authRateLimit, refreshToken);

router.get("/profile", generalRateLimit, authenticateToken, getProfile);
router.put("/profile", authRateLimit, authenticateToken, updateProfile);
router.post("/logout", generalRateLimit, authenticateToken, logout);

export default router;
