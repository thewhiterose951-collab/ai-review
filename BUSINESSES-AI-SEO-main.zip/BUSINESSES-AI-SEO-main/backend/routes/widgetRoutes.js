import express from "express";
import { authenticateToken, requireRole } from "../middleware/auth.js";
import {
  createWidget,
  getBusinessWidgets,
  getWidget,
  updateWidget,
  displayWidget,
  deleteWidget,
  previewWidget
} from "../controllers/widgetController.js";

const widgetRouter = express.Router();

widgetRouter.post("/create", authenticateToken, requireRole(["client", "business_owner"]), createWidget);
widgetRouter.get("/business/:businessId", authenticateToken, requireRole(["client", "business_owner"]), getBusinessWidgets);
widgetRouter.get("/:widgetId", authenticateToken, requireRole(["client", "business_owner"]), getWidget);
widgetRouter.put("/:widgetId", authenticateToken, requireRole(["client", "business_owner"]), updateWidget);
widgetRouter.delete("/:widgetId", authenticateToken, requireRole(["client", "business_owner"]), deleteWidget);
widgetRouter.post("/preview", authenticateToken, requireRole(["client", "business_owner"]), previewWidget);
widgetRouter.get("/display/:businessId/:widgetId", displayWidget);

export default widgetRouter;
