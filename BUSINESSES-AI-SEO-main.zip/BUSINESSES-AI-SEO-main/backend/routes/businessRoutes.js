import express from "express";
import {
  deleteBusiness,
  getBusinessById,
  getMyBusinesses,
  registerBusiness,
  updateBusiness
} from "../controllers/businessController.js";
import { authenticateToken } from "../middleware/auth.js";

const router = express.Router();
router.post("/register", authenticateToken, registerBusiness);
router.get("/all-business", authenticateToken, getMyBusinesses);
router.get("/:id", authenticateToken, getBusinessById);
router.put("/:id", authenticateToken, updateBusiness);
router.delete("/:id", authenticateToken, deleteBusiness);

export default router;