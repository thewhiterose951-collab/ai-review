import express from "express";
import multer from 'multer';
import {
  sendEmailInvitation,
  sendSmsInvitation
} from "../controllers/invitationController.js";
import { processBulkInvitations } from "../controllers/bulkInvitationController.js";
import { authenticateToken, requireRole } from "../middleware/auth.js";

const router = express.Router();
const upload = multer();

router.use(authenticateToken);
router.use(requireRole(["business-owner"]));

router.post("/email", sendEmailInvitation);
router.post("/sms", sendSmsInvitation);
router.post("/bulk-upload", upload.single('file'), processBulkInvitations);

export default router;