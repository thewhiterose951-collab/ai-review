// d:\AI-Review-app\ai-review-backend\routes\integrationRoutes.js
import express from "express";
import {
  redirectToGoogleBusiness,
  googleOAuthCallback,
  checkConnectionStatus,
  syncGoogleReviews,
} from "../controllers/integrationController.js";
import { authenticateToken, requireRole, applyRateLimit } from "../middleware/auth.js";

const router = express.Router();

// Rate limiting
const integrationRateLimit = applyRateLimit(30, 60 * 1000); // 30 requests per minute
const statusRateLimit = applyRateLimit(10, 60 * 1000); // 10 requests per minute

// Public endpoints
router.get("/google-setup", integrationRateLimit, redirectToGoogleBusiness);
router.get("/google-callback", integrationRateLimit, googleOAuthCallback);
router.get("/status", statusRateLimit, checkConnectionStatus);

// Protected routes
router.use(authenticateToken);
router.use(requireRole(["business-owner"]));
router.post("/sync-reviews", integrationRateLimit, syncGoogleReviews);

export default router;