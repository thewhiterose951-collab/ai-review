// routes/reviewRoutes.js
import express from "express";
import supabase from "../config/supabase.js";
import {
  exportReviewsCSV,
  generateAISampleReviews,
  getReviews,
  getReviewSummary,
  submitReviewToDatabase,
  submitReviewToGoogle,
  syncReviewsDaily,
} from "../controllers/reviewController.js";

import { authenticateToken, requireRole } from "../middleware/auth.js";

const router = express.Router();

// Submit 1-3 star reviews to database
router.post("/submit/database", submitReviewToDatabase);

// Submit 4-5 star reviews to Google
router.post("/submit/google", submitReviewToGoogle);

// Get AI sample reviews for display
router.post("/samples/google/:businessId", async (req, res) => {
  try {
    const { businessId } = req.params;
    const { rating } = req.body;

    const { data: business } = await supabase
      .from("businesses")
      .select("id, name, category, location")
      .eq("id", businessId)
      .single();

    if (!business) {
      return res.status(404).json({ error: "Business not found" });
    }

    const samples = await generateAISampleReviews(business, rating);
    res.json({ samples });
  } catch (error) {
    res.status(500).json({ error: "Failed to generate samples" });
  }
});

router.use(authenticateToken);
router.use(requireRole(["business-owner", "admin"]));

// Get all reviews
router.get("/:businessId", getReviews);


// Get review summary
router.get("/summary/:businessId", getReviewSummary);

// Export reviews
router.get("/export/:businessId", exportReviewsCSV);

// Admin: Sync all reviews
router.post("/sync/all-daily", requireRole(["admin"]), syncReviewsDaily);

export default router;