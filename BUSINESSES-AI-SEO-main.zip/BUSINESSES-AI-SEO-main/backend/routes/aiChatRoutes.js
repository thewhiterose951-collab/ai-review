import express from "express";
import {
  generateAIInvitationContent
} from "../controllers/aiChatController.js";

const router = express.Router();


router.post("/invitation-message", async (req, res) => {
  try {
    const { business, customer, mode } = req.body;

    const content = await generateAIInvitationContent(business, customer, mode || "email");
    res.json({ content });
  } catch (e) {
    res.status(500).json({ error: "Failed to generate AI invitation message" });
  }
});

export default router;