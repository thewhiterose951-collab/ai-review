import express from "express";
import { google } from "googleapis";
import { OAuth2Client } from "google-auth-library";
import axios from "axios";

const router = express.Router();

const oauth2Client = new OAuth2Client(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI || "http://localhost:8000/auth/google/google-callback"
);

router.get("/login", (req, res) => {
  const authUrl = oauth2Client.generateAuthUrl({
    access_type: "offline",
    prompt: "consent",
    scope: [
      "https://www.googleapis.com/auth/business.manage",
      "https://www.googleapis.com/auth/userinfo.email",
      "https://www.googleapis.com/auth/userinfo.profile",
      "openid",
    ],
  });
  res.redirect(authUrl);
});

router.get("/google-callback", async (req, res) => {
  try {
    const { code } = req.query;
    if (!code) throw new Error("No authorization code received");

    const { tokens } = await oauth2Client.getToken(code);
    oauth2Client.setCredentials(tokens);

    const oauth2 = google.oauth2({ version: "v2", auth: oauth2Client });
    const userInfo = await oauth2.userinfo.get();

    global.googleTokens = tokens;
    global.googleUser = userInfo.data;

    const frontendUrl = process.env.FRONTEND_URL ;
    const redirectUrl = `${frontendUrl}/integrations?success=true&user=${encodeURIComponent(userInfo.data.email)}`;
    res.redirect(redirectUrl);
  } catch (error) {
    console.error("OAuth callback error:", error);
    res.status(500).json({ error: error.message });
  }
});

async function getBearerToken() {
  if (!global.googleTokens) throw new Error("No tokens available");
  return global.googleTokens.access_token;
}

router.get("/businesses", async (req, res) => {
  try {
    if (!global.googleTokens) return res.status(401).json({ error: "Not authenticated" });

    const token = await getBearerToken();

    const accountsRes = await axios.get("https://mybusinessaccountmanagement.googleapis.com/v1/accounts", {
      headers: { Authorization: `Bearer ${token}` },
    });
    const accounts = accountsRes.data.accounts || [];

    let allLocations = [];
    for (const account of accounts) {
      const accountId = account.name.split("/")[1]; 
      try {
        const locationsRes = await axios.get(
          `https://mybusinessbusinessinformation.googleapis.com/v1/accounts/${accountId}/locations`,
          {
            headers: { Authorization: `Bearer ${token}` },
            params: {
              readMask: "name,title,storeCode,metadata,latlng,phoneNumbers,regularHours",
            },
          }
        );
        const locations = locationsRes.data.locations || [];
        allLocations.push(...locations.map(loc => ({ ...loc, accountId })));
      } catch (locErr) {
        console.warn(`Failed to fetch locations for account ${accountId}:`, locErr.response?.data || locErr.message);
      }
    }

    res.json({
      user: global.googleUser,
      businesses: allLocations,
    });
  } catch (error) {
    console.error("Error fetching businesses:", error.response?.data || error.message);
    res.status(500).json({
      user: global.googleUser || null,
      businesses: [],
      error: error.response?.data || error.message,
    });
  }
});

router.get("/reviews/:accountId/:locationId", async (req, res) => {
  try {
    if (!global.googleTokens) return res.status(401).json({ error: "Not authenticated" });

    const { accountId, locationId } = req.params;
    const token = await getBearerToken();

    const reviewsRes = await axios.get(
      `https://mybusiness.googleapis.com/v4/accounts/${accountId}/locations/${locationId}/reviews`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    console.log("res review",reviewsRes)

    res.json(reviewsRes.data);
  } catch (error) {
    console.error("Error fetching reviews:", error.response?.data || error.message);
    res.status(500).json({ reviews: [], error: error.response?.data || error.message });
  }
});

router.get("/status", (req, res) => {
  res.json({
    authenticated: !!global.googleTokens,
    user: global.googleUser || null,
  });
});

router.post("/disconnect", (req, res) => {
  global.googleTokens = null;
  global.googleUser = null;
  oauth2Client.setCredentials({});
  res.json({ message: "Disconnected successfully" });
});

router.post("/accounts/:accountId/locations/:locationId/localPosts", async (req, res) => {
  try {
    if (!global.googleTokens) return res.status(401).json({ error: "Not authenticated" });

    const { accountId, locationId } = req.params;
    const { summary, languageCode = 'en-US', media } = req.body;
    const token = await getBearerToken();

    const postData = {
      languageCode,
      summary,
      topicType: 'STANDARD',
    };

    if (media && media.length > 0) {
      postData.media = media.map(item => ({
        mediaFormat: 'PHOTO',
        sourceUrl: item.sourceUrl,
        thumbnail: item.thumbnail || item.sourceUrl
      }));
    }

    console.log('Creating post with data:', JSON.stringify(postData, null, 2));
    
    const postRes = await axios.post(
      `https://mybusiness.googleapis.com/v4/accounts/${accountId}/locations/${locationId}/localPosts`,
      postData,
      {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      }
    );

    console.log('Post created successfully:', postRes.data);
    res.json(postRes.data);
  } catch (error) {
    console.error("Error creating post:", error.response?.data || error.message);
    res.status(error.response?.status || 500).json({ 
      error: error.response?.data?.error || error.message 
    });
  }
});

router.get("/accounts/:accountId/locations/:locationId/localPosts", async (req, res) => {
  try {
    if (!global.googleTokens) return res.status(401).json({ error: "Not authenticated" });

    const { accountId, locationId } = req.params;
    const token = await getBearerToken();

    console.log(`Fetching posts for account ${accountId}, location ${locationId}`);
    
    const response = await axios.get(
      `https://mybusiness.googleapis.com/v4/accounts/${accountId}/locations/${locationId}/localPosts`,
      {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      }
    );

    console.log('Successfully fetched posts:', response.data);
    res.json(response.data);
  } catch (error) {
    console.error("Error fetching posts:", error.response?.data || error.message);
    res.status(error.response?.status || 500).json({ 
      error: error.response?.data?.error || error.message 
    });
  }
});

router.get("/posts/:accountId/:locationId", async (req, res) => {
  try {
    if (!global.googleTokens) return res.status(401).json({ error: "Not authenticated" });

    const { accountId, locationId } = req.params;
    const token = await getBearerToken();

    const postsRes = await axios.get(
      `https://mybusiness.googleapis.com/v4/accounts/${accountId}/locations/${locationId}/localPosts`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    res.json(postsRes.data);
  } catch (error) {
    console.error("Error fetching posts:", error.response?.data || error.message);
    res.status(500).json({ error: error.response?.data || error.message });
  }
});

export default router;
