import express from "express";
import { authenticateToken } from "../middleware/auth.js";
import {
  getSEORankings,
  analyzeSEO,
  getTopBusinesses,
} from "../controllers/seoController.js";

const seoRouter = express.Router();

seoRouter.get("/rank/:businessId", authenticateToken, getSEORankings);
seoRouter.post("/analyze", authenticateToken, analyzeSEO);
seoRouter.get("/top/:region/:category", getTopBusinesses);

export default seoRouter;

