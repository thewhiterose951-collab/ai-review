import compression from "compression";
import cors from "cors";
import 'dotenv/config';
import express from "express";
import helmet from "helmet";

console.log('Environment Variables:');
console.log('NODE_ENV:', process.env.NODE_ENV);
console.log('SUPABASE_URL:', process.env.SUPABASE_URL ? 'Set' : 'Not Set');
console.log('FIREBASE_PROJECT_ID:', process.env.FIREBASE_PROJECT_ID || 'Not Set');

import { createSecurityMiddleware, getSecuritySettings, REQUEST_LIMITS } from "./config/security.js";
import { cleanupSecurityData, createRateLimit, ipBlacklist } from "./middleware/auth.js";
import { authenticateToken } from "./middleware/auth.js";
import adminRoutes from "./routes/adminRoutes.js";
import aiChatRoutes from "./routes/aiChatRoutes.js";
import { analyticsRouter } from "./routes/analyticsRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import businessRoutes from "./routes/businessRoutes.js";
import dashboardRoutes from "./routes/dashboardRoutes.js";
import invitationRouter from "./routes/invitationRoutes.js";
import { notificationRouter } from "./routes/notificationRoutes.js";
import qrRoutes from "./routes/qrRoutes.js";
import reviewRoutes from "./routes/reviewRoutes.js";
import seoRouter from "./routes/seoRoutes.js";
import googleRoutes from "./routes/googleRoutes.js";
import widgetRouter from './routes/widgetRoutes.js';
import auditRoutes from './routes/auditRoutes.js';

const app = express();
const PORT = process.env.PORT || 8000;
const NODE_ENV = process.env.NODE_ENV || 'development';
const isProduction = NODE_ENV === 'production';

app.set('trust proxy', isProduction ? 1 : false);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:", "blob:"],
      connectSrc: ["'self'", "https://api.openai.com", "https://generativelanguage.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
    },
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  },
  crossOriginEmbedderPolicy: false,
  referrerPolicy: { policy: "strict-origin-when-cross-origin" }
}));

app.use(createSecurityMiddleware());

app.use(ipBlacklist);

const globalRateLimit = createRateLimit(
  isProduction ? 1000 : 5000,
  15 * 60 * 1000,
  "Too many requests from this IP"
);
const strictRateLimit = createRateLimit(
  isProduction ? 50 : 200,
  15 * 60 * 1000,
  "Rate limit exceeded for sensitive operations"
);

app.use(globalRateLimit);

const allowedOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',')
  : ['http://clurst.io', 'https://clurstseo.netlify.app/',
    'https://clurst.io',
    'https://clurst.netlify.app/',
    'https://clurst.netlify.app',
    'https://www.clurst.io',
    'https://clurstseo.netlify.app',
    'http://www.clurst.io/',
    'http://clurst.io/', 'http://localhost:3000', 'http://localhost:8000', 'http://localhost:5173', 'http://localhost:5174', 'http://127.0.0.1:5174'];

app.use(cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true);

    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      console.warn(`CORS blocked request from origin: ${origin}`);
      callback(new Error('Not allowed by CORS policy'));
    }
  },
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
  allowedHeaders: [
    "Content-Type",
    "Authorization",
    "X-Requested-With",
    "X-API-Key",
    "X-Client-Version"
  ],
  exposedHeaders: ["X-Total-Count", "X-Page", "X-Per-Page"],
  maxAge: 86400
}));

app.use(compression({
  threshold: 1024,
  level: 6,
  filter: (req, res) => {
    if (req.headers['x-no-compression']) return false;
    return compression.filter(req, res);
  }
}));

app.use(express.json({
  limit: REQUEST_LIMITS.JSON_LIMIT,
  verify: (req, res, buf) => {
    req.rawBody = buf;
  }
}));

app.use(express.urlencoded({
  limit: REQUEST_LIMITS.URL_ENCODED_LIMIT,
  extended: true,
  parameterLimit: 100
}));

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');

  res.removeHeader('X-Powered-By');

  next();
});

app.use((req, res, next) => {
  const startTime = Date.now();
  const ip = req.ip || req.connection.remoteAddress;
  const userAgent = req.get('User-Agent') || 'Unknown';

  const logData = {
    timestamp: new Date().toISOString(),
    method: req.method,
    path: req.path,
    ip: ip,
    userAgent: userAgent.substring(0, 100),
    contentLength: req.get('Content-Length') || 0
  };

  console.log(`${logData.timestamp} - ${logData.method} ${logData.path} - ${logData.ip}`);

  res.on('finish', () => {
    const duration = Date.now() - startTime;
    if (duration > 5000) {
      console.warn(`Slow request: ${req.method} ${req.path} - ${duration}ms`);
    }
  });

  next();
});

app.get("/api", (req, res) => {
  res.json({
    message: "AI Review Platform API",
    version: process.env.API_VERSION || "1.0.0",
    status: "running",
    timestamp: new Date().toISOString(),
    environment: NODE_ENV,
    security: {
      rateLimiting: "enabled",
      cors: "configured",
      headers: "secured"
    },
    endpoints: {
      auth: "/auth",
      business: "/business",
      reviews: "/reviews",
      dashboard: "/dashboard",
      admin: "/admin",
      qr: "/qr",
      wallet: "/wallet",
      subscriptions: "/subscription",
      notifications: "/notifications",
      analytics: "/analytics",
      seo: "/seo",
      ai: "/ai",
      integration: "/integration",
      invitations: "/invitations",
      widgets: "/widgets",
      templates: "/templates"
    }
  });
});

app.get("/", (req, res) => {
  res.send("Backend is running")
})

app.get("/health", (req, res) => {
  const memoryUsage = process.memoryUsage();
  const uptime = process.uptime();

  res.json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    uptime: {
      seconds: Math.floor(uptime),
      human: `${Math.floor(uptime / 60)}m ${Math.floor(uptime % 60)}s`
    },
    memory: {
      used: `${Math.round(memoryUsage.heapUsed / 1024 / 1024)}MB`,
      total: `${Math.round(memoryUsage.heapTotal / 1024 / 1024)}MB`,
      external: `${Math.round(memoryUsage.external / 1024 / 1024)}MB`
    },
    environment: NODE_ENV,
    version: process.env.API_VERSION || "1.0.0",
    nodeVersion: process.version
  });
});

app.get("/api/status", (req, res) => {
  res.status(200).send("OK");
});



app.get("/api/me", authenticateToken, (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  res.status(200).json({ user: req.user });
});

app.use("/api/auth", strictRateLimit, authRoutes);
app.use("/api/business", businessRoutes);
app.use("/api/reviews", reviewRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/admin", strictRateLimit, adminRoutes);
app.use("/api/qr", qrRoutes);
app.use("/api/notifications", notificationRouter);
app.use("/api/analytics", analyticsRouter);
app.use("/api/seo", seoRouter);
app.use("/api/ai", aiChatRoutes);
app.use("/api/audit", auditRoutes);
app.use("/auth/google", googleRoutes);
app.use("/api/invitations", invitationRouter);
app.use("/api/widgets", widgetRouter);
app.use("/webhooks", express.raw({ type: 'application/json' }), (req, res, next) => {
  console.log(`Webhook received: ${req.path}`);
  next();
});

app.use((req, res) => {
  console.warn(`404 - Endpoint not found: ${req.method} ${req.originalUrl} from ${req.ip}`);

  res.status(404).json({
    error: "Endpoint not found",
    code: "ENDPOINT_NOT_FOUND",
    path: req.originalUrl,
    method: req.method,
    timestamp: new Date().toISOString(),
    suggestion: "Check the API documentation for available endpoints"
  });
});

app.use((error, req, res, next) => {
  const errorId = Date.now().toString(36);

  console.error(`Error ${errorId}:`, {
    message: error.message,
    stack: isProduction ? undefined : error.stack,
    url: req.url,
    method: req.method,
    ip: req.ip,
    timestamp: new Date().toISOString()
  });

  if (error.type === 'entity.parse.failed') {
    return res.status(400).json({
      error: "Invalid JSON in request body",
      code: "INVALID_JSON",
      errorId,
      timestamp: new Date().toISOString()
    });
  }

  if (error.type === 'entity.too.large') {
    return res.status(413).json({
      error: "Request entity too large",
      code: "REQUEST_TOO_LARGE",
      errorId,
      timestamp: new Date().toISOString()
    });
  }

  if (error.message === 'Not allowed by CORS policy') {
    return res.status(403).json({
      error: "CORS policy violation",
      code: "CORS_ERROR",
      errorId,
      timestamp: new Date().toISOString()
    });
  }

  if (error.status === 429) {
    return res.status(429).json({
      error: "Rate limit exceeded",
      code: "RATE_LIMIT_EXCEEDED",
      retryAfter: error.retryAfter || 900,
      errorId,
      timestamp: new Date().toISOString()
    });
  }

  const statusCode = error.status || error.statusCode || 500;

  res.status(statusCode).json({
    error: isProduction ? "Internal server error" : error.message,
    code: error.code || "INTERNAL_ERROR",
    errorId,
    timestamp: new Date().toISOString(),
    ...(isProduction ? {} : { stack: error.stack })
  });
});

const gracefulShutdown = (signal) => {
  console.log(`\nReceived ${signal}. Starting graceful shutdown...`);

  server.close((err) => {
    if (err) {
      console.error('Error during shutdown:', err);
      process.exit(1);
    }

    console.log('HTTP server closed');

    cleanupSecurityData();

    console.log('Cleanup completed');
    process.exit(0);
  });

  setTimeout(() => {
    console.error('Forced shutdown after 30s timeout');
    process.exit(1);
  }, 30000);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  gracefulShutdown('UNCAUGHT_EXCEPTION');
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  if (isProduction) {
    console.error('Unhandled rejection logged, continuing...');
  } else {
    gracefulShutdown('UNHANDLED_REJECTION');
  }
});

const securityCleanupInterval = setInterval(() => {
  cleanupSecurityData();
}, 5 * 60 * 1000);
const memoryMonitorInterval = setInterval(() => {
  const memoryUsage = process.memoryUsage();
  const memoryMB = Math.round(memoryUsage.heapUsed / 1024 / 1024);

  if (memoryMB > 500) {
    console.warn(`High memory usage: ${memoryMB}MB`);
  }
}, 10 * 60 * 1000);


const server = app.listen(PORT, () => {
  console.log(PORT)
  console.log('='.repeat(60));
  console.log(`🚀 AI Review Platform API Server Started`);
  console.log('='.repeat(60));
  console.log(`📍 Port: ${PORT}`);
  console.log(`🌍 Environment: ${NODE_ENV}`);
  console.log(`🔒 Security: ${isProduction ? 'Production' : 'Development'} mode`);
  console.log(`🔗 Health check: http://localhost:${PORT}/health`);
  console.log(`📚 API docs: http://localhost:${PORT}/`);
  console.log(`⏰ Started at: ${new Date().toISOString()}`);
  console.log(`📊 Memory usage: ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`);
  console.log('='.repeat(60));
});

server.timeout = 30000;
server.keepAliveTimeout = 65000;
server.headersTimeout = 66000;
const cleanup = () => {
  clearInterval(securityCleanupInterval);
  clearInterval(memoryMonitorInterval);
};

process.on('exit', cleanup);
process.on('SIGTERM', cleanup);
process.on('SIGINT', cleanup);

export default app;