import dotenv from 'dotenv';
import path from 'path';
import supabase from './config/supabase.js';

dotenv.config({ path: path.resolve(process.cwd(), 'ai-review-backend', '.env') });

const setupDatabase = async () => {
  try {
    console.log('Checking for reminder_sent_at column in review_invitations table...');
    const { data, error } = await supabase.rpc('add_reminder_sent_at_column');

    if (error) {
      console.error('Error adding column:', error.message);
    } else {
      console.log('Database setup complete.');
    }
  } catch (err) {
    console.error('Database setup failed:', err.message);
  }
};

setupDatabase();
